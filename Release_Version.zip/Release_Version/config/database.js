module.exports = {
	'url' : 'mongodb://admin:admin@proximus.modulusmongo.net:27017/raZyma4r'
}