/* Testarea clasei Persoana */

class TestPers {
  public static void main(String args[]) {
    Pers p1=new Pers("Antoniu","Vasile",1981);
    Pers p2, p3, p4, p5;
    String s1="Vasilescu", s2="Mihai";
    p2=new Pers(s1, s2, 1980);
    p3=new Pers(s1, "Ion", 1982);
    System.out.println("Numele persoanei p1: "+p1.nume());
    System.out.println("Prenumele persoanei p2: "+p2.prenume());
    System.out.println("Anul nasterii persoanei p3: "+p3.anNastere());
  }
}
