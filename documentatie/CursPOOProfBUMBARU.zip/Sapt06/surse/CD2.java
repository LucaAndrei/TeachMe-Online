/* O clasa in care se ascund unele din campurile superclasei */

public class CD2 extends S1 {
  public double a, b, m; // campurile a, b le ascund pe cele cu
                         // aceleasi nume din superclasa

  public CD2(int a1, double b1, int c1, double a2, 
             double b2, double m2) {
    super(a1,b1,c1); // initializarea campurilor din superclasa
    a=a2; b=b2; m=m2; // initializarea campurilor proprii
  }

  public void afisare() {
    System.out.println("Campuri din CD2: a="+a+" b="+b+" m="+m);
    System.out.println("Campuri din S1: a="+super.a+" b="+super.b);
  }

  public static int f4(int h) { // ascunde metoda statica f4() din
     // superclasa
    return h+alpha;
  }

  public String toString() {
    return "(CD2: "+super.toString()+" "+a+" "+b+" "+m+")";
  }
}


