public class Persoana {
  private String nume, prenume;
  private int anNastere;

  public Persoana(String nume, String prenume, int anNastere) {
    this.nume=nume;
    this.prenume=prenume;
    this.anNastere=anNastere;
  }

  public Persoana(Persoana pers) {
    nume=pers.nume;
    prenume=pers.prenume;
    anNastere=pers.anNastere;
  }

  public String nume() { return nume; }

  public String prenume() { return prenume; }

  public int anNastere() { return anNastere; }

  public int varsta(int anCurent) { return anCurent-anNastere; }

  public String toString() {
    return nume+" "+prenume+" "+anNastere;
  }

  public int hashCode() {
    return nume.hashCode()+prenume.hashCode()/1000+anNastere%100;
  }
}
