public class Student1 extends Persoana1 {
  private String fac, gr;
  private int anStudii;

  public Student1(String nume, String prenume, int anNastere, 
      String facultate, int an, String grupa) {
    this.nume=nume;
    this.prenume=prenume;
    this.anNastere=anNastere;
    fac=facultate;
    anStudii=an;
    gr=grupa;
  }

  public Student1(Persoana1 pers, String facultate, int an, 
        String grupa) {
    nume=pers.nume;
    prenume=pers.prenume;
    anNastere=pers.anNastere;
    fac=facultate;
    anStudii=an;
    gr=grupa;
  }

  public Student1(Student1 stud) {
   super(stud.nume(), stud.prenume(), stud.anNastere());
    fac=stud.fac;
    anStudii=stud.anStudii;
    gr=stud.gr;
  }

  public String facultate() { return fac; }

  public int an() { return anStudii; }

  public String grupa() { return gr; }

  public String toString() { 
    return super.toString()+" fac: "+fac+" an: "+anStudii+
      " grupa: "+gr;
  }
}
