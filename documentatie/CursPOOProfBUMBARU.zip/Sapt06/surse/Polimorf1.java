class Polimorf1 {
  public static void main(String args[]) {
    Object ob1, ob2, ob3, ob4;
    S1 s1a, s1b, s1c;
    CD1 cd1a;
    CD2 cd2a;
    String s1="sirul1";
    s1a=new S1(1, 2.5, 3);
    cd1a=new CD1(-1, -2.5, -3);
    cd2a=new CD2(10, 20.5, 30, 100, 200.5, 300);
    s1b=cd1a; s1c=cd2a;
    ob1=s1; ob2=s1a; ob3=cd1a; ob4=cd2a;
    System.out.println("s1a="+s1a+" s1b="+s1b);
    System.out.println("s1c="+s1c);
    System.out.println("s1a.f2()="+s1a.f2()+" s1a.f3()="+s1a.f3());
    System.out.println("s1b.f2()="+s1b.f2()+" s1b.f3()="+s1b.f3());
    System.out.println("s1c.f2()="+s1c.f2()+" s1c.f3()="+s1c.f3());
    System.out.println("ob1="+ob1+" ob2="+ob2+" ob3="+ob3);
    System.out.println("ob4="+ob4);
    System.out.println("cd1a.f2()="+cd1a.f2()+" cd1a.f3()="+cd1a.f3());
    System.out.println("cd2a.f2()="+cd2a.f2()+" cd2a.f3()="+cd2a.f3());
    System.out.println("((S1)ob2).f2()="+((S1)ob2).f2()+
      " ((S1)ob2).f3()="+((S1)ob2).f3());
    System.out.println("((S1)ob3).f2()="+((S1)ob3).f2()+
      " ((S1)ob3).f3()="+((S1)ob3).f3());
    System.out.println("((CD1)ob3).f2()="+((CD1)ob3).f2()+
      " ((CD1)ob3).f3()="+((CD1)ob3).f3());
    System.out.println("((S1)ob4).f2()="+((S1)ob4).f2()+
      " ((S1)ob4).f3()="+((S1)ob4).f3());
    System.out.println("((CD2)ob4).f2()="+((CD2)ob4).f2()+
      " ((CD2)ob4).f3()="+((CD2)ob4).f3());
  }
}
