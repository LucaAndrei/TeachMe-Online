/* Crearea si utilizarea unei Exceptii */

class ExceptieDomeniuFactorial extends Exception {
   public ExceptieDomeniuFactorial() {
      super();
   }
   public ExceptieDomeniuFactorial(String str) {
      super(str);
   }
}

class Fact {
   public static double factorial(int n) throws ExceptieDomeniuFactorial {
      if(n<0) throw new ExceptieDomeniuFactorial();
      if(n==0) return 1;
      return n*factorial(n-1);
   }
}

class TestExceptie {
   public static void main(String args[]) {
      int n;
      double fact;
      if(args.length==0) {
         System.out.println("Nu ati dat numarul intreg n ca parametru");
         System.exit(1);
      }
      try {
         n=Integer.parseInt(args[0]);
         fact=Fact.factorial(n);
         System.out.println("Factorialul este "+fact);
      }
      catch(NumberFormatException e1) {
         System.out.println("Parametrul nu are format corect de numar intreg");
      }
      catch(ExceptieDomeniuFactorial e2) { // se capteaza exceptia nou creata
         System.out.println("Nu se poate calcula factorial din numar negativ");
      }
      catch(Exception e) {
      	 System.out.println("S-a produs exceptia: "+e);
      }
   }
}


