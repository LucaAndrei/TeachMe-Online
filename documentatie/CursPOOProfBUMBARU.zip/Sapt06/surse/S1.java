/* Clasa S1 din care vor fi derivate alte clase */

public class S1 {
  public int a;
  protected double b;
  private int c;
  public final static int alpha=12;

  public S1(int a, double b, int c) { // constructorul clasei S1
    this.a=a; this.b=b; this.c=c;
  }

  private double  f1() { // o metoda privata
    return a*c+b;
  }

  protected int f2() { // o metoda protejata
    return a+2*c;
  }

  public double f3() { // o metoda publica in care se folosesc f1 si f2
    return 2*f1()+f2();
  }

  public String toString() { // redefinirea metodei Object.toString()
    return "(S1: "+a+" "+b+" "+c+")";
  }

  public static int f4(int k) {
    return 2*k+alpha;
  }
}

    
 
  