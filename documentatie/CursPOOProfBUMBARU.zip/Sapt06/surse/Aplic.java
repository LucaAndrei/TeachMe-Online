/* O clasa care contine metoda main() si poate fi instantiata */

class Aplic {
  static int a=10; // un camp static (al clasei)
  double b;  // camp al instantei
  String s;  // camp al instantei

  Aplic(double b, String s) { // constructorul clasei Aplic
    this.b=b; this.s=s;
  }

  double f1(double x) { // o metoda (functie) de instanta
    return a*b+1; // se utilizeaza campul static si cel de instanta
  }

  static int f2(int m) { // o metoda (functie) statica
    return m+a; // se utilizeaza numai campul static
  }

  public static void main(String args[]) {
    String s0="sir implicit 0", s1="sir implicit 1";
    Aplic a0, a1; // Doua referinte la instante ale clasei Aplic
    if(args.length>=1) s0=args[0];
    if(args.length>=2) s1=args[1];
    /* Se creaza doua instante ale clasei Aplic */
    a0=new Aplic(12.47, s0);
    a1=new Aplic(-15.28, s1);
    /* Campul static a si metoda statica f2 pot fi utilizate direct,
       sau calificandu-le cu numele clasei sau cu referinta la o 
       instanta
    */
    System.out.println("a="+a+" Aplic.a="+Aplic.a+" a0.a="+a0.a+
      " a1.a="+a1.a);
    System.out.println("f2(2)="+f2(2)+" Aplic.f2(2)="+Aplic.f2(2)+
      " a0.f2(2)="+a0.f2(2)+" a1.f2(2)="+a1.f2(2));
    /* Campurile si metodele de instanta se folosesc prin intermediul
       referintelor la instantele respective
    */
    System.out.println("a0.b="+a0.b+" a0.s="+a0.s);
    System.out.println("a1.b="+a1.b+" a1.s="+a1.s);
    System.out.println("a0.f1(1.5)="+a0.f1(1.5)+
      " a1.f1(1.5)="+a1.f1(1.5));
    /* Modificam campul static a si il afisam in diferite moduri */
    a=20;
    System.out.println("Dupa modificari:");
    System.out.println("a="+a+" Aplic.a="+Aplic.a+" a0.a="+a0.a+
      " a1.a="+a1.a);
    /* Modificam campul b din fiecare instanta si afisam */
    a0.b=32.5; a1.b=-121.8;
    System.out.println("a0.b="+a0.b+" a1.b="+a1.b);
  }
}
