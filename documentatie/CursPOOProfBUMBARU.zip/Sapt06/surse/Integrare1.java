/* O varianta a aplicatiei din fisierul Integrare.java, in care
   se folosesc clase imbricate si interioare
*/

/* Declararea si utilizarea unor interfete  */

/* Interfata pentru o clasa care ofera o functie reala de o variabila reala */

interface FunctieReala {
   double f(double x);
}

/* Interfata pentru o clasa care ofera o metoda de calcul al integralei 
   de la inf la sup a functiei f(x) din interfata FunctieReala
*/

interface Integrator {
   double integrala(double inf, double sup, FunctieReala func);
}

/* O clasa care implementeaza interfata Integrator, realizand integrarea prin
   metoda trapezelor a functiei f(x) cu nrPasi pasi de integrare
*/
class IntegrareTrapeze implements Integrator {
   int nrPasi; // Numarul de pasi de integrare
   /* Constructorul initializeaza numarul de pasi */
   public IntegrareTrapeze(int nrPasi) throws Exception {
      if(nrPasi<=0) throw new Exception("IntegrareTrapeze: nrPasi<=0");
      this.nrPasi=nrPasi;
   }
   /* Metoda de modificare a numarului de pasi */
   public void puneNrPasi(int nrPasi) throws Exception {
      if(nrPasi<=0) throw new Exception("IntegrareTrapeze: nrPasi<=0");
      this.nrPasi=nrPasi;
   }
   /* Implementarea metodei abstracte din interfata */
   public double integrala(double inf, double sup, FunctieReala func) {
      double h,s;
      h=(sup-inf)/nrPasi; // pasul de integrare
      s=0; // initializarea sumei ordonatelor
      for(int i=1; i<nrPasi; i++) s+=func.f(inf+i*h);
      return ((func.f(inf)+func.f(sup))/2+s)*h;
   }
}

/* O aplicatie in care se utilizeaza clasele si interfetele declarate aici
   Utilizare:
   	java Integrare inf sup nrPasi
   unde:
   	inf - marginea inferioara a intervalului de integrare (numar real)
   	sup - marginea superioara a intervalului de integrare (numar real)
   	nrPasi - numarul de pasi de integrare (numar intreg pozitiv)
*/

class Integrare1 {
   public static void main(String args[]) {
      Integrare1 int1=new Integrare1();// Instanta a acestei aplicatii
          // necesara la utilizarea claselor interioare
      IntegrareTrapeze inTrap;
      FunctieReala f1, f2;
      double inf, sup; // marginile intervalului de integrare
      int nrPasi; // numarul de pasi de integrare
      if(args.length<3) {
         System.out.println("Utilizare: java Integrare inf sup nrPasi");
         System.exit(1);
      }
      try {
         inf=Double.parseDouble(args[0]);
         sup=Double.parseDouble(args[1]);
         nrPasi=Integer.parseInt(args[2]);
         f1=int1.new Functie1(2.73, 0.15, -0.21, 2.45);
         f2=int1.new Functie1(0.46, -1.23, 1.4, -0.78);
         inTrap=new IntegrareTrapeze(nrPasi);
         System.out.println("Prima integrala:  "+inTrap.integrala(inf,sup,f1));
         System.out.println("A doua integrala: "+
             inTrap.integrala(inf,sup,f2));
         inTrap.puneNrPasi(2*nrPasi);
         System.out.println("Dupa dublarea numarului de pasi de integrare:");
         System.out.println("Prima integrala:  "+inTrap.integrala(inf,sup,f1));
         System.out.println("A doua integrala: "+inTrap.integrala(inf,sup,f2));
         /* Utilizarea clasei incuibate statice Functie2 */
         Functie2 func2=new Functie2(1,-5,6);
         System.out.println("func2.f(sup)="+func2.f(sup));
         System.out.println("Functie2.f1(inf,sup)="+Functie2.f1(inf,sup));
         System.out.println("Integrala din Functie2.f(x)="+
         	inTrap.integrala(inf,sup,func2));
      }
      catch(NumberFormatException e1) {
         System.out.println("Nu ati introdus corect parametrii aplicatiei");
      }
      catch(Exception e) {
         System.out.println("S-a produs exceptia: "+e);
      }
   }
   
   /* O clasa interioara care implementeaza interfata FunctieReala pentru a
      oferi functia f(x)=a*sin(b*x+c)+d*cos(b*x)
   */

   class Functie1 implements FunctieReala {
      private double a, b, c, d; // parametrii functiei
      /* Constructorul clasei introduce valorile parametrilor functiei */
      public Functie1(double a, double b, double c, double d) {
         this.a=a; this.b=b; this.c=c; this.d=d;
      }
      /* metoda de calculare a functiei, prin care se concretizeaza metoda
         abstracta f(x) din interfata
      */
      public double f(double x) {
         return a*Math.sin(b*x+c)+d*Math.cos(b*x);
      }
   }
   
   /* O clasa incuibata statica */
   static class Functie2 implements FunctieReala {
      private double a, b, c;
      public Functie2(double a, double b, double c) {
         this.a=a; this.b=b; this.c=c;
      }
      public double f(double x) {
         return (a*x+b)*x+c;
      }
      public void puneParam(double a, double b, double c) {
         this.a=a; this.b=b; this.c=c;
      }
      public static double f1(double x, double y) {
         return 2*x*x+3*y;
      }
   }
}

