public class Student extends Persoana {
  private String fac, gr;
  private int anStudii;

  public Student(String nume, String prenume, int anNastere, 
      String facultate, int an, String grupa) {
    super(nume, prenume, anNastere);
    fac=facultate;
    anStudii=an;
    gr=grupa;
  }

  public Student(Persoana pers, String facultate, int an, 
        String grupa) {
    super(pers);
    fac=facultate;
    anStudii=an;
    gr=grupa;
  }

  public Student(Student stud) {
   super(stud.nume(), stud.prenume(), stud.anNastere());
    fac=stud.fac;
    anStudii=stud.anStudii;
    gr=stud.gr;
  }

  public String facultate() { return fac; }

  public int an() { return anStudii; }

  public String grupa() { return gr; }

  public String toString() { 
    return super.toString()+" fac: "+fac+" an: "+anStudii+
      " grupa: "+gr;
  }
}
