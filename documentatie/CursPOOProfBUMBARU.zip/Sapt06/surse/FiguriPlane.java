/* Clase de figuri plane */

/* Declararea unei clase abstracte */

abstract class FiguraPlana {
   public abstract double perimetru(); // metoda abstracta
   public abstract double arie();  // metoda abstracta
}

/* Clase concrete derivate din cea abstracta */

class Cerc extends FiguraPlana {
   private double raza;
   public Cerc(double raza) {
      this.raza=raza;
   }
   public double raza() {
      return raza;
   }
   public double perimetru() { // redefinirea metodei abstracte
      return 2*Math.PI*raza;
   }
   public double arie() { // redefinirea metodei abstacte
      return Math.PI*raza*raza;
   }
   public double diametru() {
      return 2*raza;
   }
}

class Patrat extends FiguraPlana {
   private double latura;
   public Patrat(double latura) {
      this.latura=latura;
   }
   public double latura() {
      return latura;
   }
   public double perimetru() { // redefinirea metodei abstracte
      return 4*latura;
   }
   public double arie() { // redefinirea metodei abstracte
      return latura*latura;
   }
   public double diagonala() {
      return latura*Math.sqrt(2);
   }
}

/* Aplicatie pentru testarea claselor. Mod de utilizare:
	java FiguriPlane <numarRealPozitiv>
*/

class FiguriPlane {
   public static void main(String args[]) {
      FiguraPlana f;
      Cerc c;
      Patrat p;
      double a;
      /* Instructiunea urmatoare nu este corecta, deoarece o clasa abstracta
         nu poate fi instantiata; daca se elimina din fata // apare eroare
         la compilare
      */
      // f=new FiguraPlana();
      /* Se valideaza parametrul din linia de comnada */
      if(args.length==0) {
         System.out.println("Dati ca parametru un numar real pozitiv");
         System.exit(1);
      }
      try {
         a=Double.parseDouble(args[0]);
         if(a<=0) {
            System.out.println("Numarul nu este pozitiv");
            System.exit(2);
         }
         /* Se instantiaza clasele Cerc si Patrat */
         c=new Cerc(a);
         p=new Patrat(a);
         /* Variabilei f din clasa abstracta FiguraPlana i se poate da ca
            valoare o referinta catre o subclasa instantiabila
         */
         f=new Cerc(2*a);
         /* Aplicarea metodelor */
         System.out.println("Cerc: raza="+c.raza()+" perimetrul="+
            c.perimetru()+"\naria="+c.arie()+" diametrul="+c.diametru());
         System.out.println("Patrat: latura="+p.latura()+" perimetrul="+
            p.perimetru()+"\naria="+p.arie()+" diagonala="+p.diagonala());
         /* Daca spre un obiect din clasa Cerc indica o variabila din
            superclasa FiguraPlana, este necesara conversia de clasa pentru
            invocarea metodelor care nu exista in superclasa
         */
         System.out.println("Al doilea cerc: raza="+((Cerc)f).raza()+
            " perimetrul="+ f.perimetru()+"\naria="+f.arie()+
            " diametrul="+((Cerc)f).diametru()); }
      catch(NumberFormatException e1) {
         System.out.println("Nu ati respectat formatul de numar real");
      }
      catch(Exception e) {
         System.out.println("S-a produs exceptia: "+e);
      }
   }
}

