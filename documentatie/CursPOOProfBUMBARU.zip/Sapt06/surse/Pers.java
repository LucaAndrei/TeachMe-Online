class Pers {
  private String numePers, prenumePers;
  private int anNasterePers;

  Pers(String nume, String prenume, int anNastere) {
    numePers=nume;
    prenumePers=prenume;
    anNasterePers=anNastere;
  }

  String nume() { return numePers; }

  String prenume() { return prenumePers; }

  int anNastere() { return anNasterePers; }
}
