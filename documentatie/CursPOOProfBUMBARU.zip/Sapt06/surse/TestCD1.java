/* Testarea claselor S1 si CD1 */

class TestCD1 {
  public static void main(String args[]) {
    S1 s=new S1(1, 1.1, 2);
    CD1 cd=new CD1(10, 10.2, 20);
    System.out.println("s="+s+" cd="+cd);
    System.out.println("s.f2()="+s.f2()+" s.f3()="+s.f3());
    System.out.println("cd.f2()="+cd.f2()+" cd.f3()="+cd.f3());
    System.out.println("CD2.f4(3)="+CD2.f4(3)+" S1.f4(3)="+S1.f4(3));
    System.out.println("cd.f4(3)="+cd.f4(3)+" s.f4(3)="+s.f4(3));
  }
}
