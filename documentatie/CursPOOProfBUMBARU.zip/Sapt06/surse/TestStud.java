class TestStud {
  public static void main(String args[]) {
    Persoana p1=new Persoana("Vasiliu","George",1981), p2;
    Student s1=new Student(p1, "NIE",2,"2221a"),
	s2=new Student("Ionescu","Maria", 1980, "NIE", 2, "2322b"), s3;
    Object ob1, ob2, ob3;
    Persoana tabPers[]=new Persoana[3];
    ob1=s1;
    ob2=p2=s2;
    ob3=p1;
    System.out.println("p1="+p1);
    System.out.println("s1="+s1);
    System.out.println("s2="+s2);
    System.out.println("ob1="+ob1);
    System.out.println("p2="+p2);
    System.out.println("ob2="+ob2);
    System.out.println("ob3="+ob3);
    System.out.println("Numele lui p1: "+p1.nume());
    System.out.println("Numele lui s1: "+s1.nume());
    System.out.println("Numele lui ob1: "+((Persoana)ob1).nume());
    s3=(Student)ob2;
    System.out.println("s3="+s3);
    System.out.println("In anul 2000, s3 are "+s3.varsta(2000)+" ani");
    System.out.println("p2.hashCode()="+p2.hashCode());
    System.out.println("s1.hashCode()="+s1.hashCode());
    tabPers[0]=p1; tabPers[1]=s1; tabPers[2]=s2;
    System.out.println("Tabloul de persoane tabPers contine:");
    System.out.println("Clasa lui p1: "+p1.getClass().getName());
    System.out.println("Clasa lui ob2: "+ob2.getClass().getName());
    for(int i=0; i<tabPers.length; i++)
       System.out.println(tabPers[i]);
  }
}
