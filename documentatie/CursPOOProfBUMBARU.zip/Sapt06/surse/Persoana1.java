/* O varianta a clasei Persoana, in care campurile sunt protejate */

public class Persoana1 {
  protected String nume, prenume;
  protected int anNastere;

  public Persoana1() {} // Constructor fara argumente

  public Persoana1(String nume, String prenume, int anNastere) {
    this.nume=nume;
    this.prenume=prenume;
    this.anNastere=anNastere;
  }

  public Persoana1(Persoana1 pers) {
    nume=pers.nume;
    prenume=pers.prenume;
    anNastere=pers.anNastere;
  }

  public String nume() { return nume; }

  public String prenume() { return prenume; }

  public int anNastere() { return anNastere; }

  public int varsta(int anCurent) { return anCurent-anNastere; }

  public String toString() {
    return nume+" "+prenume+" "+anNastere;
  }

  public int hashCode() {
    return nume.hashCode()+prenume.hashCode()/1000+anNastere%100;
  }
}
