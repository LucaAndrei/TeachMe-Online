/* O clasa derivata din S1, in care se redefinesc unele metode */

public class CD1 extends S1 {
  public CD1(int a, double b, int c) {
    super(a,b,c);
  }

  public int f2() { // redefinirea metodei f2() din superclasa
    return 2*a;
  }
  public double f3() { // redefinirea metodei f3() din superclasa
    return f2()+super.f3();
  }  
}
