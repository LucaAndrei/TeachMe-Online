/* Declararea clasei Cerc1 cu metode ale instantei */

class Cerc1 {
  static final double PI=3.141592653589793;
  double r;

  double arie() {
    return PI*r*r;
  }

  double circumferinta() {
    return 2*PI*r;
  }
}

/* Declararea clasei Cerc2 cu metode ale clasei (statice) */

class Cerc2 {
  static final double PI=3.141592653589793;

  static double arie(double r) {
    return PI*r*r;
  }

  static double circumferinta(double r) {
    return 2*PI*r;
  }
}

/* Aplicatia in care se utilizeaza cele doua clase de cercuri
   declarate mai sus
*/

class Cercuri {
  public static void main(String args[]) {
    double r1=1, r2=7.32;
    Cerc1 c1=new Cerc1(), c2=new Cerc1();
    c1.r=r1; c2.r=r2;
    System.out.println("Folosind metodele de instanta din clasa Cerc1:");
    System.out.println("Pentru cercul c1: aria="+c1.arie()+
      " circumferinta="+c1.circumferinta());
    System.out.println("Pentru cercul c2: aria="+c2.arie()+
      " circumferinta="+c2.circumferinta());
    System.out.println("Folosind metodele statice din clasa Cerc2:");
    System.out.println("Pentru raza r1: aria="+Cerc2.arie(r1)+
      " circumferinta="+Cerc2.circumferinta(r1));
    System.out.println("Pentru raza r2: aria="+Cerc2.arie(r2)+
      " circumferinta="+Cerc2.circumferinta(r2));
  }
}
