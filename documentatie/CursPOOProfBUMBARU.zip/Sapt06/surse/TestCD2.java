/* Testarea clasei CD2 */

class TestCD2 {
  public static void main(String args[]) {
    CD2 cd=new CD2(1, 2.45, 3, 10.23, 12.5, 17.08);
    System.out.println("Imediat dupa ce s-a creat instanta clasei CD2:");
    cd.afisare();
    System.out.println("cd.toString(): "+cd.toString());
    cd.a=-17.83; cd.b=28.16; cd.m=127.9;
    System.out.println("dupa ce s-au schimbat valorile "+
         "campurilor din CD2:");
    cd.afisare();
    System.out.println("cd.toString(): "+cd.toString());
    System.out.println("S1.f4(3)="+S1.f4(3)+" CD2.f4(3)="+CD2.f4(3)+
         " CD1.f4(3)="+CD1.f4(3));
  }
}