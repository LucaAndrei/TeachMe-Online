/* Declararea clasei Cerc cu metode ale instantei */

class Cerc {
  public static final double PI=3.141592653589793;
  private double r;

  public Cerc(double raza) {
    r=raza;
  }

  public double raza() {
    return r;
  }

  public double arie() {
    return PI*r*r;
  }

  public double circumferinta() {
    return 2*PI*r;
  }

  public static double arie(double r) {
    return PI*r*r;
  }

  public static double circumferinta(double r) {
    return 2*PI*r;
  }
}


/* Aplicatia in care se utilizeaza cele doua clase de cercuri
   declarate mai sus
*/

class Cercuri1 {
  public static void main(String args[]) {
    double r1=1, r2=7.32;
    /* Instantierea a doua cercuri */
    Cerc c1=new Cerc(r1), c2=new Cerc(r2);
    /* Utilizarea metodelor de instanta */
    System.out.println("Utilizand metodele de instanta:");
    System.out.println("Pentru cercul c1:\n aria="+c1.arie()+
      " circumferinta="+c1.circumferinta()+" raza="+c1.raza());
    System.out.println("Pentru cercul c2:\n aria="+c2.arie()+
      " circumferinta="+c2.circumferinta()+" raza="+c2.raza());
    System.out.println("Folosind metodele statice ale clasei Cerc:");
    System.out.println("Pentru raza r1: aria="+Cerc.arie(r1)+
      " circumferinta="+Cerc2.circumferinta(r1));
    System.out.println("Pentru raza r2: aria="+Cerc.arie(r2)+
      " circumferinta="+Cerc2.circumferinta(r2));
    System.out.println("Pentru raza r=9.23 aria="+Cerc.arie(9.23)+
      " circumferinta="+Cerc.circumferinta(9.23));
    /* Acelasi calcul, facut calificand numele metodelor prin
       referinte la instante ale clasei Cerc
    */
    System.out.println("Aria cercului cu raza 9.23: "+
      c1.arie(9.23)+"  "+c2.arie(9.23));
  }
}
