/* Conversii de tip la tablouri bidimensionale */

class Tab2b {
   public static void main(String args[]) {
      Object ob1, ob2, tob2[][];
      int ti1[][]={{0,1},{10,11,12,13},{20,21,22}},ti2[][];
      String ts[][]={{"aa","ab"},{"ba","bb","bc"},{"ca","cb"}}, ts1[][];
      /* Urmatoarele doua atribuiri sunt corecte */
      ob1=ti1;
      ob2=ts;
      System.out.println("Tabloul indicat de ob1:");
      for(int i=0; i<((int[][])ob1).length; i++) {
         for(int j=0; j<((int[][])ob1)[i].length; j++)
            System.out.print(((int[][])ob1)[i][j]+"  ");
         System.out.println();
      }
      /* Urmatoarele doua atribuiri nu sunt corecte, deoarece se trece de
         la clasa la subclasa (incercati sa suprimati simbolul // ) 
      */
      // ti2=ob1;
      // ts1=ob2;
      /* In urmatoarele doua atribuiri s-a recurs la conversii explicite,
         stiind caror clase apartin efectiv obiectele referite de variabilele
         respective
      */
      ti2=(int[][])ob1;
      ts1=(String[][])ob2;
      System.out.println("Tabloul ti2:");
      for(int i=0; i<ti2.length; i++) {
         for(int j=0; j<ti2[i].length; j++) System.out.print(ti2[i][j]+"  ");
         System.out.println();
      }
      System.out.println("Tabloul ts1:");
      for(int i=0; i<ts1.length; i++) {
         for(int j=0; j<ts1[i].length; j++) System.out.print(ts1[i][j]+"  ");
         System.out.println();
      }
      /* In atribuirea urmatoare, castul este aplicat corect sub aspect
         sintactic, deci nu se semnaleaza o eroare la compilare, dar va
         apare o exceptie la executie, deoarece in mod efectiv ob2 nu este
         o referinta la int[][] ci la String[][]
      */
      try {
         ti2=(int[][])ob2;
      }
      catch(Exception e) {
         System.out.println("S-a generat exceptia: "+e);
      }
      tob2=ts;
      ts1=(String[][])tob2;  
   }
}

