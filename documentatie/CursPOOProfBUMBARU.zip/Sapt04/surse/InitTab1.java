/* Declararea si initializarea tablourilor unidimensionale */

class InitTab1 {
   public static void main(String args[]) {
      int a=27, b=-15, c[]={-3,72,-21}, d=-5, e[]={231,-98};
      String s1="un sir", ts1[]={"sirul 0","sirul 1","sirul 2"},
      		s2="alt sir";
      float[]  u={-1.24076f, 0.03254f, 27.16f}, v={2.7698E-12f,-3.876e7f};
      double aa[]=new double[3], bb[]={3.76,-2.879};
      String str[]=new String[2], s3="abcdef1234";
      long  []k={187658954760876535L, 786432098764319051L},
      		m={598028476093172L, -9892865429740341L, 92765201};
      Object tab1[]=new Object[2],tab2=new String[3],
      		tab3[]={"aaa","bbb","ccc"};
      System.out.println("Valorile variabilelor simple:");
      System.out.println("a="+a+" b="+b+" d="+d);
      System.out.println("s1="+s1+" s2="+s2+" s3="+s3);
      System.out.println("Lungimile tablourilor:");
      System.out.println("c: "+c.length+" e: "+e.length+" ts1: "+ts1.length);
      System.out.println("u: "+u.length+" v: "+v.length+" str: "+str.length);
      System.out.println("aa: "+aa.length+" bb: "+bb.length);
      System.out.println("k: "+k.length+" m: "+m.length);
      System.out.println("Componentele tablourilor:");
      System.out.println("Tabloul c:");
      for (int i=0; i<c.length; i++) System.out.print(c[i]+" ");
      System.out.println("\nTabloul ts1:");
      for(int j=0; j<ts1.length; j++) System.out.print(ts1[j]+"; ");
      System.out.println();
      System.out.println("Tabloul aa:");
      for(int i=0; i<aa.length; i++) System.out.print(aa[i]+" ");
      System.out.println("\nTabloul de siruri str:");
      for (int j=0; j<str.length; j++) System.out.print(str[j]+"; ");
      System.out.println();
      System.out.println("Tabloul tab3:");
      for(int i=0; i<tab3.length; i++) System.out.print(tab3[i]+"; ");
      System.out.println();
   }
}

