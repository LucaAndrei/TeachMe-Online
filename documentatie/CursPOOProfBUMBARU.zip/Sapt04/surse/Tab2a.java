/* Operatii cu tablouri unidimensionale si bidimensionale */

class Tab2a {
   public static void main(String args[]) {
      int a[][]={{-5,12,52},{8,-4},{},{105}}, b[]={31,-3,17,24};
      System.out.println("Dupa initializare:\nTabloul bidimensional a:");
      for(int i=0; i<a.length; i++) {
        for(int j=0; j<a[i].length; j++) System.out.print(a[i][j]+"  ");
        System.out.println();
      }
      System.out.println("Tabloul unidimensional b:");
      for(int i=0; i<b.length; i++) System.out.print(b[i]+"  ");
      System.out.println();
      /* Se fac atribuiri de valori ale componentelor si de linii de tablou */
      a[0][2]=2*b[1]-a[1][1];
      a[2]=new int[3]; // s-a creat o noua linie pentru a[2]
      a[2][0]=b[3];
      a[2][2]=a[3][0];
      a[3]=b; // S-a inlocuit vechea linie a[3] prin tabloul b
      b=a[1]; // b indica acum spre linia a[1];
      b[1]=88; // S-a modificat, de fapt, componenta a[1][1];
      /* Se afiseaza noua stare */
       System.out.println("Dupa atribuiri:\nTabloul bidimensional a:");
      for(int i=0; i<a.length; i++) {
        for(int j=0; j<a[i].length; j++) System.out.print(a[i][j]+"  ");
        System.out.println();
      }
      System.out.println("Tabloul unidimensional b:");
      for(int i=0; i<b.length; i++) System.out.print(b[i]+"  ");
      System.out.println();
   }
}

