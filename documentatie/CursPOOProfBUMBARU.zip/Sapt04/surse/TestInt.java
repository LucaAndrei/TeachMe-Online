/* Testarea clasei acoperitoare Integer */

class TestInt {
   public static void main(String args[]) {
      Integer tI[]=new Integer[5], tI1[]=new Integer[5], a;
      int tint[]=new int[5], i1;
      String ts[]={"3298","-18765","+987692","-765b32","abcde"}; 
      /* Testarea metodei statice parseInt(String) */
      for(int i=0; i<5; i++) {
         try {
            tint[i]=Integer.parseInt(ts[i]);
         }
         catch(NumberFormatException e1) {
            System.out.println("i="+i+" eroare in sirul: "+ts[i]);
         }
         catch(Exception e) {
            System.out.println("i="+i+" Exceptie "+e);
         }
      }
      System.out.print("tint=");
      for(int i=0; i<tint.length; i++) System.out.print(tint[i]+"  ");
      System.out.println();
      /* Incercam preluarea unui numar mai mare decat valoarea maxima
         a unui numar de tip int, care este 2147483647 
      */
      try {
         i1=Integer.parseInt("2147483648");
         System.out.println("i1="+i1);
      }
      catch(Exception e) {
         System.out.println("Numarul 2147483648 a produs exceptia:\n"+e);
      }
      /* Testarea metodei parseInt(String,int) */
      System.out.println("38AB3FC7 din baza 16 este: "+
      		Integer.parseInt("38AB3FC7",16));
      System.out.println("-38AB3FC7 din baza 16 este: "+
      		Integer.parseInt("-38AB3FC7",16));
      System.out.println("6423651 din baza 7 este: "+
      		Integer.parseInt("6423651",7));
      System.out.println("7GHA din baza 18 este: "+
      		Integer.parseInt("7GHA",18));
      System.out.println("-AC7D din baza 16 este: "+
      		Integer.parseInt("-AC7D",16));
      /* Incercam preluarea unui numar hexazecimal mai mare de 7FFFFFFF */
      try {
         i1=Integer.parseInt("80000000",16);
      } catch (Exception e) {
          System.out.println(e);
      }
      /* Afisarea aceluiasi numar in diferite baze de numeratie: */
      i1=1986895879;
      for(int i=2; i<=18; i+=4)
         System.out.println("in baza "+i+" i1="+Integer.toString(i1, i));
      /* Testarea metodei statice valueOf(String) poate fi facuta 
         in acelasi mod ca pentru metoda parseInt(String)
      */
      for(int i=0; i<5; i++) {
         try {
            tI[i]=Integer.valueOf(ts[i]);
         }
         catch(NumberFormatException e1) {
            System.out.println("i="+i+" eroare in sirul: "+ts[i]);
         }
         catch(Exception e) {
            System.out.println("i="+i+" Exceptie "+e);
         }
      }
      System.out.print("tI=");
      for(int i=0; i<tI.length; i++) System.out.print(tI[i]+"  ");
      System.out.println();
      /* Repetam acelasi procedeu, testand acum constructorul Integer(String)
      */
      for(int i=0; i<5; i++) {
         try {
            tI1[i]=new Integer(ts[i]);
         }
         catch(NumberFormatException e1) {
            System.out.println("i="+i+" eroare in sirul: "+ts[i]);
         }
         catch(Exception e) {
            System.out.println("i="+i+" Exceptie "+e);
         }
      }
      System.out.print("tI1=");
      for(int i=0; i<tI1.length; i++) System.out.print(tI1[i]+"  ");
      System.out.println();
      /* Pentru un singur obiect din clasa Integer aplicam toate metodele
         de conversie in valoare de tip primitiv
      */
      a=new Integer(1763478206);
      System.out.println("byte:   "+a.byteValue());
      System.out.println("short:  "+a.shortValue());
      System.out.println("int:    "+a.intValue());
      System.out.println("long:   "+a.longValue());
      System.out.println("float:  "+a.floatValue());
      System.out.println("double: "+a.doubleValue());
   }
}

