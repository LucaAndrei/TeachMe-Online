/* Utilizarea parametrilor din linia de comanda */

class Parametri {
   public static void main(String args[]) {
      if(args.length==0)
         System.out.println("Nu ati introdus parametri in linia de comanda");
      else {
         System.out.println("Aplicatia are urmatorii parametri: ");
      	 for(int i=0; i<args.length; i++)
      	    System.out.println(args[i]);
      }
   }
}

