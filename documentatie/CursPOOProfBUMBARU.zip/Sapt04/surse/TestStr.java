/* Testarea clasei String */

class TestStr {
   public static void main(String args[]) {
      String s1="ABCdef#@&", s2, s3, s4;
      char ch1[];
      byte tb[];
      s2=new String("Un sir nou");
      System.out.println("s1="+s1+"  s2="+s2);
      System.out.println("Lungimile sirurilor: s1="+s1.length()+
      	" s2="+s2.length());
      System.out.println("Conversie in litere mari: s1="+s1.toUpperCase()+
        " s2="+s2.toUpperCase());
      System.out.println("Conversie in litere mici: s1="+s1.toLowerCase()+
        " s2="+s2.toLowerCase());
      ch1=s1.toCharArray();
      System.out.print("s1 convertit in tablou de caractere:  ");
      for(int i=0; i<ch1.length; i++) System.out.print(ch1[i]);
      System.out.println(); // trecere la linie noua
      tb=s1.getBytes();
      System.out.print("s1 convertit in tablou de octeti:  ");
      for(int i=0; i<tb.length; i++) System.out.print(tb[i]+" ");
      System.out.print("\nAcelasi tablou convertit in caractere:  ");
      for(int i=0; i<tb.length; i++) System.out.print((char)tb[i]);
      System.out.println();
      s3=String.copyValueOf(ch1);
      System.out.println("Sirul obtinut din tabloul de caractere: "+s3);
      System.out.println("Comparatii de siruri: "+s1.compareTo(s3)+" "+
      	s1.compareTo(s2)+" "+s2.compareTo(s1));
      System.out.println("s1==s3: "+(s1==s3)+"   s1.equals(s3): "+
      	s1.equals(s3));
      s4=s2.toUpperCase();
      System.out.println("s2="+s2+"  s4="+s4);
      System.out.println("s2.equals(s4): "+s2.equals(s4)+
      	"  s2.equalsIgnoreCase(s4): "+s2.equalsIgnoreCase(s4));
      System.out.println("Subsirul lui s2 intre pozitiile 3 si 8: "+
      	s2.substring(3,8));
      System.out.println("Subsirul lui s2 de la pozitia 3 la sfarsit: "+
      	s2.substring(3));
   }
}

