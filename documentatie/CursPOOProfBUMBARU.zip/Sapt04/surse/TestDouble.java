/* Testarea clasei acoperitoare Double */

class TestDouble {
   public static void main(String args[]) {
      Double tD[]=new Double[6], a;
      double td[]=new double[6];
      String ts[]={"3.2987","-187.659068","+9.87692413","8.0764382e-7",
		"-238.0729456E8","4.687b53e7"};
      long b; 
      /* Testarea metodei statice parseDouble(String) */
      for(int i=0; i<6; i++) {
         try {
            td[i]=Double.parseDouble(ts[i]);
         }
         catch(NumberFormatException e1) {
            System.out.println("i="+i+" eroare in sirul: "+ts[i]);
         }
         catch(Exception e) {
            System.out.println("i="+i+" Exceptie "+e);
         }
      }
      System.out.print("td=");
      for(int i=0; i<td.length; i++) System.out.print(td[i]+"  ");
      System.out.println();
      /* Repetam acelasi procedeu, testand acum constructorul Double(String)
      */
      for(int i=0; i<6; i++) {
         try {
            tD[i]=new Double(ts[i]);
         }
         catch(NumberFormatException e1) {
            System.out.println("i="+i+" eroare in sirul: "+ts[i]);
         }
         catch(Exception e) {
            System.out.println("i="+i+" Exceptie "+e);
         }
      }
      System.out.print("tD=");
      for(int i=0; i<tD.length; i++) System.out.print(tD[i]+"  ");
      System.out.println();
      /* Pentru un singur obiect din clasa Integer aplicam toate metodele
         de conversie in valoare de tip primitiv
      */
      a=new Double(73416.853209);
      System.out.println("byte:   "+a.byteValue());
      System.out.println("short:  "+a.shortValue());
      System.out.println("int:    "+a.intValue());
      System.out.println("long:   "+a.longValue());
      System.out.println("float:  "+a.floatValue());
      System.out.println("double: "+a.doubleValue());
      /* Forma interna (binara) a numarului */
      b=Double.doubleToLongBits(a.doubleValue());
      System.out.println("Reprezentarea interna a numarului real precedent:");
      System.out.println("in binar: "+Long.toBinaryString(b));
      System.out.println("in hexazecimal: "+Long.toHexString(b));
   }
}

