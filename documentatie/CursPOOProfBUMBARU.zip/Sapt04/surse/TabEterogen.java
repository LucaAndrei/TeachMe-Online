/* Testarea construirii unui tablou eterogen */

class TabEterogen {
   public static void main(String args[]) {
      /* Construirea structurii */
      Object tab[]=new Object[3];
      tab[0]=new int[3];
      ((int[])tab[0])[0]=-87;
      ((int[])tab[0])[1]=23;
      ((int[])tab[0])[2]=164;
      tab[1]=new double[2];
      ((double[])tab[1])[0]=32.164;
      ((double[])tab[1])[1]=-6.237;
      tab[2]=new Object[3];
      ((Object[])tab[2])[0]=new String("abcd");
      ((Object[])tab[2])[1]=new String("PQRS");
      ((Object[])tab[2])[2]=new char[2];
      ((char[])((Object[])tab[2])[2])[0]='@';
      ((char[])((Object[])tab[2])[2])[1]='$';
      /* Afisarea unor componente din structura */
      System.out.println(((Object[])tab[2])[0]);
      for(int i=0; i<3; i++) 
         System.out.print(((int[])tab[0])[i]+"  ");
      System.out.println();
      for(int i=0; i<2; i++)
         System.out.print(((char[])((Object[])tab[2])[2])[i]+"  ");
      System.out.println();
   }
}

