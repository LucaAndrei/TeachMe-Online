/* Testarea clasei Class */

class TestClass {
   public static void main(String args[]) {
      String s1="Primul sir", s2="al doilea sir";
      Object obj=new Object();
      Class cls1, cls2, cls3;
      cls1=s1.getClass();
      System.out.println(cls1.getName());
      System.out.println(cls1.toString());
      cls2=s2.getClass();
      System.out.println(cls1.isAssignableFrom(cls2));
      cls3=obj.getClass();
      System.out.println(cls3);
      System.out.println(cls1.isAssignableFrom(cls3));
      System.out.println(cls3.isAssignableFrom(cls1));
      System.out.println(cls1.getSuperclass());
      System.out.println(cls3.getSuperclass());
      System.out.println(cls1.isPrimitive());
   }
}

