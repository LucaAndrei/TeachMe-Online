/* Declararea si initializarea tablourilor bidimensionale */

class Tab2 {
   public static void main(String args[]) {
      double u=5.3127, v[]={1.25, -3.12, 2.6}, 
      	w[][]={{2.31, -4.15},{0.35,-12.6, -573.2},{10.9}};
      int[] a={3,2,7}, b[]={{43,28,92,-6},{},{-1,17,29}};
      char[][] h1={{'a','*'},{'+','$'}}, h2=new char[2][3], h3=new char[4][];
      String ts[][]={{"abc","defg"},{"AB","CD","EF"}};
      System.out.println("Numarul de linii din tabloul w: "+w.length);
      System.out.println("Numarul de componente din fiecare linie a "+
        "tabloului w:");
      for (int i=0; i<w.length; i++) System.out.print(w[i].length+" ");
      System.out.println("\nComponentele tabloului w:");
      for (int i=0; i<w.length; i++) { // Se afiseaza o linie
         for (int j=0; j<w[i].length; j++) System.out.print(w[i][j]+"  ");
         System.out.println(); // Se trece la linie noua
      }
      System.out.println("Numarul de linii din tabloul b: "+b.length);
      System.out.println("Numarul de componente din fiecare linie "+
      		" a tabloului b:");
      for (int i=0; i<b.length; i++) System.out.print(b[i].length+" ");
      System.out.println("\nComponentele tabloului b:");
      for (int i=0; i<b.length; i++) {
         for (int j=0; j<b[i].length; j++) System.out.print(b[i][j]+"  ");
         System.out.println();
      }
      System.out.println("Tabloul de caractere h1:");
      for (int i=0; i<h1.length; i++) {
         for (int j=0; j<h1[i].length; j++) System.out.print(h1[i][j]+"  ");
         System.out.println();
      }
      System.out.println("Tabloul de siruri ts:");
      for (int i=0; i<ts.length; i++) {
         for (int j=0; j<ts[i].length; j++) System.out.print(ts[i][j]+"  ");
         System.out.println();
      }
   }
}

