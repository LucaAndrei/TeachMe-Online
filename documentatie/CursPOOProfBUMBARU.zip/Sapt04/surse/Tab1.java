/* Utilizarea tablourilor unidimensionale */

class Tab1 {
   public static void main(String args[]) {
      double a[]={3.276, -5.83, 12.8}, b[];
      String ts1[]={"aa", "bb"},ts2[];
      /* Variabilelor b si ts1 li se atribuie ca valori referinte la tablouri
      	 existente, apoi se afiseaza
      */
      b=a;
      ts2=ts1;
      System.out.println("Dupa atribuirile b=a si ts2=ts1:");
      for (int i=0; i<a.length; i++) 
        System.out.println("i="+i+" a[i]="+a[i]+" b[i]="+b[i]);
      for (int i=0; i<ts1.length; i++)
	System.out.println("i="+i+" ts1[i]="+ts1[i]+" ts2[i]="+ts2[i]);
      /* Atribuim o alte valori lui b[0] si b[1], apoi afisam tablourile a si b
      */
      b[0]=-12.7; b[1]=283.6;
      System.out.println("Dupa ce s-au dat valori noi componentelor lui b:");
      for (int i=0; i<a.length; i++)
      	System.out.println("i="+i+" a[i]="+a[i]+" b[i]="+b[i]);
      /* Atribuim variabilei b o referinta la un nou tablou. Constatam ca
         valorile componentelor noului tablou sunt nule          
      */
      b=new double[4];
      System.out.println("Dupa atribuirea unui nou tablou, b[] indica:");
      for (int i=0; i<b.length; i++) System.out.print(b[i]+" ");
      System.out.println();
      /* Atribuim valori componentelor noului tablou indicat de b[] si
         le afisam
      */
      for (int i=0; i<b.length; i++) b[i]=Math.cos(0.7*i+0.23);
      System.out.println("Noul tablou b dupa atribuirea de valori:");
      for(int i=0; i<b.length; i++) System.out.print(b[i]+" ");
      System.out.println("\nTabloul a[] a ramas neschimbat:");
      for (int i=0; i<a.length; i++) System.out.print(a[i]+" ");
      System.out.println();
      /* Testam si ce se intampla daca incercam sa folosim o un indice care
         iese din domeniul tabloului
      */
      try {
	System.out.println(b[5]);
      } catch (Exception e) {
          System.out.println("S-a produs exceptia:\n"+e);
      }
      System.out.println("Programul s-a incheiat normal");
   }
}

