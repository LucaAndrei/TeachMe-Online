/* Testarea clasei Object */
import java.util.*;

class TestObject {
   public static void main(String argv[]) {
      Object ob1=new Object(), ob2=new String("ABCD"), ob3="abcd", ob4=ob2;
      Object ob5=new Object(), ob6=ob5;
      String str1="ABCD", str2=str1;
      System.out.println("ob1="+ob1);
      System.out.println("ob2="+ob2);
      System.out.println("ob3="+ob3);
      System.out.println("str1="+str1);
      System.out.println("Coduri de dispersie:");
      System.out.println("ob1: "+ob1.hashCode());
      System.out.println("ob5: "+ob5.hashCode());
      System.out.println("ob2: "+ob2.hashCode());
      System.out.println("str1: "+str1.hashCode());
      System.out.println("ob4: "+ob4.hashCode());
      System.out.println("ob3: "+ob3.hashCode());
      System.out.println("Testarea egalitatii prin == si prin equals():");
      
      /* In clasa Obhect operatorul == si metoda equals() sunt echivalente */
      System.out.println("ob1==ob5: "+(ob1==ob5)+"  ob1.equals(ob5): "+
      		(ob1.equals(ob5)));
      System.out.println("ob5==ob6: "+(ob5==ob6)+"  ob5.equals(ob6): "+
      		(ob5.equals(ob6)));
      		
      /* Pentru obiecte din clasa String operatorul == testeaza egalitatea
         referintelor, in timp ce metoda equals() testeaza egalitatea
         continutului"
      */
      System.out.println("ob2==ob4: "+(ob2==ob4)+" ob2.equals(ob4): "+
      		(ob2.equals(ob4)));
      System.out.println("ob2==str1: "+(ob2==str1)+"  ob2.equals(str1): "+
      		(ob2.equals(str1)));
      System.out.println("ob2==ob3: "+(ob2==ob3)+"  ob2.equals(ob3): "+
      		(ob2.equals(ob3)));
      		
      /* Aplicarea metodei toString() obiectelor din clasa Object */
      System.out.println("Aplicarea metodei toString(): ");
      System.out.println("pentru ob1: "+ob1.toString());
      
      /* Aplicarea metodei toString() obiectelor din clasa String intoarce
      chiar sirul pe care acestea il contin
      */ 
      System.out.println("pentru ob2: "+ob2.toString());
      System.out.println("pentru ob3: "+ob3.toString());
      System.out.println("pentru str1: "+str1.toString());
      
      /* De altfel, daca un obiect apare ca argument in metoda print() sau
         println(), aplicarea conversia lui in sir (deci aplicarea metodei
         toString() se face in mod implicit 
      */
      System.out.println("Aceleasi afisari, cu conversii in sir implicite:");
      System.out.println(ob1);
      System.out.println(ob2);
      System.out.println(ob3);
      System.out.println(str1);
      
      /* Unei variabile din clasa Object i se poate atribui o referinta la un 
	 obiect din clasa String, deci instructiunea urmatoare nu produce o
	 eroare de compilare
      */
      ob1=str2;
      
      /* Unei variabile din clasa String nu i se poate atribui o referinta 
	 la un obiect din clasa Object. In consecinta, daca se elimina // din
	 linia de program urmatoare, apare o eroare la compilare
      */
      // str1=ob2;
      /* Daca insa suntem siguri ca variabila ob2 din clasa Object contine in
         realitate o referinta la un obiect din clasa String (asa cum este
         cazul in situatia de fata) putem cere o conversie explicita de la
         Object la String. Din aceasta cauza, instructiunea urmatoare nu mai
         constituie o eroare
      */
      str1=(String)ob2;
      
      /* Aplicarea metodei getClass() */
      System.out.println("Informatii despre clase: ");
      System.out.println("ob5: "+ob5.getClass());
      System.out.println("ob2: "+ob2.getClass());
      System.out.println("str1: "+str1.getClass());
   }
}

