/* Conversii de tip la atribuiri de referinte la tablouri unidimensionale */

class ConvTip1 {
   public static void main(String args[]) {
      int a[]={54, 23, -17}, b[];
      double u[]={-6.237429, 83.17026}, v[];
      String str1[]={"abc","def"}, str2[], str3[];
      Object ob1, ob2, ob3, tob1[], tob2[];
      /* Atribuire permisa: Object este superclasa pentru String */
      tob1=str1;
      /* Instructiunea urmatoare nu este permisa, deoarece String nu este 
         superclasa a lui Object (puteti verifica suprimand // din fata ei)
      */
      // str2=tob1;
      /* Deoarece stim ca tob1[] contine o referinta la un tablou String,
         putem face o conversie explicita prin cast
      */
      str2=(String[])tob1;
      /* Tablourile a[] si u[] sunt considerate obiecte, deci variabilele
         bsimple din clasa Object pot primi ca valori referinte la astfel de
         tablouri
      */
      ob1=a;
      ob2=u;
      /* Chiar si un tablou de obiecte este considerat tot un obiect */
      ob3=str1;
      /* Atribuirile inverse nu sunt permise, deoarece clasele int[], double[]
         si String[] nu sunt superclase ale lui Object (puteti verifica!)
      */
      // b=ob1;
      // v=ob2;
      // str3=ob3;
      /* Avand in vedere ca stim ca atribuirile sunt corecte, ne putem 
         permite sa facem conversiile explicite prin cast
      */
      b=(int[])ob1;
      v=(double[])ob2;
      str3=(String[])ob3;
      /* Pentru a face diferite operatii cu componentele tablourilor referite
         de variabilele ob1, ob2 ob3 si tob1 sunt necesare, de asemenea,
         conversii explicite, deoarece ob1, ob2, ob3 nu sunt tablouri
      */
      System.out.println("Tabloul referit de ob1:");
      for (int i=0; i<((int[])ob1).length; i++)
         System.out.print(((int[])ob1)[i]+" ");
      System.out.println("\nTabloul referit de ob2: ");
      for (int j=0; j<((double[])ob2).length; j++)
         System.out.print(((double[])ob2)[j]+" ");
      System.out.println("\nTabloul referit de ob3:");
      for (int k=0; k<((String[])ob3).length; k++)
         System.out.print(((String[])ob3)[k]+"; ");
      System.out.println();
      /* Pentru afisarea elementelor lui tob1[] nu este nevoie de cast,
         deoarece acesta este tablou de componente din clasa Object care au ca
         valori referinte la String, iar Object este superclasa pentru String
      */
      System.out.println("Tabloul referit prin tob1[]:");
      for (int i=0; i<tob1.length; i++) System.out.print(tob1[i]+"; ");
      System.out.println();
      /* Atribuim valori unor componente ale acestor tablouri si le afisam */
      ((double[])ob2)[1]=12.7846e-8;
      ((String[])ob3)[0]="pqrst";
      System.out.println("Valori atribuite: "+((double[])ob2)[1]+"  "+
      		((String[])ob3)[0]);
      /* Afisam clasele carora le apartin unele din aceste tablouri */
      System.out.println("Clasa lui a[]: "+a.getClass().getName());
      System.out.println("Clasa lui u[]: "+u.getClass().getName());
      System.out.println("Clasa lui str1[]: "+str1.getClass().getName());
      System.out.println("Clasa lui ob1: "+ob1.getClass().getName());
      System.out.println("Clasa lui ob2: "+ob2.getClass().getName());
      System.out.println("Clasa lui ob3: "+ob3.getClass().getName());     
   }
}

