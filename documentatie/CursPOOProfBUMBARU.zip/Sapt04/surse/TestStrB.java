/* Testarea clasei StringBuffer */

class TestStrB {
   public static void main(String args[]) {
      StringBuffer stb1=new StringBuffer(), stb2;
      String str1="abcdefg", str2;
      double d=3.670283105E-3;
      char tc1[]={'A','B','C'}, tc2[]=new char[10];
      System.out.println("Lungimea si capacitatea initiala a stb1: "+
      	 stb1.length()+"  "+stb1.capacity());
      stb1.append(str1);
      stb1.append(d);
      System.out.println("stb1="+stb1+"\nLungime: "+stb1.length()+
      	 " Capacitate: "+stb1.capacity());
      str2=stb1.toString(); // Este obligatorie folosirea metodei toString()
      System.out.println("Caracterul de indice 3: "+stb1.charAt(3));
      stb2=stb1.insert(3, "PQRS");
      System.out.println("Dupa insertia sirului PQRS:\nstb1="+stb1+
      	 "\nstb2="+stb2);
      stb1.append(tc1);
      System.out.println("Dupa adaugarea tabloului tc1, stb1="+stb1);
      System.out.println("Lungime: "+stb1.length()+"  Capacitate: "+
         stb1.capacity());
      stb1.delete(3,25);
      System.out.println("Dupa eliminarea zonei 3..25: "+stb1);
      System.out.println("Lungime: "+stb1.length()+"  Capacitate: "+
         stb1.capacity());
      stb1.reverse();
      System.out.println("Dupa inversare stb1="+stb1);
      stb1.getChars(1,4,tc2,3);
      System.out.println("Dupa extragerea de caractere, lungimea "+
         "tabloului tc2: "+tc2.length);
      System.out.print("tc2=");
      for(int i=0; i<tc2.length; i++) System.out.print(tc2[i]);
      System.out.println();
   }
}


