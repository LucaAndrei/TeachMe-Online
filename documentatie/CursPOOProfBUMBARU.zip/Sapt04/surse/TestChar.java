/* Testarea clasei acoperitoare Character */

class TestChar {
   public static void main(String args[]) {
      Character c1=new Character('B'), c2=new Character('b'), c3;
      Object ob;
      c3=new Character('b');
      ob=c3;
      System.out.println("'x' este litera: "+Character.isLetter('x'));
      System.out.println("'3' este cifra: "+Character.isDigit('3'));
      System.out.println("'b' este litera mica: "+Character.isLowerCase('b'));
      System.out.println("'*' este litera mare: "+Character.isUpperCase('*'));
      System.out.println("'\\n' este Whitespace: "+
         Character.isWhitespace('\n'));
      System.out.println("'\\n' este SpaceChar: "+Character.isSpaceChar('\n'));
      System.out.println("'d' mare este: "+Character.toUpperCase('d'));
      System.out.println("In sistemul de numeratie cu baza 27 cifra 19 este: "+
      	Character.forDigit(19,27));
      System.out.println("In acelasi sistem, litera 'M' este cifra: "+
      	Character.digit('M',27));
      /* Testarea operatorului == si a metodei equals() */
      System.out.println("c2==c3: "+(c2==c3));
      System.out.println("ob==c3: "+(ob==c3));
      System.out.println("c2 identic cu c3: "+c2.equals(c3));
      System.out.println("c2 identic cu ob: "+c2.equals(ob));
      System.out.println("c1 identic cu ob: "+c1.equals(ob));
      /* Testarea metodei hashCode() */
      System.out.println("Coduri de dispersie pentru c1, c2, c3 si ob:\n"+
      	c1.hashCode()+" "+c2.hashCode()+" "+c3.hashCode()+" "+
      	ob.hashCode());
   }
}

