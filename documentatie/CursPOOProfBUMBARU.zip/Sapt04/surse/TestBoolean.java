/* Testarea clasei acoperitoare Boolean */

class TestBoolean {
   public static void main(String args[]) {
      boolean b1=true, b2=false, b3, b4;
      Boolean bc1, bc2, bc3=Boolean.TRUE, bc4=Boolean.FALSE, bc5, bc6;
      boolean tb1[]={true, false, true}, tb2[][]={{true,false},{false,true}};
      Boolean tcb1[]={Boolean.TRUE,Boolean.FALSE};
      Boolean tcb2[][]={{Boolean.FALSE,Boolean.TRUE},
		{Boolean.TRUE,Boolean.FALSE}};
      String str1, str2;
      /* Se aplica constructorul Boolean(boolean value) */
      bc1=new Boolean(b1);
      bc2=new Boolean(b2);
      /* Se afiseaza valorile variabilelor bc1 si bc2 convertite in siruri 
         (amintim ca in argumentele metodelor print() si println() aplicarea
         metodei toString() este implicita)
      */
      System.out.println("bc1="+bc1+" bc2="+bc2);
      /* Se afiseaza tablourile cu componente de tip primitiv boolean */
      System.out.println("Tabloul tb1: ");
      for (int i=0; i<tb1.length; i++) System.out.print(tb1[i]+" ");
      System.out.println("\nTabloul bidimensional tb2: ");
      for (int i=0; i<tb2.length; i++) {
         for (int j=0; j<tb2[i].length; j++)
            System.out.print(tb2[i][j]+" ");
         System.out.println();
      }
      /* Se afiseaza tablourile cu componente din clasa Boolean */
      System.out.println("Tabloul tcb1: ");
      for (int i=0; i<tcb1.length; i++) System.out.print(tcb1[i]+" ");
      System.out.println("\nTabloul bidimensional tcb2: ");
      for (int i=0; i<tcb2.length; i++) {
         for (int j=0; j<tcb2[i].length; j++)
            System.out.print(tcb2[i][j]+" ");
         System.out.println();
      }
      /* Afisarea valorii variabilei finale statice TYPE */
      System.out.println("Clasa primitiva acoperita de bc1: "+bc1.TYPE);
      /* Aplicarea metodei getClass mostenite de la clasa Object */
      System.out.println("Clasa obiectului bc1: "+bc1.getClass());
      /* Afisarea valorilor variabilelor bc3 si bc4 convertite la sir */
      System.out.println("bc3="+bc3+" bc4="+bc4);
      /* Compararea obiectelor prin operatorul == si prin metoda equals().
         Se obtin rezultate diferite, deoarece operatorul == compara
         referintele (iar obiectele bc1 si bc3 au adrese diferite in memorie)
         in timp ce metoda equals() compara obiectele insesi, iar in cazul
         de fata ambele contin intern valoarea primitiva true 
      */
      System.out.println("bc1==bc3: "+(bc1==bc3)+"    bc1.equals(bc3): "
      		+ bc1.equals(bc3));
      /* Aplicarea metodei hashCode(). Remarcam ca pentru obiecte identice
         se obtin coduri de dispersie identice
      */
      System.out.println("Coduri de dispersie: ");
      System.out.println("bc1: "+bc1.hashCode()+"   bc3: "+bc3.hashCode());
      System.out.println("bc2: "+bc2.hashCode()+"   bc4: "+bc4.hashCode());
      /* Testarea metodei booleanValue() (care intoarce o valoare primitiva
         de tip boolean)
      */
      b3=bc1.booleanValue(); b4=bc2.booleanValue();
      /* Testarea constructorului Boolean(String s) pentru cazul cand are
         ca argument sirul "true". Se observa ca nu conteaza daca literele
         sunt mari sau mici.
      */
      bc5=new Boolean("True");
      bc6=new Boolean("TrUe");
      System.out.println("bc5="+bc5+" bc6="+bc6);
      /* Testarea pentru cazul cand argumentul nu este sirul "true" */
      bc5=new Boolean("adevarat");
      bc6=new Boolean("fals");
      System.out.println("bc5="+bc5+" bc6="+bc6);
      /* Testarea faptului ca aceleasi rezultate se obtin aplicand metoda 
         public static Boolean valueOf(String s)
      */
      bc5=Boolean.valueOf("TruE");
      bc6=Boolean.valueOf("un sir");
      System.out.println("Aplicand metoda valueOf(): bc5="+bc5+"  bc6="+bc6);
      /* Se testeaza metoda toString() */
      /* Atribuirea din linia urmatoare nu este permisa (incercati sa
         suprimati simbolul de comentariu //)
      */
      // str1=bc1;
      /* Atribuirile urmatoare sunt permise, caci metoda toString intoarce 
         un sir
      */
      str1=bc1.toString();
      str2=tcb2[1][0].toString();
      System.out.println("str1="+str1+"  str2="+str2);
   }
}

