/* Calcularea sumei unei serii convergente folosind ciclul 
   cu test final
*/

class Serie2 {
   public static void main(String argv[]) {
      /* Se declara si se initializeaza variabilele din program */
      double x=1.30726, S=0, t=1;
      int k=0;
      /* Se calculeaza suma S a seriei */
      do {
         S+=t; // Se adauga termenul curent la suma partiala anterioara
         k++;  // Se trece la indicele termenului urmator
         t*=x/k; // Se calculeaza valoarea termenului urmator
      } while (S+t!=S);
      /* Se afiseaza rezultatul */
      System.out.println("Suma seriei este "+S);
      /* Avand in vedere ca suma S calculata mai sus este dezvoltarea
      	 in serie Taylor a functiei matematice exponentiale exp(x), 
      	 pentru comparatie afisam si valoarea acestei functii
     */
      System.out.println("Pentru comparatie: "+Math.exp(x));
   }
}

