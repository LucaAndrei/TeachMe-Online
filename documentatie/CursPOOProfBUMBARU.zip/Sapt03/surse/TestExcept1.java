/* Exemplu de aparitie a unei exceptii */

class TestExcept1 {
   public static void main(String argv[]) {
      int a=7, b=0, x;
      System.out.println("Urmeaza o exceptie de impartire la zero");
      x=a/b;
      System.out.println("S-a depasit locul de aparitie a exceptiei");
   }
}

