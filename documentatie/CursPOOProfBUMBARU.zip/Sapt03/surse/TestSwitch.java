/* Testarea instructiunii switch */

class TestSwitch {
  public static void main(String args[]) {
    int a=7;
    char c='@';
    double u=15.3782;
    System.out.println("Switch fara break si cu cazuri vide");
    switch(a) {
      case 143: u++;
                System.out.println("A "+u);
      case 2:   u+=a;
                System.out.println("B "+u);
      case 7:   u--;
                System.out.println("C "+u);
      case '@':
      case 148:
      case 15:
      case -87: u-=a;
		System.out.println("D "+u);
      case -12: u*=a;
		System.out.println("E "+u);
      case 'F': u%=a;
                System.out.println("F "+u);
      default:  u=15.3782;
                System.out.println("G "+u);
    }
    System.out.println("Switch cu break dupa fiecare caz nevid");
    switch(c) {
      case 143: u++;
                System.out.println("A "+u);
		break;
      case 2:   u+=a;
                System.out.println("B "+u);
		break;
      case 7:   u--;
                System.out.println("C "+u);
		break;
      case '@':
      case 148:
      case 15:
      case 87: u-=a;
		System.out.println("D "+u);
		break;
      case 12: u*=a;
		System.out.println("E "+u);
		break;
      case 'F': u%=a;
                System.out.println("F "+u);
		break;
      default:  u=15.3782;
                System.out.println("G "+u);
    }

  }
}