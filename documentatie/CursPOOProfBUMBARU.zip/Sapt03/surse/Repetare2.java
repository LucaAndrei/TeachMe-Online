/* Calcularea repetata a unei expresii pentru diferite valori ale lui k 
   folosind ciclul cu test final
*/

class Repetare2 {
   public static void main(String argv[]) {
      /* Se declara si initializeaza variabilele */
      int k, n=12;
      
      /* Se calculeaza si afiseaza in mod repetat valoarea expresiei */
      k=0;
      do {
         System.out.println("Pentru k="+k+" Valoarea expresiei este "+
            2*Math.exp(-0.35*k)*Math.sin(0.17*k-0.08));
         k++; // se trece la valoarea urmatoare a lui k
      } while (k<=n);
   }
}

