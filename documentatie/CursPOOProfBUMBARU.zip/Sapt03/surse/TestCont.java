/* Testarea instructiunii continue */

class TestCont {
   public static void main(String argv[]) {
      double a=3.25, x=1.17, s, t;
      int k;
      
      /* Folosirea instructiunii continue fara eticheta */
      System.out.println("Testul 1");
      s=0;
      for(k=0; k<20; k++) {
         x*=a;
         s+=x;
         if(k<16) continue;
         System.out.println("k="+k+" x="+x+" s="+s);
      }
      
          	      
      /* Instructiunea continue care contine o eticheta produce trecerea
      fortata la sfarsitul corpului ciclului care poarta eticheta respectiva
      si continuarea acestui ciclu cat timp este satisfacuta conditia sa */
      
      System.out.println("\nTestul 2");
      ciclu1: for(int i=0; i<6; i++) {
      		 System.out.println("Control 1: i="+i);
      		 for(int j=3; j>0; j--) {
      		    System.out.println("Control 2: i="+i+" j="+j);
      		    if(i>1 && i<5) continue ciclu1;
      		    System.out.println("Control 3: i="+i+" j="+j);
      		 } // Sfarsitul ciclului interior
      	         System.out.println("Control 4: i="+i);
      	      }  // Sfarsitul ciclului exterior
   }
}
  
