/* Testarea instructiunii for */

class TestFor {
   public static void main(String arg[]) {
      int k, n=9;
      double a=2.7465,P;
      
      /* Diferite forme ale instructiunii for pentru realizarea urmatorului
        program scris in pseudocod:
      	  P=1;
      	  pentru k de_la 5 la n executa
      	     P=P*(a+k)
      	  sfarsit_ciclu
      */
      
      /* Forma de baza */
      for(P=1,k=5; k<=n; k++)
      	P*=a+k;
      System.out.println("P="+P);
      
      /* Varianta (a), in care initializarea se face inainte de 
         instructiunea for, iar pregatirea pasului parcurgerii
         urmatoare se face in corpul ciclului. Atentie: intre
         parantezele lui for s-au mentinut separatorii';'
      */
      P=1; k=5;
      for(;k<=n;){
      	P*=a+k;
      	k++;
      }
      System.out.println("In varianta (a) P="+P);
      
      /* Varianta (b), in care s-a suprimat corpul ciclului, trecand
         instructiunea respectiva in zona de pregatire a parcurgerii
         urmatoare; corpul ciclului este acum instructiunea vida
      */
      for(P=1,k=5;k<=n;P*=a+k,k++);
      System.out.println("In varianta (b) P="+P);
      
      /* Variabila "contor al ciclului" poate fi si de tip real
         si cresterea ei la fiecera parcurgere a ciclului poate
         fi de asemenea de tip real
      */
      double v,S;
      for(S=0, v=2.75; v<12; v+=0.12876)
      	S+=2*v;
      System.out.println("S="+S);
      
      /* Pasul de variatie al "contorului" poate sa nu fie constant */
      for(S=2.87,v=12;v>0.005;v/=2.53)
      	S+=v;
      System.out.println("S="+S);
   }
}

