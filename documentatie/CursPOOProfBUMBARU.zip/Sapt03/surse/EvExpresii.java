/* Evaluarea expresiilor */

class EvExpresii {
  public static void main(String args[]) {
    int a=23, b=500, c=17, d=0;
    System.out.println((a+b*c)+" "+((a+b)*c)+" "+(b/a*c)+
	" "+(b/(a*c)));
    System.out.println((-a+b*c++/3+(d=c--%4))+" "+c+" "+d);
    System.out.println((d<1 && c--==0)+" "+c+" "+d);
    System.out.println((d<1 & ++d<c)+" "+c+" "+d);
  }
}
