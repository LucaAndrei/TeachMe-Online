/* Testarea expresiei conditionale */ 
class ExprCond { 
  public static void main(String args[]) { 
    int m=17, n=-6, p=0, q=0; 
    System.out.println(m>n ? m+1 : 2*n-2); 
    System.out.println(m<=n ? 3*m : m-n); 
    /* Se evalueaza numai operandul 2 */ 
    System.out.println((m>=6 ? ++p*n : ++q-m)+" "+p+" "+q); 
    /* Se evalueaza numai operandul 3 */ 
    System.out.println((m<n+3 ?  m-- : n++)+" "+m+" "+n); 
    /* Un exemplu in care operanzii 2 si 3 sunt tot expresii  
       conditionale 
    */ 
    System.out.println(m>p ? (n<0? m+1 : m-2) : (m>n ? m : n)); 
  } 
}
