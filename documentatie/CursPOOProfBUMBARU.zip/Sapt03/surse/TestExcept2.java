/* Exemplu de aparitie a unei exceptii folosind instructiunea try */

class TestExcept2 {
   public static void main(String argv[]) {
      int a=7, b=0, x;
      try {
      	    System.out.println("Urmeaza o exceptie de impartire la zero");
            x=a/b;
            System.out.println("S-a depasit locul de aparitie a exceptiei");
          } catch (ArithmeticException e1) {
              System.out.println("S-a captat exceptia aritmetica:\n"+e1);
          } catch (Exception e2) {
              System.out.println("S-a captat exceptia:\n"+e2);
          }
      System.out.println("S-a trecut de instructiunea try");
      System.out.println("Sfarsit normal al programului");
   }
}

