/* Testarea deosebirii dintre ciclurile cu test initial si cu 
   test final
*/

class DeosCicluri {
   public static void main(String argv[]) {
      int k=7;
      /* Situatia cand corpul ciclului cu test initial nu se executa
         nici o data
      */
      while (k<0)
         System.out.println("Aceast text nu trebuie sa se afiseze!");
         
      /* Situatia similara, in care insa corpului cu test final se
      	 executa o singura data
      */
      do
      	System.out.println("Acest text trebuie sa se afiseze o singura "
      		+"data");
      while (k<0);
      
      /* Incrementari succesive cu ciclu cu test initial */
      k=0;
      while (k<5){
        System.out.println("In ciclul cu test initial k="+k);
      	k++;
      }
      System.out.println("La iesirea din ciclul cu test initial k="+k);
      
      /* Incrementari succesive cu ciclu cu test final si aceeasi
      	 conditie de continuare a ciclului
      */
      k=0;
      do {
        System.out.println("In ciclul cu test final k="+k);
      	k++;
      } while (k<5);
      System.out.println("La iesirea din ciclul cu test final k="+k);
   }
}

         
