/* Exemplu de program care contine blocuri imbricate */

class Blocuri { // aici incepe corpul clasei Blocuri
  public static void main(String args[]) { // aici incepe blocul A
    int m=8, n=-3;
    double u=m*3.5+32, v=2, w;
    w=m*u+v;
    System.out.println("m="+m+" n="+n+" u="+u+" v="+v+" w="+w);
    m++;
    { // aici incepe blocul B, continut in A
      int a=5;
      double p=m*w-3.5, q;
      q=n*p-a; // s-a folosit n din blocul exterior
      { // aici incepe blocul C continut in B
        System.out.println("m="+m+" a="+a+" p="+p+" q="+q);
      } // aici se termina blocul C
    } // aici se termina blocul B
  } // aici se termina blocul A (corpul metodei main)
} // aici se incheie corpul clasei Blocuri