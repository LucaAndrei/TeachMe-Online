/* Calcularea unei sume folosind ciclul cu test final */

class Suma2 {
   public static void main(String argv[]) {
      int n=8, k;
      double a=0.72, b=-0.1735, S;
      
      /* Se calculeaza suma S */
      S=0; k=0; // Se dau valorile initiale lui S si k
      do {
        /* Se calculeaza termenul curent al sumei si se adauga la
           valoarea precedenta a lui S
        */
        S+=Math.sqrt(Math.pow(Math.sin(k*a+b),2)+
        	Math.pow(Math.cos(k*b-a),2));
        k++; // se trece la valoarea urmatoare a lui k
      } while (k<=n);
      
      /* Se afiseaza S */
      System.out.println("Suma calculata este "+S);
   }
}

        
      
      
