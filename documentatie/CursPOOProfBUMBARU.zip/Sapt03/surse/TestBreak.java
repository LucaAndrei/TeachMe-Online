/* Testarea instructiunii break */

class TestBreak {
   public static void main(String argv[]) {
      double x, y, a=3.27;
      
      /* Folosirea instructiunii break fara eticheta pentru iesirea
         din ciclul for (in acest exemplu, substituie conditia de iesire
	 din ciclu, care lipseste din for)
      */
      x=0; y=100;
      for(;;){
         x+=y;
         if(y<0.2) break;
         y/=a;
      }
      System.out.println("Testul 1: x="+x);
         
      /* Acelasi efect, in cazul instructiunii while */
      x=0; y=100;
      while(true){
         x+=y;
         if(y<0.2) break;
         y/=a;
      }
      System.out.println("Testul 2: x="+x);

      /* Folosirea unui break fara eticheta in ciclul interior (se 
         observa ca se iese fortat din acest ciclu, dar se reia
         ciclul exterior)
      */
      for(int k=0; k<=2; k++) {
         System.out.println("Control 1: k="+k);
         for(int i=0;i<=3; i++) {
            if(i>k) break;
            System.out.println("Control 2: k="+k+" i="+i);
         }
         System.out.println("Control 3: k="+k);
      }
      System.out.println("Control 4");
      
      /* Aceleasi doua cicluri ca in cazul precedent, dar se folo-
         seste o instructiune break cu trimitere la eticheta
         ciclului exterior. Se poate constata ca, in acest caz, la executarea
	 instructiunii break se iese din ambele cicluri.
      */
      ciclul1: for(int k=0; k<=2; k++) {
         System.out.println("Control 1a: k="+k);
         for(int i=0;i<=3; i++) {
            if(i>k) break ciclul1;
            System.out.println("Control 2a: k="+k+" i="+i);
         }
         System.out.println("Control 3a: k="+k);
      }
      System.out.println("Control 4a");
      
      /* Instructiunea break care contine o eticheta poate fi folosita si
         pentru a iesi din blocul care poarta eticheta respectiva. In cazul de
         fata, se iese din blocul cu eticheta bloc2
      */
      { System.out.println("Intrare in blocul exterior");
   	       int k=7;
   	  bloc2: { System.out.println("Intrare in blocul interior");
   	         if(k>0) break bloc2;
   	         System.out.println("Iesire din blocul interior");
   	       }
   	       System.out.println("Iesire din blocul exterior");
   	     }
      System.out.println("S-a iesit din ambele blocuri");

      /* Daca avem doua blocuri imbricate si dorim sa iesim din ambele, blocul
          exterior se eticheteaza, iar eticheta lui este pusa in break
      */
      bloc1: { System.out.println("Intrare in blocul exterior");
   	       int k=7;
   	       { System.out.println("Intrare in blocul interior");
   	         if(k>0) break bloc1;
   	         System.out.println("Iesire din blocul interior");
   	       }
   	       System.out.println("Iesire din blocul exterior");
   	     }
      System.out.println("S-a iesit din ambele blocuri");
   }
}

