/* Exemple de instructiuni simple */

class Instructiuni {
  public static void main(String args[]) {
    double a=3.76, b=-15, c=2*a-b, d, e; // declaratie de variabile
    d=3*a-7;  // instructiune de atribuire
    b++;  // instructiune de incrementare
    e=b-17; // instructiune de atribuire
     /* invocare de metoda */
    System.out.println("a="+a+" b="+b+" c="+c+" d="+d+" e="+e);
   }
}

    