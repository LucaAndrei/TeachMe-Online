/* Declararea unor variabile in zona de initializare a instructiunii 
   for
*/

class TestFor1 {
   public static void main(String argv[]) {
      int j=0, n=7;
      double x=0, a=1.2073;
      
      /* Variabila k este declarata si initializata in instructiunea for
      */
      for(int k=0; k<n; k++)
        x+=a*k;
      System.out.println("x="+x);
      
      /* Se declara in zona de initializare a instructiunii for
         doua variabile, care sunt apoi folosite in acesta 
         instructiune
      */
      x=0;
      for(int k=0,i=9; k<n; k++,i--)
        x+=(a+i)*k;
      System.out.println("x="+x);
      
      /* Daca incercam acum sa folosim variabilele k si i, declarate
         in instructiunea for, apare eroare de compilare,deoarece
         ele nu mai sunt vizibile (incercati sa suprimati // din
         fata instructiunii urmatoare, apoi sa compilati)
      */
      // System.out.println("k="+k+" i="+i);
      
      /* Aceste variabile pot fi insa declarate  din nou, chiar si 
         de alt tip
      */
      x=7.28;
      for(double k=8.76; k>0.28; k/=2.31) x+=k;
      System.out.println("x="+x);
      
      /* In schimb nu putem redeclara in instructiunea for variabila j,
         deoarece ea este deja declarata si este vizibila si in
         interiorul acestei instructiuni(incercati sa suprimati //
         din fata instructiunii urmatoare si sa compilati)
      */
      // for(int j=2; j<8; j++)x+=j;
   }
}
 
