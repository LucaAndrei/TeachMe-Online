/* Calcularea repetata a unei expresii pentru diferite valori ale lui k 
   folosind ciclul cu test initial
*/

class Repetare1 {
   public static void main(String argv[]) {
      /* Se declara si initializeaza variabilele */
      int k, n=12;
      
      /* Se calculeaza si afiseaza in mod repetat valoarea expresiei.
         Variabila k este declarata si initializata in for
      */
      k=0; // initializarea contorului ciclului
      while (k<=n) {
         System.out.println("Pentru k="+k+" Valoarea expresiei este "+
            2*Math.exp(-0.35*k)*Math.sin(0.17*k-0.08));
         k++; // Se pregateste trecerea la ciclul urmator
      } // Sfarsit ciclu
   }
}

