/* Testarea unei metode care genereaza exceptii.

   Lansarea in executie a aplicatiei se face prin comanda:
     java TestExceptie <numar_intreg>
   Daca <numar_intreg> este un numar intreg cuprins intre 0 si 12
   se afiseaza factorialul acestui numar. Altfel, se afiseaza un 
   mesaj de eroare
*/

class TestExceptie {

  /* O metoda in care se genereaza exceptii prin clauza throw */

  static int factorial(int n) throws Exception {
    if(n<0) throw new Exception("factorial: argument negativ n="+n);
    if(n>12) throw new Exception("factorial: argument prea mare: "+n);
    int fact=1;
    for(int k=1; k<=n; k++) fact*=k;
    return fact;
  }

  /* In metoda main se capteaza si trateaza exceptiile generate de
     metodele factorial si parseInt
  */
  public static void main(String args[]) {
    if(args.length==0) {
      System.out.println("Lipsa argument in linia de comanda");
      System.exit(1);
    }
    try {
      int n=Integer.parseInt(args[0]);
      int m=factorial(n);
      System.out.println("Factorialul lui "+n+" este "+m);
    }
    catch(Exception e) {
      System.out.println(e);
    }
  }
}
