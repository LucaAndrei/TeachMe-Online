/* Metode care au ca parametri si ca valori intoarse referinte
   la tablouri 
*/

class TestTab {
  
  static int[] alpha(int a[], double b[]) {
    System.out.print("La intrarea in metoda alpha\n Tabloul a: ");
    for(int i=0; i<a.length; i++) System.out.print(a[i]+" ");
    System.out.print("\nTabloul b: ");
    for(int i=0; i<b.length; i++) System.out.print(b[i]+" ");
    /* Se creaza tabloul c si se dau valori elementelor lui */
    int c[]=new int[4];
    for(int i=0; i<c.length; i++) c[i]=2*i+1;
    System.out.println("\nTabloul c alocat si initializat in aceasta "+
      "metoda:");
    for(int i=0; i<c.length; i++) System.out.print(c[i]+" ");
    /* Se modifica valorile primelor doua elemente ale tabloului b */
    b[0]=-777.77; b[1]=-999.99;
    /* Se creaza un nou tablou, iar referinta catre el se atribuie
       parametrului formal a:
    */
    a=new int[3];
    a[0]=1000; a[1]=1001; a[2]=1002;
    System.out.println("\nInainte de iesirea din metoda alpha:");
    System.out.print("Tabloul a: ");
    for(int i=0; i<a.length; i++) System.out.print(a[i]+" ");
    System.out.print("\nTabloul b: ");
    for(int i=0; i<b.length; i++) System.out.print(b[i]+" ");
    System.out.println();
    return c;
  }

  public static void main(String args[]) {
    int p[]={10, 11, 12, 13, 14}, q[];
    double w[]={1.1, 1.2, 1.3, 1.4, 1.5, 1.6};
    q=alpha(p,w);
    System.out.println("In main dupa revenirea din alpha:");
    System.out.print("Tabloul p: ");
    for(int i=0; i<p.length; i++) System.out.print(p[i]+" ");
    System.out.print("\nTabloul q: ");
    for(int i=0; i<q.length; i++) System.out.print(q[i]+" ");
    System.out.print("\nTabloul w: ");
    for(int i=0; i<w.length; i++) System.out.print(w[i]+" ");
    System.out.println();
  }
}
