class Persoana {
  protected String nume, prenume;
  protected int anNastere;

  Persoana(String nume, String prenume, int anNastere) {
    this.nume=nume;
    this.prenume=prenume;
    this.anNastere=anNastere;
  }

  String nume() { return nume; }

  String prenume() { return prenume; }

  int anNastere() { return anNastere; }

  public String toString() {
    return "[nume: "+nume+", prenume: "+prenume+", anul nasterii: "+
      anNastere+"]";
  }

  public int hashCode() {
    String str=nume+prenume;
    return str.hashCode();
  }

  public boolean equals(Object obj) {
    if(this==obj) return true; // obj este chiar acest obiect
    if(!obj.getClass().getName().equals("Persoana")) return false;
    Persoana p=(Persoana)obj; // conversie de la Object la Persoana
    if(nume.equals(p.nume())&&prenume.equals(p.prenume())&&
      anNastere==p.anNastere()) return true;
    return false;
  }
}
