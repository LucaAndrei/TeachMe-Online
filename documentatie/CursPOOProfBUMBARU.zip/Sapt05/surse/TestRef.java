/* Testarea unei metode care intoarce un sir */

class TestRef {

  static String metoda1() {
    String str=new String("un sir");
    System.out.println("In metoda1 str="+str);
    return str;
  }

  static void metoda2(String s) {
    String s1=new String("alt sir");
    s=s1;
    System.out.println("In metoda2 s="+s);
  }

  public static void main(String args[]) {
    String sir1=null, sir2=null;
    sir1=metoda1();
    metoda2(sir2);
    System.out.println("In main sir1="+sir1+"\nsir2="+sir2);
  }
}
  