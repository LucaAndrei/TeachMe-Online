/* Metode recursive si iterative  */

class Recursii {

   /* Metode recursive */
   public static long factorial(int n) throws Exception {
      if(n<0) throw new Exception("factorial(n): n<0");
      if(n==0) return 1;
      return n*factorial(n-1);
   }
   public static long fibonacci(int n) throws Exception {
      if(n<0) throw new Exception("fibonacci(n): n<0");
      if(n==0) return 0;
      if(n==1) return 1;
      return fibonacci(n-1)+fibonacci(n-2);
   }
   
   /* Metode mutual recursive: fct1() o invoca pe fct2() si reciproc */
   
   public static double fct1(int n, double x) throws Exception {
      if(n<0) throw new Exception("fct1: n<0");
      return 2*fct2(n, 0.4*x+0.3)+x;
   }
   public static double fct2(int n, double y) throws Exception {
      if(n<0) throw new Exception("fct2: n<0");
      if(n==0) return y;
      return y*fct1(n-1, 1.27*y-0.89)-1;
   }
}

class Iteratii {
   public static long factorial(int n) throws Exception {
      long fact;
      if(n<0) throw new Exception("factorial(n): n<0");
      fact=1;
      for(int i=2; i<=n; i++) fact*=i;
      return fact;
   }
   public static long fibonacci(int n) throws Exception {
      if(n<0) throw new Exception("fibonacci(n): n<0");
      if(n==0) return 0;
      if(n==1) return 1;
      long a=0, b=1;
      for(int i=2; i<=n; i++) {
         b+=a;
         a=b-a;
      }
      return b;
   }
}

/* Aplicatia TestRecursii pentru testarea claselor Recursii si Iteratii.
   Se pune in executie dand ca parametru in linia de comanda numarul al carui
   factorial se calculeaza 
*/

class TestRecursii {
   public static void main(String args[]) {
      int n;
      if(args.length==0) {
         System.out.println("Nu ati dat ca parametru un numar intreg");
         System.exit(1);
      }
      n=Integer.parseInt(args[0]);
      try {
         long fact1, fact2, fib1, fib2;
         long time1, time2;
         
         /* Testarea functiilor mutual recursive fct1() si fct2() */
         System.out.println("fct1("+n+", 1.76)="+Recursii.fct1(n,1.76));
         System.out.println("fct2("+n+", 1.76)="+Recursii.fct2(n,1.76));
         
         /* Calcularea factorialului prin functie recursiva */
         time1=System.currentTimeMillis();
         fact1=Recursii.factorial(n);
         time2=System.currentTimeMillis();
         System.out.println("Recursiv factorial("+n+")="+fact1+
         	" durata: "+(time2-time1));
         
         /* Calcularea iterativa a factorialului */
         time1=System.currentTimeMillis();
         fact2=Iteratii.factorial(n);
         time2=System.currentTimeMillis();
         System.out.println("Iterativ factorial("+n+")="+fact2+
         	" durata: "+(time2-time1));
         
         /* Calcularea recursiva a numarului lui Fibonacci */
         time1=System.currentTimeMillis();
         fib1=Recursii.fibonacci(n);
         time2=System.currentTimeMillis();
         System.out.println("Recursiv fibonacci("+n+")="+fib1+
         	" durata: "+(time2-time1));
         
         /* Calcularea iterativa a numarului lui Fibonacci */
         time1=System.currentTimeMillis();
         fib2=Iteratii.fibonacci(n);
         time2=System.currentTimeMillis();
         System.out.println("Iterativ fibonacci("+n+")="+fib2+
         	" durata: "+(time2-time1));
         
         /* Calcularea numarului lui Fibonacci pentru n=35 */
         n=35;
         time1=System.currentTimeMillis();
         fib1=Recursii.fibonacci(n);
         time2=System.currentTimeMillis();
         System.out.println("Recursiv fibonacci("+n+")="+fib1+
         	" durata: "+(time2-time1));
         time1=System.currentTimeMillis();
         fib2=Iteratii.fibonacci(n);
         time2=System.currentTimeMillis();
         System.out.println("Iterativ fibonacci("+n+")="+fib2+
         	" durata: "+(time2-time1));
      }
      catch(Exception e) {
         System.out.println("Eroare in date: "+e);
      }
   }
}

