/* Declararea clasei Proba1
   Clasa contine numai campuri de date
*/

class Proba1 {
  static int m=9, n=m-3;
  int a=7, b=m*a+1, c, d;
  char c1='@', c2;
  String s1="un sir", s2=s1+" extins", s3;
}


/* Programul in care se utilizeaza clasa Proba1 ca o structura
   obisnuita
*/

class TestClasa1 {
  public static void main(String args[]) {
    /* Se declara doua referinte catre instante ale clasei Proba1,
       iar prima din ele se si initializeaza
    */
    Proba1 p1=new Proba1(), p2;
    /* Se mai creaza o instanta si se atribuie lui p2
    */
    p2=new Proba1();
    /* Se afiseaza unele campuri ale instantelor p1 si p2; */
    System.out.println("Campuri din p1: n="+p1.n+" m="+p1.m+" a="+
      p1.a+" b="+p1.b+" c="+p1.c+" c1="+p1.c1+" c2="+p1.c2+
      "  (int)p1.c2="+(int)p1.c2);
    System.out.println("Campuri din p2: n="+p2.n+" m="+p2.m+" a="+
      p2.a+" b="+p2.b+" c="+p2.c+"\n s1="+p2.s1+" s2="+p2.s2+
      " s3="+p2.s3);
    /* Afisarea campurilor statice calificandu-le cu numele clasei */
    System.out.println("Afisarea campurilor statice: m="+Proba1.m+
      " n="+Proba1.n);
    /* Modificam atribuim p1.a si p2.a valori diferite, apoi reafisam
       toate campurile
    */
    p1.a=12; p2.a=-9;
    System.out.println("Dupa modificarea valorilor campurilor a:");
    System.out.println("Campuri din p1: n="+p1.n+" m="+p1.m+" a="+
      p1.a+" b="+p1.b+" c="+p1.c);
    System.out.println("Campuri din p2: n="+p2.n+" m="+p2.m+" a="+
      p2.a+" b="+p2.b+" c="+p2.c);
    /* Modificam campul static p1.m si reafisam p1.m, p2.m si Proba1.m
    */
    p1.m=-12;
    System.out.println("Dupa modificare: p1.m="+p1.m+"  p2.m="+p2.m+
      "  Proba1.m="+Proba1.m);
    /* Modificam campul static n folosind expresia Proba1.n si afisam
    */
    Proba1.n=-25;
    System.out.println("Dupa modificare: p1.n="+p1.n+"  p2.n="+p2.n+
      "  Proba1.n="+Proba1.n);
    /* Atribuim o valoare campului de instanta p1.c */
    p1.c=1234;
    System.out.println("Dupa atribuire: p1.c="+p1.c+"  p2.c="+p2.c);
  }
}
