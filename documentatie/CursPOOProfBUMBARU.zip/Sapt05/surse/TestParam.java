/* Testarea modului de transmitere a parametrilor catre metode */

/* O clasa oarecare, continand un camp a */
class Proba2 {
  int a;
}

class TestParam {
  /* O metoda in care se modifica valorile propriilor parametri formali
  */
  static void modParam(int k, Proba2 p1, Proba2 p2) {
    System.out.println("La intrarea in modParam k="+k+" p1.a="+p1.a+
      " p2.a="+p2.a);
    k=-111; // S-a modificat valoarea parametrului k de tip int
    p1.a=-222; // S-a modificat valoarea unui camp al obiectului cu 
               // referinta p1, dar nu insasi referinta p1
    p2=new Proba2(); // S-a modificat insasi referinta p2, catre 
                     // o noua instanta a clasei Proba2
    p2.a=-333;       // S-a atribuit valoare campului a al noii 
                     // instante referite prin p2
    System.out.println("In modParam dupa modificarile de parametri:\n"+
      "k="+k+" p1.a="+p1.a+" p2.a="+p2.a);
  }

  /* Metoda principala */
  public static void main(String args[]) {
    // Se declara si se initializeaza variabilele
    int m=123;
    Proba2 pr1=new Proba2(), pr2=new Proba2();
    pr1.a=333; pr2.a=444;
    System.out.println("In main inainte de a invoca modParam:\n"+
      "m="+m+" pr1.a="+pr1.a+" pr2.a="+pr2.a);
    // Se invoca metoda modParam
    modParam(m, pr1, pr2);
    // Se afiseaza valorile parametrilor dupa revenirea din modParam
    System.out.println("In main dupa ce s-a invocat modParam:\n"+
      "m="+m+" pr1.a="+pr1.a+" pr2.a="+pr2.a);
  }
}
    