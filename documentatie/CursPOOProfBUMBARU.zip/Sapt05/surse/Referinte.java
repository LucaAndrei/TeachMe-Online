/* Utilizarea constructorilor si operatorului new */

class Referinte {
   public static void main(String argv[]) {
      String a="un sir", b=new String(a), c, d, e;
      c=new String(b);
      d=b;
      e=c;
      System.out.println("a="+a+" b="+b+" c="+c);
      System.out.println("d="+d+" e="+e);
      
      /* Se modifica acum valoarea lui b, construind un nou obiect, si 
         se reafiseaza obiectele spre care fac referinte toate variabilele
      */
      b=new String("alt sir");
      System.out.println("Dupa atribuirea unei noi valori lui b:");
      System.out.println("a="+a+" b="+b+" c="+c);
      System.out.println("d="+d+" e="+e);
      
      /* Se mai fac acum si alte atribuiri */
      e=b;
      a="sir nou";
      c=new String(a);
      System.out.println("Dupa atribuirea de valori noi lui e, a si c:");
      System.out.println("a="+a+" b="+b+" c="+c);
      System.out.println("d="+d+" e="+e);
   }
}

