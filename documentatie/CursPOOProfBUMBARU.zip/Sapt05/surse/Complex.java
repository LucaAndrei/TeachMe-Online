/* Clasa numerelor complexe */

public class Complex {
  private double re; // partea reala
  private double im; // partea imaginara

  /* Constructori */

  public Complex() {
    re=0; im=0;
  }

  public Complex(double parteaReala) {
    re=parteaReala; im=0;
  }

  public Complex(double parteaReala, double parteaImaginara) {
    re=parteaReala;
    im=parteaImaginara;
  }

  public Complex(Complex z) {
    re=z.re; im=z.im;
  }

  /* Metode */

  public double real() { // intoarce partea reala
    return re;
  }

  public double imag() { // intoarce partea imaginara
    return im;
  }

  public double modul() {  // intoarce modulul numarului complex
    return Math.sqrt(re*re+im*im);
  }

  public double arg() { // intoarce argumentul numarului complex
    return Math.atan2(im,re);
  }

  public static Complex complex(double modul, double argument)
      throws Exception {
    if(modul<0) throw new Exception("Complex: modul negativ: "+modul);
    Complex z=new Complex();
    z.re=modul*Math.cos(argument);
    z.im=modul*Math.sin(argument);
    return z;
  }

  public Complex plus(Complex a) {
    Complex z=new Complex();
    z.re=re+a.re;
    z.im=im+a.im;
    return z;
  }

  public Complex plus(double d) {
    return new Complex(re+d, im);
  }

  public static Complex plus(double d, Complex z) {
    return new Complex(d+z.re, z.im);
  }

  public Complex minus(Complex a) {
    Complex z=new Complex();
    z.re=re-a.re;
    z.im=im-a.im;
    return z;
  }

  public Complex minus(double d) {
    return new Complex(re-d, im);
  }

  public static Complex minus(double d, Complex z) {
    return new Complex(d-z.re, -z.im);
  }



  public Complex inmultitCu(Complex a) {
    Complex z=new Complex();
    z.re=re*a.re-im*a.im;
    z.im=re*a.im+im*a.re;
    return z;
  }

  public Complex inmultitCu(double d) {
    return new Complex(re*d, im*d);
  }

  public static Complex inmultitCu(double d, Complex z) {
    return new Complex(d*z.re, d*z.im);
  }

  public Complex impartitLa(Complex a) throws Exception {
    Complex z=new Complex();
    double w=a.re*a.re+a.im*a.im; // patratul modulului numitorului
    if(w==0) 
      throw new Exception("Complex impartitLa: impartire la zero");
    z.re=(re*a.re+im*a.im)/w;
    z.im=(im*a.re-re*a.im)/w;
    return z;
  }

  public Complex impartitLa(double d) throws Exception {
    if(d==0) 
      throw new Exception("Complex impartitLa: impartire la zero");
    return new Complex(re/d, im/d);
  }

  public static Complex impartitLa(double d, Complex z) 
      throws Exception {
    double w=z.re*z.re+z.im*z.im;
    if(w==0) 
      throw new Exception("Complex impartitLa: impartire la zero");
    return new Complex(d*z.re/w, -d*z.im/w);
  }

  public String toString() {
    StringBuffer b=new StringBuffer("("+re);
    if(im>=0) b.append('+');
    b.append(im+"*i)");
    return b.toString();
  }

  public boolean equals(Object obj) {
    if(this==obj) return true;
    if(getClass()!=obj.getClass()) return false;
    if(re==(((Complex)obj).re)&&(im==(((Complex)obj).im)))
       return true;
    return false;
  }

  public int hashCode() {
    return (int)(100000*modul()+100*arg());
  }
}

