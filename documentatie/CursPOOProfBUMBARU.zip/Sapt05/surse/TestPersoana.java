/* Testarea clasei Persoana */

class TestPersoana {
  public static void main(String args[]) {
    Persoana p1=new Persoana("Antoniu","Vasile",1981);
    Persoana p2, p3, p4, p5;
    String s1="Vasilescu", s2="Mihai";
    p2=new Persoana(s1, s2, 1980);
    p3=new Persoana(s1, "Ion", 1982);
    p4=new Persoana(s1, s2, 1980);
    p5=p1;
    System.out.println("p1=p5="+p1);
    System.out.println("p2="+p2);
    System.out.println("p4="+p4);
    System.out.println("Numele lui p3: "+p3.nume());
    System.out.println("p1==p5: "+(p1==p5)+"  p2==p4: "+(p2==p4));
    System.out.println("p1.equals(p5): "+p1.equals(p5)+
      " p2.equals(p4): "+p2.equals(p4));
    System.out.println("Coduri de dispersie pentru:\np1="+
      p1.hashCode()+" p2="+p2.hashCode()+" p3="+p3.hashCode()+
      "\np4="+p4.hashCode()+" p5="+p5.hashCode());
    
  }
}
