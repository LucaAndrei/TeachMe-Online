/* Testarea clasei Complex */

class TestComplex {
  public static void main(String args[]) {
    Complex u=new Complex(1,1), v=new Complex(1,-1), 
      w=new Complex(-1,1), z=new Complex(-1,-1);
    Complex x=new Complex(1,1), y;
    /* Testarea redefinirii metodei toString() din clasa Object */
    System.out.println("u="+u+" v="+v);
    /* Testarea redefinirii metodei equals din clasa Object */
    System.out.println("u==x: "+(u==x)+"  u.equals(x): "+u.equals(x));
    y=u;
    System.out.println("u==y: "+(u==y)+"  u.equals(y): "+u.equals(y));
    System.out.println("u==v: "+(u==v)+"  u.equals(v): "+u.equals(v));
    /* Testarea redefinirii metodei hashCode din clasa Object */
    System.out.println("Coduri de dispersie:");
    System.out.println("u: "+u.hashCode()+" v: "+v.hashCode()+
      " w: "+w.hashCode()+" z: "+z.hashCode());

    /* Testarea metodelor care intorc re, im, modul si argument */
    System.out.println("Pentru u: re="+u.real()+" im="+u.imag()+
      " modul="+u.modul()+" argument="+u.arg());
    System.out.println("Pentru v: re="+v.real()+" im="+v.imag()+
      " modul="+v.modul()+" argument="+v.arg());
    System.out.println("Pentru w: re="+w.real()+" im="+w.imag()+
      " modul="+w.modul()+" argument="+w.arg());
    System.out.println("Pentru z: re="+z.real()+" im="+z.imag()+
      " modul="+z.modul()+" argument="+z.arg());

    /* Testarea metodei statice complex */
    try {
      x=Complex.complex(1.0,0.5); // Se creeaza un nou numar complex 
                                  // cu modul 1 si argument 0.5
      System.out.println("Noua valoare a lui x: "+x);
      System.out.println("Modulul lui x: "+x.modul());
      System.out.println("Argumentul lui x: "+x.arg());
      y=Complex.complex(-1.0,1.2); // Gresit: modul negativ -1.0
    }
    catch(Exception e) {
      System.out.println(e);
    }

    /* Operatii intre numere complexe */
    Complex a=null, b=null, c=null, d=null;
    y=new Complex();
    try {
      a=u.plus(v);
      b=u.inmultitCu(v);
      c=u.impartitLa(v);
      d=b.minus(c);
      System.out.println("a="+a+" b="+b+"\nc="+c+" d="+d);
      d=u.impartitLa(y);
    }
    catch(Exception e) {
      System.out.println("impartire complex la complex nul:");
      System.out.println(e);
    }

    /* Operatii intre un numar complex si unul real */
    try {
      a=u.plus(2.5);
      b=u.inmultitCu(3.0);
      c=u.impartitLa(2.0);
      d=u.minus(4.5);
      System.out.println("a="+a+" b="+b+"\nc="+c+" d="+d);
      d=u.impartitLa(0.0);
    }
    catch(Exception e) {
      System.out.println("impartire complex la real nul:");
      System.out.println(e);
    }

    /* Operatii intre un numar real si unul complex */
    try {
      a=Complex.plus(2.5, u);
      b=Complex.inmultitCu(3.0, u);
      c=Complex.impartitLa(1.0,c);
      d=Complex.minus(4.5,u);
      System.out.println("a="+a+" b="+b+"\nc="+c+" d="+d);
      d=Complex.impartitLa(1.0,y);
    }
    catch(Exception e) {
      System.out.println("impartire real la complex nul:");
      System.out.println(e);
    }

    try {
      /* Calcularea expresiei (2*u+w-3)/v */
      a=(((Complex.inmultitCu(2,u)).plus(w)).minus(3)).impartitLa(v);
      System.out.println("Valoarea expresiei finale: "+a);

      /* Aceeasi expresie calculata pas cu pas */
      b=Complex.inmultitCu(2,u);
      c=b.plus(w);
      d=c.minus(3);
      a=d.impartitLa(v);
      System.out.println("Aceeasi valoare obtinuta pas cu pas: "+a);
    }
    catch(Exception e) {
      System.out.println("La calcularea expresiei finale:\n"+e);
    }
  }
}
