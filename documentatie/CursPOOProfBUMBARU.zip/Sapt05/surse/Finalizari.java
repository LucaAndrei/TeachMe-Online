class ProbaFinaliz {
  private int a;

  public ProbaFinaliz(int m) {
    a=m;
    System.out.println("S-a construit obiectul "+a);
  }
  
  protected void finalize() {
    System.out.println("Finalizarea obiectului "+a);
  }
  
}

class Finalizari {
  public static void main(String args[]) {
    ProbaFinaliz pf1=new ProbaFinaliz(1), pf2=new ProbaFinaliz(2);
    pf1=null;
    System.out.println("S-a anulat referinta pf1");
    pf2=null;
    System.out.println("S-a anulat referinta pf2");
    System.out.println("Se incheie executia aplicatiei");
  }
}
