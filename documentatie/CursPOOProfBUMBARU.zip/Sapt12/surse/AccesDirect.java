/* Crearea si utilizarea unui fisier cu acces direct */

import java.io.*;

class AccesDirect {
  public static void main(String args[]) throws IOException {
    /* Se deschide fisierul cu acces direct "Proba.fad" 
       in mod "rw" (citire si scriere)
    */
    RandomAccessFile fisier=new RandomAccessFile("Proba.fad","rw");
    long fp, fp1, fp2, k;
    int i;
    char c;
    float f;
    double d;
    String s;
    fp=fisier.getFilePointer();
    System.out.println("Pozitia initiala a cursorului: "+fp);
    /* Se scriu date in fisier incepand de la pozitia 0 */
    fisier.writeInt(-176534);
    fisier.writeDouble(176.5832987306);
    fisier.writeChar('#');
    fisier.writeUTF("Primul sir");
    /* Se memoreaza si se afiseaza pozitia curenta a cursorului de
       fisier
    */
    fp1=fisier.getFilePointer();
    System.out.println("Pozitia cursorului dupa prima scriere: "+fp1);
    /* Se scriu in continuare date in fisier */
    fisier.writeLong(157832490245L);
    fisier.writeFloat(0.05682369543f);
    fisier.writeBytes("Al doilea sir\n");
    fp2=fisier.getFilePointer();
    System.out.println("Pozitia cursorului dupa a doua scriere: "+fp2);
    /* Se deplaseaza cursorul de fisier pe pozitia de la care a inceput
       scrierea celei de a doua serii si se citesc datele in ordinea
       si sub forma in care au fost scrise, apoi se afiseaza
    */
    fisier.seek(fp1);
    k=fisier.readLong();
    f=fisier.readFloat();
    s=fisier.readLine();
    System.out.println("Date citite incepand de la pozitia: "+fp1);
    System.out.println(k+" "+f+" "+s);
    /* Se pozitioneaza cursorul la inceputul fisierului si se 
       citesc datele scrise in prima serie, apoi se afiseaza
    */
    fisier.seek(0);
    i=fisier.readInt();
    d=fisier.readDouble();
    c=fisier.readChar();
    s=fisier.readUTF();
    System.out.println("Date citite incepand de la pozitia 0:");
    System.out.println(i+" "+d+" "+c+" "+s);
    /* Se inchide fisierul */
    fisier.close();
    /* Se redeschide fisierul, se deplaseaza cursorul in pozitia
       de la care a inceput scrierea celei de a doua serii de date,
       se citesc datele respective si se afiseaza
    */
    fisier=new RandomAccessFile("Proba.fad","r");
    fisier.seek(fp1);
    System.out.println("Dupa redeschiderea fisierului s-au citit:");
    System.out.println(fisier.readLong()+" "+fisier.readFloat()+" "+
      fisier.readLine());
    /* Se inchide fisierul */
    fisier.close();
  }    
}
