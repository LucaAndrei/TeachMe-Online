/* Testarea clasei FileWriter.
   La lansarea in executie a programului se da un text oarecare in
   linia de comanda (sub forma java FileWriter <text>). Acest text va
   fi scris intr-un fisier cu numele "ProbaScriere.txt". Dupa ce se
   inchide fisierul, se redeschide pentru citire si se afiseaza pe
   ecran. Apoi se inchide si se redeschide pentru adaugare in coada.
   Se inchide si se redeschide pentru a citi si afisa noul continut
*/

import java.io.*;

class TestFileWriter {
  public static void main(String args[]) {
    FileWriter fout;
    FileReader fin;
    String str;
    int k;
    if(args.length==0) {
      System.out.println("La lansare dati un text in linia de comanda");
      System.exit(0);
    }
    try {
      /* Se deschide fisierul pentru scriere */
      fout=new FileWriter("ProbaScriere.txt");
      for(int i=0; i<args.length; i++) {
        fout.write(args[i]);
        fout.write(' ');
      }
      fout.close();
      /* Dupa ce a fost inchis, acelasi fisier se deschide pentru citire
      */
      fin=new FileReader("ProbaScriere.txt");
      /* Se afiseaza continutul fisierului */
      System.out.println("Fisierul contine:");
      while((k=fin.read()) != -1) System.out.print((char)k);
      System.out.println();
      fin.close();
      /* Se redeschide fisierul pentru scriere prin adaugare la coada */
      fout=new FileWriter("ProbaScriere.txt",true);
      /* Se scrie textul "\nText adaugat\n" */
      str="\nText adaugat\n";
      fout.write(str);
      fout.close();
      /* Se deschide din nou fisierul pentru citire si se afiseaza.
         De data aceasta, fin este fisierul din care se citeste, iar
         fout este un nou flux de iesire, care se conecteaza la
         iesirea standard al sistemului (la ecran) prin intermediul
         descriptorului FileDescriptor.out
      */
      fin=new FileReader("ProbaScriere.txt");
      System.out.println("\nA doua oara fisierul contine:");
      while((k=fin.read()) != -1) System.out.print((char)k);
      System.out.println();
      fin.close();
    }
    catch(Exception e) {
      System.out.println("Exceptie: "+e);
    }
  }
}
