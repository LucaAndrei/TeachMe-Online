import java.io.*;

class TestFile {
  public static void main(String args[]) throws Exception {
    /* Fisier situat in directorul curent */
    File fis1=new File("TestFile.java");
    System.out.println("Calea absoluta: "+fis1.getAbsolutePath());
    System.out.println("Fisierul exista: "+fis1.exists());
    System.out.println("Pot citi fisier: "+fis1.canRead());
    System.out.println("Pot scrie in fisier: "+fis1.canWrite());
    System.out.println("Calea: "+fis1.getPath());
    System.out.println("Parintele: "+fis1.getParent());
    System.out.println("Este director: "+fis1.isDirectory());
    System.out.println("Este fisier: "+fis1.isFile());
    System.out.println("Ultima modificare: "+fis1.lastModified());
    System.out.println("Lungimea fisierului: "+fis1.length());
    System.out.println("Sub foorma de URL: "+fis1.toURL());
    /* Director */
    File dir1=new File("../surse");
    System.out.println("Calea absoluta: "+dir1.getAbsolutePath());
    System.out.println("Exista: "+dir1.exists());
    System.out.println("Este director: "+dir1.isDirectory());
    System.out.println("Se poate citi: "+dir1.canRead());
    System.out.println("Se poate scrie: "+dir1.canWrite());
    /* Fisier situat in alt director */
    File fis2=new File("../surse/TestStudent.java");
    System.out.println("Calea absoluta: "+fis2.getAbsolutePath());
    System.out.println("Exista: "+fis2.exists());
    System.out.println("Este director: "+fis2.isDirectory());
    System.out.println("Se poate citi: "+fis2.canRead());
    System.out.println("Se poate scrie: "+fis2.canWrite());
    System.out.println("Parintele: "+fis2.getParent());
  }
}
