/* Testarea clasei FileOutputStream.
   La lansarea in executie a programului se da un text oarecare in
   linia de comanda (sub forma java FileOutput <text>). Acest text va
   fi scris intr-un fisier cu numele "ProbaScriere.txt". Dupa ce se
   inchide fisierul, se redeschide pentru citire si se afiseaza pe
   ecran. Apoi se inchide si se redeschide pentru adaugare in coada.
   Se inchide si se redeschide pentru a citi si afisa noul continut
*/

import java.io.*;

class TestFileOutput {
  public static void main(String args[]) {
    FileOutputStream fout;
    FileInputStream fin;
    byte b[];
    int k;
    if(args.length==0) {
      System.out.println("La lansare dati un text in linia de comanda");
      System.exit(0);
    }
    try {
      /* Se deschide fisierul pentru scriere */
      fout=new FileOutputStream("ProbaScriere.txt");
      for(int i=0; i<args.length; i++) {
        /* parametrul args[i] se converteste in tablou de octeti */
        b=(args[i]+" ").getBytes(); 
        /* tabloul b astfel obtinut se scrie in fisier */
        fout.write(b);
      }
      fout.close();
      /* Dupa ce a fost inchis, acelasi fisier se deschide pentru citire
      */
      fin=new FileInputStream("ProbaScriere.txt");
      /* Se afiseaza continutul fisierului */
      System.out.println("Fisierul contine:");
      while((k=fin.read()) != -1) System.out.print((char)k);
      System.out.println();
      fin.close();
      /* Se redeschide fisierul pentru scriere prin adaugare la coada */
      fout=new FileOutputStream("ProbaScriere.txt",true);
      /* Se scrie textul "\nText adaugat\n" */
      fout.write(("\nText adaugat\n").getBytes());
      fout.close();
      /* Se deschide din nou fisierul pentru citire si se afiseaza.
         De data aceasta, fin este fisierul din care se citeste, iar
         fout este un nou flux de iesire, care se conecteaza la
         iesirea standard al sistemului (la ecran) prin intermediul
         descriptorului FileDescriptor.out
      */
      fin=new FileInputStream("ProbaScriere.txt");
      fout=new FileOutputStream(FileDescriptor.out);
      fout.write("\nA doua oara fisierul contine:\n".getBytes());
      while((k=fin.read()) != -1) fout.write((byte)k);
      fout.write('\n');
/*    // Pentru comparatie, sub forma de comentariu se da 
      // programul de afisare obisnuit
      System.out.println("\nA doua oara fisierul contine:");
      while((k=fin.read()) != -1) System.out.print((char)k);
      System.out.println();
*/
      fin.close();
    }
    catch(Exception e) {
      System.out.println("Exceptie: "+e);
    }
  }
}
