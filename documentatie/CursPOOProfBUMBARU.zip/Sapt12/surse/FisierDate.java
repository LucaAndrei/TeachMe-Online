/* Testarea claselor DataOutputStream si DataInputStream.
   Scrierea datelor se face intr-un fisier, folosind un
   FileOutputStream conectat la iesirea unui DataOutputStream.
   Citirea datelor se face apoi din acelasi fisier, folosind un
   DataInputStream conectat la iesirea unui FileInputStream.
*/

import java.io.*;

class FisierDate {

  public static void main(String args[]) throws IOException {
    /* Datele care vor fi scrise in fisier */
    byte b=67;
    char c='A';
    boolean t=true, f=false;
    short sh=10723;
    int i=958716;
    long k=847543218045433L;
    float fl=95.01462f;
    double d=3.2607643218765;
    String str="ABCDabcd";
    /* Deschiderea fisierului pentru scrierea datelor */
    FileOutputStream fout=new FileOutputStream("Proba.dat");
    DataOutputStream dout=new DataOutputStream(fout); // acest flux
      // de date este conectat la iesire la fluxul de scriere
      // in fisier fout deschis anterior
    /* Scrierea datelor in fisier */
    dout.writeByte(b); // Se scrie ub octet
    dout.writeChar(c); // Se scrie un caracter
    dout.writeBoolean(t); dout.writeBoolean(f); // Se scriu valori logice
    dout.writeShort(sh); // Se scrie un short
    dout.writeInt(i);  // se scrie un int
    dout.writeLong(k); // se scrie un long
    dout.writeFloat(fl); // se scrie un float
    dout.writeDouble(d);  // se scrie un double
    dout.writeUTF(str);  // se scrie un sir de opt caractere in 
			 // format UTF
    /* Inchiderea fluxului de iesire */
    dout.close();
    /* Deschiderea fisierului pentru a citi datele scrise anterior */
    FileInputStream fin=new FileInputStream("Proba.dat");
    DataInputStream din=new DataInputStream(fin); // Fluxul de citire
      // date este conectat la iesirea fluxului de citire din fisier
      // fin deschis anterior
    /* Citirea datelor se face in aceeasi ordine in care au fost
       scrise
    */
    byte b1=din.readByte(); // Se citeste ub octet
    char c1=din.readChar(); // Se citeste un caracter
    boolean t1=din.readBoolean(),
            f1=din.readBoolean(); // Se citesc valori logice
    short sh1=din.readShort(); // Se citeste un short
    int i1=din.readInt();  // se citeste un int
    long k1=din.readLong(); // se citeste un long
    float fl1=din.readFloat(); // se citeste un float
    double d1=din.readDouble();  // se citeste un double
    String str1=din.readUTF();  // se citeste un sir in format UTF
    /* Afisarea pe ecran a perechilor de date scrise si citite */
    System.out.println("Datele scrise in fisier si cele citite");
    System.out.println("byte: "+b+" "+b1);
    System.out.println("char: "+c+" "+c1);
    System.out.println("boolean: "+t+" "+t1+"\n"+f+" "+f1);
    System.out.println("short: "+sh+" "+sh1);
    System.out.println("int: "+i+" "+i1);
    System.out.println("long: "+k+" "+k1);
    System.out.println("float: "+fl+" "+fl1);
    System.out.println("double: "+d+" "+d1);
    System.out.println("UTF: "+str+" "+str1);
    /* Inchiderea fluxului de intrare */
    din.close(); 
  }

}
