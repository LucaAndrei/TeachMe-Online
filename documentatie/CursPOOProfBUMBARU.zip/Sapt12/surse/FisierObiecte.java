/* Testarea claselor ObjectOutputStream si ObjectInputStream.
   Scrierea datelor se face intr-un fisier, folosind un
   FileOutputStream conectat la iesirea unui ObjectOutputStream.
   Citirea datelor se face apoi din acelasi fisier, folosind un
   ObjectInputStream conectat la iesirea unui FileInputStream.
*/

import java.io.*;

class FisierObiecte {

  static class Persoana implements Serializable {
   String nume;
   int anNastere;

   Persoana(String nume, int anNastere) {
    this.nume=nume; this.anNastere=anNastere;
   }
   public String toString() {
    return "[Persoana: "+nume+" an nastere: "+anNastere+"]";
   }
  }

  static class Student extends Persoana implements Serializable {
   int anStudii;
   String grupa;
   Student(String nume, int anNastere, int anStudii, String grupa) {
    super(nume, anNastere);
    this.anStudii=anStudii;
    this.grupa=grupa;
   }
   public String toString() {
    return "Student: "+nume+" an studii: "+anStudii+" grupa: "+
          grupa+"]";
   }
  }   

  public static void main(String args[]) throws Exception {
    /* Datele care vor fi scrise in fisier */
    Persoana pers1=new Persoana("Popescu Vasile", 1978),
             pers2=new Persoana("Vasiliu Mihaela", 1981);
    Student stud1=new Student("Petrescu Mihai", 1979, 2, "2221a"),
            stud2=new Student("Craciun Nelu", 1979, 2, "2321b");
    int i=1325479;
    double d=3.76523476512;
    String str="Exemplu de sir";
    int tabInt[]={12, -13, 21, 467823, -12643218};
    String tabstr[]={"alpha", "beta", "gamma"};
    double w[][]={{3.76521, 1.0256789e-4}, {-0.3709865, 12e7, 1e-9}};

    /* Deschiderea fisierului pentru scrierea datelor */
    FileOutputStream fout=new FileOutputStream("Proba1.dat");
    ObjectOutputStream dout=new ObjectOutputStream(fout); // acest flux
      // de obiecte este conectat la iesire la fluxul de scriere
      // in fisier fout deschis anterior

    /* Scrierea obiectelor in fisier */
    dout.writeObject(pers1);
    dout.writeObject(stud1);
    dout.writeDouble(d);
    dout.writeUTF(str);
    dout.writeObject(pers2);
    dout.writeInt(i);
    dout.writeObject(stud2);
    dout.writeObject(tabInt);
    dout.writeObject(tabstr);
    dout.writeObject(w);
    
    /* Inchiderea fluxului de iesire */
    dout.close();

    /* Deschiderea fisierului pentru a citi datele scrise anterior */
    FileInputStream fin=new FileInputStream("Proba1.dat");
    ObjectInputStream din=new ObjectInputStream(fin); // Fluxul de citire
      // obiecte este conectat la iesirea fluxului de citire din fisier
      // fin deschis anterior
    /* Citirea obiectelor se face in aceeasi ordine in care au fost
       scrise
    */
    Persoana pers1a, pers2a;
    Student stud1a, stud2a;
    int ia, tabInta[];
    double da, wa[][];
    String stra, tabstra[];
    pers1a=(Persoana)din.readObject();
    stud1a=(Student)din.readObject();
    da=din.readDouble();
    stra=din.readUTF();
    pers2a=(Persoana)din.readObject();
    ia=din.readInt();
    stud2a=(Student)din.readObject();
    tabInta=(int[])din.readObject();
    tabstra=(String[])din.readObject();
    wa=(double[][])din.readObject();

    /* Afisarea pe ecran a perechilor de date scrise si citite */
    System.out.println("Afisarea datelor scrise si citite pe perechi");
    System.out.println("int: "+i+" "+ia);
    System.out.println("double: "+d+" "+da);
    System.out.println("UTF: "+str+" "+stra);
    System.out.println(pers1+" "+pers1a);
    System.out.println(pers2+" "+pers2a);
    System.out.println(stud1+" "+stud1a);
    System.out.println(stud2+" "+stud2a);
    System.out.print("tabInt:  ");
    for(int j=0; j<tabInt.length; j++) 
         System.out.print(tabInt[j]+" ");
    System.out.print("\ntabInta: ");
    for(int j=0; j<tabInta.length; j++) 
         System.out.print(tabInta[j]+" ");
    System.out.print("\ntabstr:  ");
    for(int j=0; j<tabstr.length; j++)
         System.out.print(tabstr[j]+" ");
    System.out.print("\ntabstra: ");
    for(int j=0; j<tabstra.length; j++)
         System.out.print(tabstra[j]+" ");
    System.out.println();
    System.out.println("Tabloul bidimensional de tip real");
    for(int j=0; j<wa.length; j++) {
      for(int k=0; k<wa[j].length; k++)
        System.out.print(wa[j][k]+" ");
      System.out.println();
    }    

    /* Inchiderea fluxului de intrare */
    din.close(); 
  }

}
