import java.io.*;

class TestFileReader {
  public static void main(String args[]) {
    try {
      /* Se deschide fisierul si se citeste caracter cu caracter */
      FileReader fin=new FileReader("TextProba.txt");
      System.out.println("Numele canonic al codificarii textului: "+
		fin.getEncoding());
      int c;
      while(fin.ready()) {
        c=fin.read();
        System.out.print((char)c);
      }
      System.out.println();
      fin.close();
      /* Se redeschide fisierul si se citeste intr-un singur tablou
         de caractere
      */
      fin=new FileReader("TextProba.txt");
      char[] tab=new char[80];
      int nrCar;
      nrCar=fin.read(tab);
      System.out.println("Numar caractere citite: "+nrCar);
      for (int i=0; i<nrCar; i++) System.out.print(tab[i]);
      System.out.println();
      fin.close();
      /* Se redeschide fisierul si se citeste pe portiuni, folosind
         un tablou de lungime mai mica decat numarul de caractere
         din fisier
      */
      tab=new char[12];
      fin=new FileReader("TextProba.txt");
      while(fin.ready()) {
        nrCar=fin.read(tab);
        for(int i=0; i<nrCar; i++) System.out.print(tab[i]);
      }
      System.out.println();
      fin.close();
    }
    catch(Exception e) {
      System.out.println(e);
    }
  }
}
