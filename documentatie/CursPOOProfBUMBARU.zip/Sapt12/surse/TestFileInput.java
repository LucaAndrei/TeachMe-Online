/* Testarea clasei FileInputStream 
   La lansarea in executie, se da ca parametru in linia de comanda numele 
   unui fisier de text care va fi citit 
*/

import java.io.*;

class TestFileInput {
  public static void main(String args[]) {
    byte b[]=new byte[30];
    int n, n1;
    long n2;
    File fisier=null;
    if(args.length==0) {
      System.out.println("La lansarea in executie trebuie dat ca "+
	"parametru numele unui fisier de text");
      System.exit(0);
    } 
    else {
      fisier=new File(args[0]);
      if(!fisier.exists()) {
        System.out.println("Fisierul "+fisier+" nu exista!");
        System.exit(0);
      }
    }      
    try {
      /* Se deschide fisierul  dat ca parametru si se conecteaza la
         fluxul de intrare f1 */
      FileInputStream f1=new FileInputStream(fisier);
      System.out.println("S-a deschis fisierul "+fisier+
		" conectat la fluxul f1");
      System.out.println("Sunt disponibili "+f1.available()+
		" octeti");
      n1=f1.read();
      System.out.println("Primul octet citit este "+n1+
		" care este codul ASCII al caracterului "+(char)n1);
      n2=f1.skip(3);
      System.out.println("S-a sarit peste "+n2+" octeti");
      n=f1.read(b);
      System.out.println("S-au mai citit urmatorii "+n+" octeti:");
      for(int i=0; i<n; i++) System.out.print(b[i]+" ");
      System.out.println();
      System.out.println("care sunt codurile ASCII ale urmatoarelor "+
		" caractere:");
      for(int i=0; i<n; i++) System.out.print((char)b[i]);
      System.out.println();
      System.out.println("In fluxul de intrare mai sunt disponibili "+
		f1.available()+" octeti");
      /* Descriptorul fluxului f1 este folosit pentru deschiderea
         unui nou flux de intrare, f2. Acum fluxurile f1 si f2 sunt
         conectate la acelasi fisier de intrare
      */
      FileDescriptor fd=f1.getFD();
      FileInputStream f2=new FileInputStream(fd);
      System.out.println("S-a deschis fluxul f2, identic cu f1");
      System.out.println("In fluxul f2 sunt disponibili "+
		f2.available()+" octeti");
      n2=f2.read(b,0,15);
      System.out.println("S-au citit din f2 urmatorii "+n+" octeti:");
      for(int i=0; i<n; i++) System.out.print((char)b[i]);
      System.out.println();
      System.out.println("In f1 sunt disponibili "+f1.available()+
	" octeti, iar in f2 "+f2.available()+" octeti");
      f2.close();
      /* S-a inchis fisierul indicat de fluxul f2. In consecinta
         nu mai pot fi folosite nici unul din fluxurile f2 si f1,
         care au ca sursa acest fisier
      */
      System.out.println("S-a inchis fisierul "+fisier);

      /* Se deschide un nou flux de intrare, avand acelasi descriptor
         cu intrarea standard System.in, deci datele vor fi citite de
         la tastatura
      */
      f1=new FileInputStream(FileDescriptor.in);
      System.out.println("Introduceti de la tastatura un sir de "+
        "cel putin 10 caractere");
      n=f1.read(b,0,10);
      System.out.print("Caracterele citite de la tastatura: ");
      for(int i=0; i<n; i++) System.out.print((char)b[i]);
      System.out.println();
    }
    catch(Exception e) {
      System.out.println(e);
    }
  }
}
