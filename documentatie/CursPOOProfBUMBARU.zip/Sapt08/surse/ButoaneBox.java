/* Testarea gestionarului de pozitionare BoxLayout.

   In fereastra aplicatiei apar mai multe butoane din clasa
   ButonContor si un buton de anulare, a carui apasare anulaza
   toate contoarele.

   La lansarea in executie se da ca parametru in linia de comanda
   numarul de butoane de contorizare si numele axei in lungul careia
   vor fi plasate componentele (X sau Y). De exemplu, comanda
      java ButoaneBox 5 Y
   are ca efecte punerea in executie a aplicatiei cu 5 butoane contor
   si un buton de anulare, toate plasate unul sub altul
*/


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ButoaneBox { 
 static AF af=new AF(); // ascultatorul de fereastra
 static Anulare anulare=new Anulare(); // ascultatorul
                                       // butonului de anulare
 static IUG iug;  // fereastra aplicatiei
 static int numarButoane;
 static int axa;

 static class IUG extends JFrame {
  JLabel lab=new JLabel("Actionati butoanele");
  ButonContor bc[];
  JButton br=new JButton("Reset"); 

  IUG(String titlu) { // constructorul ferestrei aplicatiei
   super(titlu);
   Container cp=getContentPane();
   setSize(350,350);
   setLocation(200,150);
   addWindowListener(af);
   cp.setLayout(new BoxLayout(getContentPane(), axa));
   bc=new ButonContor[numarButoane];
   for(int i=0; i<numarButoane; i++) { 
    bc[i]=new ButonContor("B"+(i+1)); // crearea butoanelor
    cp.add(bc[i]); // adaugarea butoanelor la contentPane
   }
   cp.add(br); // adaugarea butonului de anulare
   br.addActionListener(anulare); // adaugarea ascultatorului
   setVisible(true);
  }
 }

 static class AF extends WindowAdapter { 
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 static class Anulare implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    for(int i=0; i<numarButoane; i++) iug.bc[i].reset();
  }
 }

 public static void main(String args[]) throws Exception {
  if(args.length!=2 ) {
    System.out.println(
      "Utilizare: java ButoaneBox <numarButoane> <axa>");
    System.exit(1);
  }
  String numeAxa=args[1].toUpperCase();
  if(numeAxa.equals("Y")) axa=BoxLayout.Y_AXIS;
  else 
    if(numeAxa.equals("X")) axa=BoxLayout.X_AXIS;
    else {
      System.out.println("Axa nu poate fi decat X sau Y");
      System.exit(1);
    }
  numarButoane=Integer.parseInt(args[0]);
  iug=new IUG("BoxLayout cu "+numarButoane+
   " butoane de contorizare");
 }
}
  