import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class EvTaste1 {
  static AF af=new AF(); // ascultatorul de fereastra
  static ATaste at=new ATaste(); // ascultatorul de taste
  static IUG iug=new IUG("Urmarirea evenimentelor de tasta");

  /* Clasa imbricata pentru interfata utilizator */
  static class IUG extends JFrame {
   /* Constructorul interfetei utilizator */
   IUG(String titlu) {
    super(titlu);
    setSize(300,100);
    setLocation(new Point(100,50));
    setVisible(true);
    addWindowListener(af); // adaugarea ascultatorului de fereastra
    addKeyListener(at); // adaugarea ascultatorului de taste
   }
  }

  /* Clasa imbricata pentru ascultatorul de fereastra */ 
  static class AF extends WindowAdapter {
   public void windowClosing(WindowEvent e) {
    System.exit(0); // incheierea executarii aplicatiei
   }
  }

  /* Clasa imbricata pentru ascultatorul de taste */
  static class ATaste extends KeyAdapter {
   public void keyPressed(KeyEvent e) {
    int cod=e.getKeyCode(), mod=e.getModifiers();
    String mesaj="S-a apasat tasta de cod "+cod+" "+e.getKeyText(cod);
    if(mod!=0) 
      mesaj+=" cu modificatorii: "+e.getKeyModifiersText(mod);
    System.out.println(mesaj);
   }
   public void keyTyped(KeyEvent e) {
    System.out.println("S-a introdus caracterul "+e.getKeyChar());
   }
  }

  /* Metoda principala */
  public static void main(String args[]) {
  }
}
