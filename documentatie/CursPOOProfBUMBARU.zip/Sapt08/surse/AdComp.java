import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class AdComp { 
 static String textButon="Numar de actionari: ";
 static int contorActionari=0;
 static AF af=new AF();
 static AB ab=new AB();
 static JButton buton=new JButton(textButon+contorActionari);
 static IUG iug=new IUG("Un buton de contorizare a apasarilor");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(300, 80);
   setLocation(200, 150);
   getContentPane().add(buton); // adaugarea butonului
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   buton.addActionListener(ab); // adaugarea ascult. de actiune
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare de actiuni asupra butonului */
 static class AB implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   contorActionari++;
   buton.setText(textButon+contorActionari);
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  