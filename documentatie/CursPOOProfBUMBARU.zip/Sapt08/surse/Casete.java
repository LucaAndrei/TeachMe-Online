/* Exemplu de utilizare a containerelor din clasa javax.swing.Box */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Casete {
 static ButonContor bc[]=new ButonContor[5];
 static JButton br1=new JButton("Reset 1"),
                br2=new JButton("Reset 2");
 static Anulare anulare=new Anulare();
 static IUG iug=new IUG("Gruparea componentelor in casete");

 static class IUG extends JFrame {
  Box c1=Box.createVerticalBox(); 
  Box c2=Box.createVerticalBox();
  Box c3=Box.createHorizontalBox();

  IUG(String titlu) {
   super(titlu);
   setSize(280,160);
   addWindowListener(new AF());
   /* Crearea butoanelor */
   for(int i=0; i<5; i++) bc[i]=new ButonContor("B"+i);
   /* Completarea cu butoane a casetei c1 */
   c1.add(Box.createVerticalStrut(18)); // deplasare in jos
   c1.add(bc[0]);
   c1.add(bc[1]);
   c1.add(Box.createVerticalStrut(10)); // deplasare in jos
   c1.add(br1);
   /* Completarea casetei c2 */
   for(int i=2; i<5; i++) c2.add(bc[i]);
   c2.add(Box.createVerticalStrut(5)); // deplasare in jos
   c2.add(br2);
   /* Adaugarea de ascultatori la butoanele de anulare */
   br1.addActionListener(anulare);
   br2.addActionListener(anulare);
   /* Adaugarea casetelor c1 si c2 la caseta c3 */
   c3.add(Box.createGlue()); // pentru alinierea la centru
   c3.add(c1);
   c3.add(Box.createHorizontalStrut(10));
   c3.add(c2);
   /* Adaugarea casetei c3 la contentPane */
   getContentPane().add(c3);
   setVisible(true);
  }
 }
 
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 static class Anulare implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    String actiune=e.getActionCommand();
    if(actiune.equals(br1.getText())) 
      for(int i=0; i<2; i++) bc[i].reset();
    else if(actiune.equals(br2.getText()))
      for(int i=2; i<5; i++) bc[i].reset();
  }
 }

 public static void main(String args[]) {
 }
}

