/* Testarea alinierii componentelor cand se foloseste
   gestionarul de pozitionare FlowLayout.

   In fereastra aplicatiei apar mai multe butoane din clasa
   ButonContor, trei butoane de aliniere si un buton de anulare.

   La lansarea in executie se da ca parametru in linia de comanda
   numarul de butoane de contorizare

   Actionarea unuia din butoanele de aliniere are ca efect 
   modificarea corespunzatoare a alinierii componentelor pe
   suprafata containerului

   Actionarea butonului de anulare produce anuloarea tuturor
   contoarelor.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Aliniere { 
 static AF af=new AF(); // ascultatorul de fereastra
 static Actiuni actiuni=new Actiuni(); // ascultatorul
               // butoanelor de aliniere si de anulare
 static IUG iug;  // fereastra aplicatiei
 static int numarButoane;
 static FlowLayout layout=new FlowLayout();

 static class IUG extends JFrame {
  JLabel lab=new JLabel("Actionati butoanele");
  ButonContor bc[];
  JButton br=new JButton("Anulare");
  JButton bas=new JButton("Stanga"), bac=new JButton("Centru"),
      bad=new JButton("Dreapta"); 

  IUG(String titlu) { // constructorul ferestrei aplicatiei
   super(titlu);
   Container cp=getContentPane();
   setSize(300,150);
   setLocation(200,150);
   addWindowListener(af);
   cp.setLayout(layout); // setarea gestionarului de pozitionare
   bc=new ButonContor[numarButoane];
   for(int i=0; i<numarButoane; i++) { 
    bc[i]=new ButonContor("B"+(i+1)); // crearea butoanelor
    cp.add(bc[i]); // adaugarea butoanelor la contentPane
   }
   cp.add(bas); cp.add(bac); cp.add(bad); // adaugare butoane
                                          // de aliniere
   cp.add(br); // adaugarea butonului de anulare
   br.addActionListener(actiuni); // adaugarea ascultatorului
   bas.addActionListener(actiuni);
   bac.addActionListener(actiuni);
   bad.addActionListener(actiuni);
   setVisible(true);
  }
 }

 static class AF extends WindowAdapter { 
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 static class Actiuni implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    String comanda=e.getActionCommand();
    if(comanda.equals("Anulare"))
      for(int i=0; i<numarButoane; i++) iug.bc[i].reset();
    else {
      if(comanda.equals("Stanga"))
        layout.setAlignment(FlowLayout.LEFT);
      else if(comanda.equals("Centru"))
        layout.setAlignment(FlowLayout.CENTER);
      else if(comanda.equals("Dreapta"))
        layout.setAlignment(FlowLayout.RIGHT);
      iug.getContentPane().doLayout();
    }
  }
 }

 public static void main(String args[]) throws Exception {
  if(args.length!=1) {
    System.out.println("Utilizare: java Aliniere <numarButoane>");
    System.exit(1);
  }
  numarButoane=Integer.parseInt(args[0]); // crearea tabloului de 
                                          // butoane
  iug=new IUG("FlowLayout cu "+numarButoane+
   " butoane de contorizare"); // crearea ferestrei aplicatiei
 }
}
  