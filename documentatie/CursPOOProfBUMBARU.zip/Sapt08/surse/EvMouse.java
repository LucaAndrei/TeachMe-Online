import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class EvMouse {
  static JFrame iug;  // referinta la fereastra
  static AF af; // referinta la ascultator de fereastra
  static AMouse am; // referinta la ascultator de mouse

  /* Clasa imbricata pentru ascultatorul de fereastra */ 
  static class AF extends WindowAdapter {
   public void windowClosing(WindowEvent e) {
    System.exit(0); // incheierea executarii aplicatiei
   }
  }

  /* Clasa imbricata pentru ascultatorul de mouse */
  static class AMouse implements MouseListener {
   public void mouseClicked(MouseEvent e) {
    System.out.println(e);
   }
   public void mousePressed(MouseEvent e) {
    System.out.println(e);
   }
   public void mouseReleased(MouseEvent e) {
    System.out.println(e);
   }
   public void mouseEntered(MouseEvent e) { 
    System.out.println(e);
   }
   public void mouseExited(MouseEvent e) { 
    System.out.println(e);
   }
  }

  /* Metoda principala */
  public static void main(String args[]) throws Exception {
    af=new AF(); // instantierea ascultatorului
    am=new AMouse(); // instantierea ascultatorului de mouse
    iug=new JFrame("Urmarire evenimente de mouse");
    iug.setSize(300,100);
    iug.setLocation(new Point(100,50));
    iug.setVisible(true);
    iug.addWindowListener(af); // adaugarea ascultatorului de fereastra
    iug.addMouseListener(am); // adaugarea ascultatorului de mouse
  }
}
