import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Evenim1 {
  static JFrame iug;  // referinta la fereastra
  static AscultFereastra af; // referinta la ascultator

  /* Clasa imbricata pentru ascultatorul de fereastra */ 
  static class AscultFereastra implements WindowListener {
   public void windowOpened(WindowEvent e) {
    System.out.println("Fereastra a fost deschisa: "+e);
   }
   public void windowClosing(WindowEvent e) {
    System.out.println("Fereastra se inchide: "+e);
   }
   public void windowClosed(WindowEvent e) {
    System.out.println("Fereastra a fost inchisa: "+e);
   }
   public void windowIconified(WindowEvent e) {
    System.out.println("Fereastra a fost iconificata: "+e);
   }
   public void windowDeiconified(WindowEvent e) {
    System.out.println("Fereastra a fost deiconificata: "+e);
   }
   public void windowActivated(WindowEvent e) {
    System.out.println("Fereastra a fost activata: "+e);
   }
   public void windowDeactivated(WindowEvent e) {
    System.out.println("Fereastra a fost dezactivata: "+e);
   }
  }

  /* metoda principala */
  public static void main(String args[]) throws Exception {
    af=new AscultFereastra(); // instantierea ascultatorului
    iug=new JFrame("Urmarire evenimente fereastra");
    iug.setSize(300,100);
    iug.setLocation(new Point(100,50));
    iug.setVisible(true);
    iug.addWindowListener(af); // adaugarea ascultatorului
    System.out.println("Titlul ferestrei este: "+iug.getTitle());
    System.out.println("Coltul din stanga sus este in punctul: "+
      iug.getLocation());
    System.out.println("Dimensiunile ferestrei: "+iug.getSize());
  }
}
