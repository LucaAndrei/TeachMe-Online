import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Inchidere {
  static JFrame iug;  // referinta la fereastra
  static AF af; // referinta la ascultator

  /* Clasa imbricata pentru ascultatorul de fereastra */ 
  static class AF extends WindowAdapter {
   public void windowActivated(WindowEvent e) {
    System.out.println("Fereastra a fost activata");
   }
   public void windowDeactivated(WindowEvent e) {
    System.out.println("Fereastra a fost dezactivata");
   }
   public void windowClosing(WindowEvent e) {
    System.out.println("Fereastra se inchide");
    System.exit(0); // incheierea executarii aplicatiei
   }
  }

  /* Metoda principala */
  public static void main(String args[]) throws Exception {
    af=new AF(); // instantierea ascultatorului
    iug=new JFrame("Urmarire evenimente fereastra");
    iug.setSize(300,100);
    iug.setLocation(new Point(100,50));
    iug.setVisible(true);
    iug.addWindowListener(af); // adaugarea ascultatorului
    System.out.println("Titlul ferestrei este: "+iug.getTitle());
    System.out.println("Coltul din stanga sus este in punctul: "+
      iug.getLocation());
    System.out.println("Dimensiunile ferestrei: "+iug.getSize());
  }
}
