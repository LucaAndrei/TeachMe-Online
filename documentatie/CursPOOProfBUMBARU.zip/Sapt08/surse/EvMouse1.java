import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class EvMouse1 {
  static JFrame iug;  // referinta la fereastra
  static AF af; // referinta la ascultator de fereastra
  static AMouse am; // referinta la ascultator de mouse

  /* Clasa imbricata pentru ascultatorul de fereastra */ 
  static class AF extends WindowAdapter {
   public void windowClosing(WindowEvent e) {
    System.exit(0); // incheierea executarii aplicatiei
   }
  }

  /* Clasa imbricata pentru ascultatorul de mouse */
  static class AMouse extends MouseAdapter {
   public void mousePressed(MouseEvent e) {
    int x=e.getX(), y=e.getY(), n=e.getClickCount(), 
      mod=e.getModifiers(), buton=0;
    String mesaj="S-a apasat butonul ";
    if((InputEvent.BUTTON1_MASK & mod) != 0) buton=1;
    else if((InputEvent.BUTTON2_MASK & mod) !=0) buton=2;
    else if((InputEvent.BUTTON3_MASK & mod) !=0) buton=3;
    mesaj+=buton+" x="+x+" y="+y+" contor="+n+" mod="+mod;
    if(e.isControlDown()) mesaj+=" Ctrl";
    if(e.isAltDown())    mesaj+=" Alt";
    if(e.isShiftDown())  mesaj+=" Shift";
    System.out.println(mesaj);
   }
  }

  /* Metoda principala */
  public static void main(String args[]) throws Exception {
    af=new AF(); // instantierea ascultatorului
    am=new AMouse(); // instantierea ascultatorului de mouse
    iug=new JFrame("Urmarire evenimente de mouse");
    iug.setSize(300,100);
    iug.setLocation(new Point(100,50));
    iug.setVisible(true);
    iug.addWindowListener(af); // adaugarea ascultatorului de fereastra
    iug.addMouseListener(am); // adaugarea ascultatorului de mouse
  }
}
