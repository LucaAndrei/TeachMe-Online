import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Butoane { 
 static AF af=new AF(); // ascultatorul de fereastra
 static AA aa=new AA(); // ascultatorul de actiuni
 static IUG iug=new IUG("Adaugare de butoane");
 static int totalActionari=0;

 static class IUG extends JFrame {
  JLabel lab=new JLabel("Actionati butoanele");
  ButonContor b1, b2, b3, b4; 

  IUG(String titlu) {
   super(titlu);
   Container cp=getContentPane();
   setSize(400,300);
   setLocation(200,150);
   addWindowListener(af);
   b1=new ButonContor("N");
   b1.addActionListener(aa);
   cp.add(b1, BorderLayout.NORTH);
   b2=new ButonContor("E");
   b2.addActionListener(aa);
   cp.add(b2, BorderLayout.EAST);
   b3=new ButonContor("W");
   b3.addActionListener(aa);
   cp.add(b3, BorderLayout.WEST);
   b4=new ButonContor("C");
   b4.addActionListener(aa);
   cp.add(b4, BorderLayout.CENTER);
   cp.add(lab, BorderLayout.SOUTH);
   setVisible(true);
  }
 }

 static class AA implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    totalActionari++;
    iug.lab.setText("Total actionari: "+totalActionari);
  }
 }

 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 public static void main(String args[]) {
 }
}
  