import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Panouri {
 static ButonContor bc[]=new ButonContor[8];
 static JButton br1=new JButton("Reset 1"),
                br2=new JButton("Reset 2");
 static Anulare anulare=new Anulare();
 static IUG iug=new IUG("Gruparea componentelor pe panouri");

 static class IUG extends JFrame {
  JPanel p1=new JPanel(); // p1 are implicit FlowLayout
  JPanel p2=new JPanel(new BorderLayout()); // p2 primeste BorderLayout

  IUG(String titlu) {
   super(titlu);
   Container cp=getContentPane();
   setSize(500,400);
   addWindowListener(new AF());
   cp.setLayout(new GridLayout(2,2));
   /* Crearea butoanelor */
   for(int i=0; i<8; i++) bc[i]=new ButonContor("B"+i);
   /* Completarea cu butoane a panoului p2 */
   p2.add(bc[0], BorderLayout.NORTH);
   p2.add(bc[1], BorderLayout.WEST);
   p2.add(bc[2], BorderLayout.CENTER);
   p2.add(bc[3], BorderLayout.EAST);
   p2.add(bc[4], BorderLayout.SOUTH);
   /* Completarea panoului p1 */
   for(int i=5; i<8; i++) p1.add(bc[i]);
   /* Adaugarea de ascultatori la butoanele de anulare */
   br1.addActionListener(anulare);
   br2.addActionListener(anulare);
   /* Adaugarea de panouri si butoane la controlPane */
   cp.add(p2);
   cp.add(p1);
   cp.add(br1);
   cp.add(br2);
   setVisible(true);
  }
 }
 
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 static class Anulare implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    String actiune=e.getActionCommand();
    if(actiune.equals(br1.getText())) 
      for(int i=0; i<5; i++) bc[i].reset();
    else if(actiune.equals(br2.getText()))
      for(int i=5; i<8; i++) bc[i].reset();
  }
 }

 public static void main(String args[]) {
 }
}

