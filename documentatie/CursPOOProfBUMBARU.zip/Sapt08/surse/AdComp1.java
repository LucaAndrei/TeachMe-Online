import java.awt.event.*;
import javax.swing.*;

class AdComp1 { 
 static AF af=new AF();
 static ButonContor buton=new ButonContor("Contor apasari");
 static IUG iug=new IUG("Un buton de contorizare a apasarilor");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(300, 80);
   setLocation(200, 150);
   getContentPane().add(buton); // adaugarea butonului
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  