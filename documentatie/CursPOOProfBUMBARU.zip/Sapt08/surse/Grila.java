/* Testarea alinierii componentelor cand se foloseste
   gestionarul de pozitionare GridLayout.

   In fereastra aplicatiei apar mai multe butoane din clasa
   ButonContor si un buton de anulare. 

   Punerea in executie a aplicatiei se face prin comanda
    java Grila <numarContoare> <nrLinii> <nrColoane>

   Actionarea butonului de anulare produce anuloarea tuturor
   contoarelor.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Grila { 
 static AF af=new AF(); // ascultatorul de fereastra
 static Actiuni actiuni=new Actiuni(); // ascultatorul
               // butonului de anulare
 static IUG iug;  // fereastra aplicatiei
 static int numarButoane, nrLinii, nrColoane;

 static class IUG extends JFrame {
  JLabel lab=new JLabel("Actionati butoanele");
  ButonContor bc[];
  JButton br=new JButton("Anulare");

  IUG(String titlu) { // constructorul ferestrei aplicatiei
   super(titlu);
   Container cp=getContentPane();
   setSize(400,250);
   setLocation(200,150);
   addWindowListener(af);
   cp.setLayout(new GridLayout(nrLinii, nrColoane)); // setarea 
                           // gestionarului de pozitionare
   bc=new ButonContor[numarButoane];
   for(int i=0; i<numarButoane; i++) { 
    bc[i]=new ButonContor("B"+(i+1)); // crearea butoanelor
    cp.add(bc[i]); // adaugarea butoanelor la contentPane
   }
   cp.add(br); // adaugarea butonului de anulare
   br.addActionListener(actiuni); // adaugarea ascultatorului
   setVisible(true);
  }
 }

 static class AF extends WindowAdapter { 
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 static class Actiuni implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    String comanda=e.getActionCommand();
    if(comanda.equals("Anulare"))
      for(int i=0; i<numarButoane; i++) iug.bc[i].reset();
  }
 }

 public static void main(String args[]) throws Exception {
  /* Verificarea numarului de argumente din linia de comanda */
  if(args.length!=3) {
    System.out.println(
     "Utilizare: java  <numarButoane> <nrLinii> <nrColoane>");
    System.exit(1);
  }
  /* Preluarea argumentelor din linia de comanda */
  numarButoane=Integer.parseInt(args[0]); 
  nrLinii=Integer.parseInt(args[1]);
  nrColoane=Integer.parseInt(args[2]);
  /* Crearea ferestrei aplicatiei */
  iug=new IUG("GridLayout cu "+numarButoane+
   " butoane de contorizare");
 }
}
  