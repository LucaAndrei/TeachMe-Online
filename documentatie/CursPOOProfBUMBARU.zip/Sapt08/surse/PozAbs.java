/* Pozitionarea absoluta a componentelor in container */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class PozAbs { 
 static AF af=new AF(); // ascultatorul de fereastra
 static AA aa=new AA(); // ascultatorul de actiuni
 static IUG iug=new IUG("Pozitionare absoluta");

 static class IUG extends JFrame {
  JLabel et1=new JLabel("Butoane de contorizare");
  JLabel et2=new JLabel("Anularea tuturor contoarelor >>>");
  JButton br=new JButton("Reset");
  int numarContoare=4;
  ButonContor bc[]=new ButonContor[numarContoare];

  /* Constructorul ferestrei aplicatiei */
  IUG(String titlu) {
   super(titlu);
   Container cp=getContentPane();
   setSize(420,220);
   setLocation(200,150);
   addWindowListener(af);
   cp.setLayout(null); // se elimina gestionarul de pozitionare din
                       // contentPane
   et1.setBounds(150, 5, 160,10); // pozitia si dimensiunile etichetei
   cp.add(et1);  // adaugarea etichetei
   for(int i=0; i<numarContoare; i++) {
    bc[i]=new ButonContor("B"+i);  // crearea butoanelor-contor
    bc[i].setBounds(10+100*i, 20, 90,70);  // stabilirea pozitiei
          // si dimensiunilor butoanelor-contor
    cp.add(bc[i]);  // adaugarea butoanelor-contor la contentPane
   }
   et2.setBounds(10, 140, 200,10); // locul si dimens. etichetei 2
   cp.add(et2); // adaugarea etichetei 2 la contentPane
   br.setBounds(210, 120, 70, 60); // pozitia si dimensiunile
                  // butonului de anulare
   br.addActionListener(aa); // ascultarea butonului de anulare
   cp.add(br);  // adaugarea butonului de anulare la contentPane
   setVisible(true);
  }
 }

 /* Ascultatorul actiunilor butonului de anulare. Cand este apasat
    acest buton, se pun la zero toate contoarele
 */
 static class AA implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   for(int i=0; i<iug.numarContoare; i++) iug.bc[i].reset();
  }
 }

 /* Ascultarea evenimentelor de fereastra */
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 public static void main(String args[]) {
 }
}
  