/* Buton care contorizeaza numarul de apasari si afiseaza acest 
   numar pe suprafata sa, dupa numele butonului. In acest scop, 
   butonul isi asculta propriile evenimente de actiune.
*/

import java.awt.event.*;
import javax.swing.*;

public class ButonContor extends JButton implements ActionListener {
  private int contor; // contorul de apasari
  private String nume; // numele butonului

  public ButonContor(String nume) { // constructorul butonului
    contor=0;
    this.nume=nume+" #";
    setText(this.nume+contor);
    addActionListener(this); // butonul se asculta pe sine
  }

  public void actionPerformed(ActionEvent e) {
    contor++;
    setText(nume+contor);
  }

  public int numarApasari() { // se intoarce numarul de apasari
    return contor;
  }

  public void reset() { // se pune contorul la zero
    contor=0;
    setText(nume+contor);
  }
}
