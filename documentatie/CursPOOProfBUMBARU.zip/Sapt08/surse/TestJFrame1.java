import java.awt.*;
import javax.swing.*;
 
class TestJFrame1 { 
  static JFrame iug; 

  public static void main(String args[]) throws Exception { 
    iug=new JFrame("Exemplu de JFrame"); 
    iug.setSize(300,100); 
    iug.setLocation(new Point(100,50)); 
    iug.setVisible(true); 
    System.out.println("Titlul ferestrei este: "+iug.getTitle()); 
    System.out.println("Coltul din stanga sus este in punctul: "+ 
      iug.getLocation()); 
    System.out.println("Dimensiunile ferestrei: "+iug.getSize()); 
  } 
}
