/* Exersarea metodelor print si println */

 class AfisareSiruri {
   public static void main(String args[]) {
     System.out.println("sirul 1");
     System.out.println("sirul 2"); // se afiseaza sub sirul 1
     System.out.println("AB"+"CDE"); // se afiseaza ABCDE
     System.out.println("ab"+"cd"+"ef"); // se afiseaza abcdef
     System.out.println(("ab"+"cd")+"ef"); // asociativitate
     System.out.println("ab"+("cd"+"ef"));
     /* Urmatoarele trei instructiuni afiseaza in continuare,
        pe o singura linie  */
     System.out.print("pqrst"); // nu se trece la linie noua
     System.out.print("UVW");   // se afiseaza in continuare
     System.out.print("xyz\n"); // echivalent cu println("xyz")
     /* Trecerea la linia urmatoare se face datorita prezentei
        caracterului de control \n in sirul "xyz\n" */
     System.out.println("ultima linie afisata");
     System.out.println((int)'A'+" "+(int)'q');
   } 
 }