/* Operatii cu date de tip char */

class TestChar {
  public static void main(String args[]) {
    char c1='A', c2='a', c3='b', c4='1', c5='*', c6='\n';
    System.out.println(c1+" "+c2+" "+c6+" "+c4+" "+c5+" "+c3);
    System.out.println((int)c1+" "+(int)c2+" "+(int)c6+" "+
      (int)c4+" "+(int)c5);
    System.out.println(c1+c2);
    System.out.println(c1*c2);
    System.out.println((char)107);
    System.out.println('2'+" "+(int)'2'+" "+'3'+" "+(int)'3'+
      " "+('2'+'3'));
  }
}
