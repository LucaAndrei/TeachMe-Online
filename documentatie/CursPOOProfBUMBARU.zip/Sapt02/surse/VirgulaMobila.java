/* testarea operatiilor aritmetice cu numere in virgula mobila */

class VirgulaMobila {
  public static void main(String args[]) {
    double a=12.7865, b=-158.07, c=0.0, d=-0.0, inf1, inf2, n;
    float p=3476.15f, q=0.00237621f, r=0.0f, s=-0.0f;
    System.out.println("a/b="+(a/b)+" b/a="+(b/a)+" b%a="+(b%a));
    System.out.println("a/c="+(a/c)+" b/c="+(b/c));
    System.out.println("a/d="+(a/d)+" b/d="+(b/d));
    System.out.println("c/d="+(c/d)+" d/c="+(d/c));
    System.out.println("p/q="+(p/q)+" q/p="+(q/p)+" p%q="+(p%q));
    System.out.println("p/r="+(p/r)+" p/s="+(p/s));
    System.out.println("a/q="+(a/q)+" p/b="+(p/b));
    inf1=a/c; inf2=a/d; n=c/d;
    System.out.println("a/inf1="+(a/inf1)+" a/inf2="+(a/inf2));
    System.out.println("inf1/inf2="+(inf1/inf2)+" inf2/inf1="+
      (inf2/inf1));
    System.out.println("a*inf1="+(a*inf1)+" c*inf1="+(c*inf1));
  }
}
