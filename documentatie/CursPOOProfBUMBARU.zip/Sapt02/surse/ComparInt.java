/* Testarea operatorilor de comparatie in cazul tipurilor
 de date intregi
*/

class ComparInt {
  public static void main(String args[]) {
    byte b1=48, b2=-17;
    short s1=2765, s2=-12970;
    int i1=762983, i2=48, i3=-12970;
    long m1=876432906528L, m2=48;
    System.out.println(b1==b2);
    System.out.println(b1==i2);
    System.out.println(s1!=i2);
    System.out.println(i2!=m2);
    System.out.println(m2>i2);
    System.out.println(m2>=i2);
    System.out.println(s2<i3);
    System.out.println(i3<=s2);
  }
}
