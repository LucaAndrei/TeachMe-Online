/* Testarea operatorilor de atribuire compusa */

class AtribComp {
  public static void main(String args[]) {
    int m=176, b=-15, c=16, d=-28;
    System.out.println(m+" "+(m+=b)+" "+m);
    System.out.println((m/=d)+" "+m);
    System.out.println(b+" "+(b<<=2)+" "+b);
    System.out.println(c+" "+(c|=b)+" "+c);
  }
}


    