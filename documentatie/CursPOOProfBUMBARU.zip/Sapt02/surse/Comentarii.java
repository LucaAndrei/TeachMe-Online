/** Aplicatie in care se exemplifica folosirea celor trei tipuri 
 de comentarii permise in limbajul Java */

  class Comentarii { // aici incepe definitia clasei Comentarii
     /* metoda main este metoda principala a clasei, cu care
        incepe executarea programului */
       public static void main(String args[]) {
         /* Urmeaza instructiunea prin care se invoca metoda println
            pentru afisarea unui text */
          System.out.println("Prima noastra aplicatie a reusit!"); 
       }  // sfarsitul metodei main
    }  // sfarsitul clasei Comentarii