/* Testarea exceptiei de impartire la zero */

class ImpartireZero {
  public static void main(String args[]) {
    int a=5, b=0, c=0;
    System.out.println(a/b);
  }
}
