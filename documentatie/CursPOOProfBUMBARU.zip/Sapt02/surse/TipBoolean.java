/* Testarea declararii variabilelor booleene si a efectului
   operatiilor logice
*/

class TipBoolean {
  public static void main(String args[]) {
    boolean alpha=true, beta=false, p, q, r,s;
    p=!alpha;
    q=alpha&&beta;
    r=alpha||beta;
    s=alpha^beta;
    System.out.println(" alpha="+alpha+" beta="+beta+" p="+p+
      " q="+q+" r="+r+" s="+s);
    System.out.println("alpha&&beta="+(alpha&&beta)+" alpha||beta="+
      (alpha||beta));
    System.out.println("alpha==beta: "+(alpha==beta));
    System.out.println("alpha!=beta: "+(alpha!=beta));
  }
}
