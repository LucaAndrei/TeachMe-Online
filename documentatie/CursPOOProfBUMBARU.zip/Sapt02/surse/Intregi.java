/* Testarea operatiilor cu numere intregi */

class Intregi {
  public static void main(String args[]) {
    byte b1=73, b2=-109, b3, b4, b5;
    short s1=9000, s2=-11000, s3, s4;
    int i1=900000, i2=-1100000, i3, i4, i5;
    long m1=10000000000L, m2=-200000000000L, m3, m4;
    b3=(byte)(-b2);
    b4=(byte)(b1+b2);
    b5=++b1;
    s3=(short)(s2/s1);
    s4=(short)(s2%s1);
    i3=i1+i2;
    i4=i1*i2; // restul impartirii s2/s1
    i5=(int)(m2/i1);
    m3=m2-m1;
    m4=m2*m1;
    System.out.println("b3="+b3+" b4="+b4+" b5="+b5);
    System.out.println("s3="+s3+" s4="+s4);
    System.out.println("i3="+i3+" i4="+i4+" i5="+i5);
    System.out.println("m3="+m3+" m4="+m4);
    System.out.println("b5*b2="+(b5*b2)+" s1*s2="+(s1*s2));
  }
}
