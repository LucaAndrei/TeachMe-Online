/* Testarea operatiilor de deplasare binara */

class Deplasari {
  public static void main(String args[]) {
    byte b1=15, b2;
    int i1=1024, i2=-1024;
    b2=(byte)(b1<<3);
    System.out.println("b1="+b1+" b2="+b2);
    System.out.println("i1<<4="+(i1<<4)+" i1>>4="+(i1>>4)+
      " i1>>>4="+(i1>>>4));
    System.out.println("i2<<4="+(i2<<4)+" i2>>4="+(i2>>4)+
      " i2>>>4="+(i2>>>4));
  }
}