/* Testarea operatiilor logice pe biti */

class LogicaBiti {
  public static void main(String args[]) {
    byte b1=17, b2=-95, b3;
    b3=(byte)(b1&b2); // este necesara conversie de la int la byte
    System.out.println("~b1="+(~b1)+" b1&b2="+b3+" b1|b2="+(b1|b2)+
      " b1^b2="+(b1^b2));
  }
}
