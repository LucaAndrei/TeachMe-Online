/* Verificarea actiunii operatorului (cast) in cazul numerelor intregi
*/

class CastInt {
  public static void main(String args[]) {
    /* Declararea si initializarea variabilelor */
    byte b1=73, b2=-107, b3, b4, b5;
    int i1=91, i2=-103, i3=22195, i4, i5;
    /* Atribuiri cu conversie implicita de la byte la int
    */
    i4=b1; 
    i5=b2; 
    /* Atribuiri care necesita conversie explicita de la int la byte
    */
    b3=(byte)i1;
    b4=(byte)i2;
    b5=(byte)i3;
    /* Afisarea rezultatelor */
    System.out.println("i4="+i4+" i5="+i5+"\nb3="+b3+" b4="+b4+
      " b5="+b5);
  }
}
