import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import javax.swing.event.*;


class CampuriText { 
 static AF af=new AF();
 static Actiuni act=new Actiuni();
 static IUG iug=new IUG("Campuri de text");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JPanel panel;
  JTextField tf1, tf2, tf3;
  JLabel label;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(450, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra

   /* Crearea panoului pentru campurile de text */
   panel=new JPanel();
   panel.setLayout(new GridLayout(3,2));

   /* Adaugarea la panou a etichetelor si campurilor de text */
   panel.add(new JLabel("Un sir de caractere: "));
   tf1=new JTextField();
   tf1.addActionListener(act);
   panel.add(tf1);
   panel.add(new JLabel("Un numar intreg"));
   tf2=new JTextField();
   tf2.addActionListener(act);
   panel.add(tf2);
   panel.add(new JLabel("Un numar real: "));
   tf3=new JTextField();
   tf3.addActionListener(act);
   panel.add(tf3);
   /* Adaugarea la contentPane a panoului cu campuri de text */
   cp.add(panel, BorderLayout.CENTER); 

   /* Se creeaza o "eticheta" pentru afisarea mesajelor */
   label=new JLabel("Introduceti date in campuri si urmariti efectul");
   label.setBorder(BorderFactory.createTitledBorder(
      "Afisarea mesajelor privind campurile de text"));
   cp.add(label, BorderLayout.SOUTH);

   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare a actiunilor asupra campurilor de text */
 static class Actiuni implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    JTextField sursa=(JTextField)e.getSource();
    String text=e.getActionCommand(),
           text1="Ati introdus in campul ";
    if(sursa==iug.tf1) 
      iug.label.setText(text1+"1 textul: "+text);
    else if(sursa==iug.tf2)
      try {
       int n=Integer.parseInt(text);
       iug.label.setText(text1+" 2 numarul intreg "+n);
      }
      catch(Exception e1) {
       iug.label.setText("In campul 2 nu este un numar intreg!");
      }
    else if(sursa==iug.tf3)
      try {
       double d=Double.parseDouble(text);
       iug.label.setText(text1+"3 numarul real "+d);
      }
      catch(Exception e2) {
       iug.label.setText("In campul 3 nu este un numar real!");
      }
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  