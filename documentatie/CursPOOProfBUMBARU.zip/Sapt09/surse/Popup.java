import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Popup { 
 static AF af=new AF();
 static AA aa=new AA();
 static AfisPopup afisare=new AfisPopup();
 static IUG iug=new IUG("Exemplu de menu pop-up");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JPopupMenu popup;
  JLabel label;
  JMenuItem mi1, mi2, mi3;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(350, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
 
   /* Se creeaza meniul pop-up */
   popup=new JPopupMenu();
   
   /* Se creaza articole de menu si se adauga la meniuri */
   mi1=new JMenuItem("A");
   mi1.addActionListener(aa);
   popup.add(mi1);
   mi2=new JMenuItem("B");
   mi2.addActionListener(aa);
   popup.add(mi2);
   mi3=new JMenuItem("C");
   mi3.addActionListener(aa);
   popup.add(mi3);
   
   /* Se creeaza o "eticheta" pentru afisarea mesajelor */
   label=new JLabel(
    "Apasati pe aceasta eticheta butonul drept al mouse-ului");
   label.setBorder(BorderFactory.createTitledBorder(
      "Afisarea mesajelor privind selectarea articolelor de meniu"));
   cp.add(label, BorderLayout.SOUTH);

   /* Se adauga la eticheta label ascultatorul de mouse pentru 
      afisarea meniului popup
   */
   label.addMouseListener(afisare);
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare de mouse pentru afisarea meniului pop-up */
 static class AfisPopup extends MouseAdapter {
  public void mousePressed(MouseEvent e) {
   if((e.getModifiers()&InputEvent.BUTTON3_MASK)!=0)
    iug.popup.show(e.getComponent(), e.getX(), e.getY());         
  }
 }
  
 /* Ascultator de actiuni pentru articolele de menu */
 static class AA implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    iug.label.setText("A fost selectata optiunea: "+
         e.getActionCommand());
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  