import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Meniuri { 
 static AF af=new AF();
 static AA aa=new AA();
 static IUG iug=new IUG("O fereastra cu bara de menu");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JMenuBar menuBar;
  JMenu menu1, menu2;
  JLabel label;
  JMenuItem mi1, mi2, mi3, mi4, mi5;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(350, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   menuBar=new JMenuBar(); // se creeaza bara de menu
   setJMenuBar(menuBar); // bara de menu se adauga la fereastra 
   /* Se creeaza meniurile si se adauga la bara de meniu */
   menu1=new JMenu("Un menu");
   menuBar.add(menu1);
   menu2=new JMenu("Alt menu");
   menuBar.add(menu2);
   /* Se creaza articole de menu si se adauga la meniuri */
   mi1=new JMenuItem("A");
   mi1.addActionListener(aa);
   menu1.add(mi1);
   mi2=new JMenuItem("B");
   mi2.addActionListener(aa);
   menu1.add(mi2);
   mi3=new JMenuItem("C");
   mi3.addActionListener(aa);
   menu2.add(mi3);
   /* La menu2 se aduga un submeniumenu cu doua articole */
   JMenu menu3=new JMenu("Un submeniu");
   mi4=new JMenuItem("Alpha");
   mi4.addActionListener(aa);
   menu3.add(mi4);
   mi5=new JMenuItem("Beta");
   mi5.addActionListener(aa);
   menu3.add(mi5);
   menu2.add(menu3);
   
   /* Se creeaza o "eticheta" pentru afisarea mesajelor */
   label=new JLabel("Selectati articole de meniu si urmariti efectul");
   label.setBorder(BorderFactory.createTitledBorder(
      "Afisarea mesajelor privind selectarea articolelor de meniu"));
   cp.add(label, BorderLayout.SOUTH);

   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Ascultator de actiuni pentru articolele de menu */
 static class AA implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    iug.label.setText("A fost selectata optiunea: "+
         e.getActionCommand());
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  