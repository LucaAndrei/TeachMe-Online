import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;


class TestRigla { 
 static AF af=new AF();
  static AscultRigla ascult=new AscultRigla();
 static IUG iug=new IUG("O rigla ajustabila");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JSlider rigla;
  JLabel label;
  

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(450, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra

   /* Se creeaza o "eticheta" pentru afisarea mesajelor */
   label=new JLabel("Deplasati cursorul riglei si urmariti efectul");
   label.setBorder(BorderFactory.createTitledBorder(
      "Afisarea mesajelor privind valoarea ajustata"));
   cp.add(label, BorderLayout.SOUTH);

   rigla=new JSlider(JSlider.HORIZONTAL, -20, 80, 35);
   rigla.setBorder(BorderFactory.createTitledBorder(
         "Ajustarea valorii"));
   rigla.setMajorTickSpacing(10);
   rigla.setMinorTickSpacing(1);
   rigla.setPaintTicks(true);
   rigla.setPaintLabels(true);
   rigla.addChangeListener(ascult);

   cp.add(rigla, BorderLayout.CENTER);

   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare a evenimentelor de ajustare a riglei */
 static class AscultRigla implements ChangeListener {
  public void stateChanged(ChangeEvent e) {
    iug.label.setText("Noua valoare: "+iug.rigla.getValue());
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  