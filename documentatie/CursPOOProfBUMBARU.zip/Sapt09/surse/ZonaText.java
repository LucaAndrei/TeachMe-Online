import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ZonaText { 
 static AF af=new AF();
// static AA aa=new AA();
 //static AfisPopup afisare=new AfisPopup();
 static IUG iug=new IUG("O zona de text");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JTextArea ta;
  JLabel label;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(450, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   ta=new JTextArea ();
   ta.setLineWrap(true);
   ta.setWrapStyleWord(true);
   cp.add(ta, BorderLayout.CENTER);

   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

  

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  