import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class TestComp { 
 static AF af=new AF();
 static IUG iug=new IUG("Butoane cu diferite aspecte");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  //JLabel lab1, lab2, lab3, lab4;
  //JPanel panel;
  JButton b1,b2,b3,b4,b5,b6,b7;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(250, 350);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   //panel=new JPanel();
   cp.setLayout(new GridLayout(7,1));
   //panel.setBackground(Color.red);
   b1=new JButton("Un buton obisnuit");
   //b1.setBackground(Color.blue);
   b2=new JButton("Un buton cu bordura liniara");
   b2.setBorder(BorderFactory.createLineBorder(Color.red, 4));
   b2.setToolTipText("Bordura este rosie cu grosimea 4");
   b3=new JButton("Un buton cu bordura cu titlu");
   b3.setBorder(BorderFactory.createTitledBorder("Un titlu"));
   b4=new JButton("Un buton ridicat");
   b4.setBorder(BorderFactory.createRaisedBevelBorder());
   b5=new JButton("Un buton coborat");
   b5.setBorder(BorderFactory.createLoweredBevelBorder());
   b6=new JButton(new ImageIcon("buton_go.gif"));
   b6.setBorder(BorderFactory.createTitledBorder(
      "Un buton cu titlu, care contine o imagine"));
   b7=new JButton("Un buton cu bordura compusa");
   Border bord1, bord2, bord3;
   bord1=BorderFactory.createBevelBorder(BevelBorder.RAISED,
      Color.green, Color.blue);
   bord2=BorderFactory.createBevelBorder(BevelBorder.LOWERED,
      Color.cyan, Color.yellow);
   bord3=BorderFactory.createCompoundBorder(bord1, bord2);
   b7.setBorder(bord3);
   cp.add(b1);
   cp.add(b2);
   cp.add(b3);
   cp.add(b4);
   cp.add(b5);
   cp.add(b6);
   cp.add(b7);
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }
   
 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  