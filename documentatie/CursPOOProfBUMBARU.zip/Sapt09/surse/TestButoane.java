import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class TestButoane { 
 static AF af=new AF();
 static Ascultator ascult=new Ascultator();
 static IUG iug=new IUG("Diferite tipuri de butoane");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JButton b1,b2;
  JCheckBox cb1, cb2;
  JRadioButton rb1, rb2, rb3;
  ButtonGroup grup;
  Box box1, box2, box3, box4;
  JLabel label;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(300, 150);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   /* Se creeaza doua butoane, b1 si b2, care se pun in caseta box1 */
   b1=new JButton("B1 (F1)");
   b1.addActionListener(ascult);
   b1.setMnemonic(KeyEvent.VK_F1);
   b2=new JButton("B2 (F2)");
   b2.addActionListener(ascult);
   b2.setMnemonic(KeyEvent.VK_F2);
   box1=Box.createVerticalBox();
   box1.add(new JLabel("Butoane simple"));
   box1.add(b1);
   box1.add(b2);
   /* Se creeaza doua casete de validare, care se pun in box2 */
   cb1=new JCheckBox("Caseta 1 (A)");
   cb1.addItemListener(ascult);
   cb1.setMnemonic(KeyEvent.VK_A);
   cb2=new JCheckBox("Caseta 2 (S)");
   cb2.addItemListener(ascult);
   cb2.setMnemonic(KeyEvent.VK_S);
   box2=Box.createVerticalBox();
   box2.add(new JLabel("Casete validare"));
   box2.add(cb1);
   box2.add(cb2);
   /* Se creeaza trei butoane radio, care se grupeaza si se
      pun in box3 
   */
   rb1=new JRadioButton("BR 1 (F5)");
   rb1.setMnemonic(KeyEvent.VK_F5);
   rb1.addActionListener(ascult);
   rb2=new JRadioButton("BR 2 (F6)");
   rb2.setMnemonic(KeyEvent.VK_F6);
   rb2.addActionListener(ascult);
   rb3=new JRadioButton("BR 3 (F7)");
   rb3.setMnemonic(KeyEvent.VK_F7);
   rb3.addActionListener(ascult);
   box3=Box.createVerticalBox();
   box3.add(new JLabel("Butoane radio"));
   box3.add(rb1);
   box3.add(rb2);
   box3.add(rb3);
   grup=new ButtonGroup();
   grup.add(rb1);
   grup.add(rb2);
   grup.add(rb3);
   /* box1, box2 si box3 se pun in box4 , iar aceasta 
      se pune in controlPane
   */
   box4=Box.createHorizontalBox();
   box4.add(Box.createHorizontalGlue());
   box4.add(box1);
   box4.add(Box.createHorizontalStrut(15));
   box4.add(box2);
   box4.add(Box.createHorizontalStrut(15));
   box4.add(box3);
   box4.add(Box.createHorizontalGlue());
   cp.add(box4, BorderLayout.CENTER);
   label=new JLabel("Actionati butoanele si urmariti mesajul");
   cp.add(label, BorderLayout.SOUTH);
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare de actiuni si de selectari */
 static class Ascultator implements ActionListener, ItemListener {
  public void actionPerformed(ActionEvent e) {
    iug.label.setText("A fost apasat butonul "+e.getActionCommand());
  }
  public void itemStateChanged(ItemEvent e) {
    JCheckBox cb=(JCheckBox)e.getItem();
    String selectie;
    if(cb.isSelected()) selectie="A fost selectata ";
    else selectie="A fost deselectata ";
    iug.label.setText(selectie+cb.getText());
  }
 }
   
 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  