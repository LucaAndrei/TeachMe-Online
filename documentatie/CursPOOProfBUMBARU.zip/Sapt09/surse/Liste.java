import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;


class Liste { 
 static AF af=new AF();
 static AAL ascult=new AAL();
 static AEA ascult1=new AEA();
 static IUG iug=new IUG("Diferite tipuri de liste");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JList lista1, lista2;
  JComboBox combo;
  JLabel label;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(350, 240);
   setLocation(200, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra

   /* Se creeaza o lista cu zilele saptamanii. Listei nu i se pune
      un model de selectie, deci se pot face implicit selectii 
      multiple intr-o singura zona continua
   */
   String zile[]={"Luni", "Marti", "Miercuri", "Joi", "Vineri",
         "Sambata", "Duminica"};
   lista1=new JList(zile);
   lista1.setBorder(BorderFactory.createTitledBorder(
         "Lista"));
   lista1.addListSelectionListener(ascult); // ascultarea listei
   cp.add(lista1, BorderLayout.WEST);

   /* Se creeaza o lista cu lunile anului, pusa intr-un panou
      glisant. Listei i se pune un model de selectie care 
      permite numai selectarea unui singur articol 
   */
   String luni[]={"Ianuarie", "Februarie", "Martie", "Aprilie",
      "Mai", "Iunie", "Iulie", "August", "Septembrie", 
      "Octombrie", "Noiembrie", "Decembrie"};
   lista2=new JList(luni);
   lista2.setBorder(BorderFactory.createTitledBorder(
         "Lista glisanta"));
   lista2.setSelectionModel(new DefaultListSelectionModel());
   lista2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

   lista2.addListSelectionListener(ascult);
   JScrollPane scroll=new JScrollPane(lista2); // panoul glisant 
      // care contine lista nou creata, lista2
   cp.add(scroll, BorderLayout.CENTER);

   /* Se creeaza o lista ascunsa (din clasa JComboBox) */
   String ordinea[]={"Primul            ", "Al doilea", 
    "Al treilea", "Al patrulea"};
   combo=new JComboBox(ordinea);
   combo.setBorder(BorderFactory.createTitledBorder(
     "Lista ascunsa"));
   combo.addItemListener(ascult1);
   JPanel panel=new JPanel();
   panel.add(combo);
   cp.add(panel, BorderLayout.EAST);

   /* Se creeaza o "eticheta" pentru afisarea mesajelor */
   label=new JLabel("Selectati articolele si urmariti efectul");
   label.setBorder(BorderFactory.createTitledBorder(
      "Afisarea mesajelor privind articolele selectate"));
   cp.add(label, BorderLayout.SOUTH);
   setVisible(true);
  }
 }   

 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare de selectari ale articolelor de lista
    folosita pentru JList. La aparitia unui astfel de
    eveniment, se afiseaza toate articolele selectate din
    lista sursa
 */
 static class AAL implements ListSelectionListener {
  public void valueChanged(ListSelectionEvent e) {
    JList sursa=(JList)e.getSource();
    Object selectie[]=sursa.getSelectedValues();
    StringBuffer buff=new StringBuffer();
    for(int i=0; i<selectie.length; i++)
       buff.append(selectie[i].toString()+" "); 
    iug.label.setText(buff.toString());
  }
 }

 /* Clasa ascultatoare de evenimente de articol 
    folosita pentru JComboBox. La aparitia unui astfel
    de eveniment, se afiseaza articolul care l-a produs
 */
 static class AEA implements ItemListener {
  public void itemStateChanged(ItemEvent e) {
    iug.label.setText(e.getItem().toString());
  }
 }
   
 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  