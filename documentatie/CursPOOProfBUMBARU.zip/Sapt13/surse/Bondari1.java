import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Bondari1 extends JFrame {
  Bondar b1,b2;
  Thread fir1, fir2, fir3;
  Fereastra fereastra;
  CutiePostala cutiePostala;

  public Bondari1() {
    super("Doi bondari in acelasi spatiu");
    b1=new Bondar();
    fir1=new Thread(b1);
    b1.fir=fir1;
    b2=new Bondar();
    fir2=new Thread(b2);
    b2.fir=fir2;
    Box box1=Box.createHorizontalBox();
    box1.add(b1);
    box1.add(b2);
    Box box2=Box.createVerticalBox();
    fereastra=new Fereastra();
    fir3=new Thread(fereastra);
    fereastra.setSize(200,200);
    fereastra.setBackground(Color.cyan);
    box2.add(box1);
    box2.add(fereastra);
    Container cp1=getContentPane();
    cp1.setLayout(new FlowLayout());
    cp1.add(box2);
    addWindowListener(new Iesire());
    setSize(500,400);
    setVisible(true);
    cutiePostala=new CutiePostala();
    fir1.start();
    fir2.start();
    fir3.start();
  }

  class Bondar extends JPanel implements Runnable {
    Thread fir;
    JSlider perioada, amplitudine;
    int x, y;

    public Bondar() {
      perioada=new JSlider(JSlider.HORIZONTAL, 100, 500, 200);
      perioada.setBorder(BorderFactory.createTitledBorder( 
         "Perioada saltului")); 
      perioada.setMajorTickSpacing(200); 
      perioada.setMinorTickSpacing(100); 
      perioada.setPaintTicks(true); 
      perioada.setPaintLabels(true); 
      amplitudine=new JSlider(JSlider.HORIZONTAL, 0, 40, 10);
      amplitudine.setBorder(BorderFactory.createTitledBorder( 
         "Amplitudinea saltului"));  
      amplitudine.setMajorTickSpacing(20); 
      amplitudine.setMinorTickSpacing(2); 
      amplitudine.setPaintTicks(true); 
      amplitudine.setPaintLabels(true);
      Box box=Box.createVerticalBox(); 
      box.add(perioada);
      box.add(amplitudine);
      getContentPane().add(box);  
    }

    public void run() {
     Rectangle r=fereastra.getBounds();
     x=(int)(r.width*(Math.random()));
     y=(int)(r.height*(Math.random()));
     for(; ; ) {
      x+=(int)(amplitudine.getValue()*(Math.random()-0.5));
      if(x<0) x=0;
      else if(x>r.width-10) x=r.width-10;
      y+=(int)(amplitudine.getValue()*(Math.random()-0.5));       
      if(y<0) y=0;
      else if(y>r.height-10) y=r.height-10;
      cutiePostala.amPus();   
      try {
        fir.sleep(perioada.getValue());
      }
      catch(Exception e) {
        System.out.println(e);
      }
     }
    }
  }

  class Fereastra extends Canvas implements Runnable {
    
    public void paint(Graphics g) {
     g.setColor(Color.green);
     g.fillRect(b1.x,b1.y,10,10);
     g.setColor(Color.red);
     g.drawRect(b1.x,b1.y,10,10);
     g.setColor(Color.blue);
     g.fillRect(b2.x,b2.y,10,10);
     g.setColor(Color.red);
     g.drawRect(b2.x,b2.y,10,10);
    }

    public void run() {
     for(;;) {
      repaint();
      cutiePostala.amLuat();
     }
    }

  }

  class CutiePostala {
    boolean valoareNoua=false;
    
    synchronized void amPus() {
      while(valoareNoua) {
        try {
          wait();
        }
        catch(Exception e) {}
      }
      valoareNoua=true;
      notifyAll();
    }

    synchronized void amLuat() {
      while(!valoareNoua) {
        try {
          wait();
        }
        catch(Exception e) {}
      }
      valoareNoua=false;
      notifyAll();
    }
  }
      

  class Iesire extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
  }

  public static void main(String args[]) {
    Bondari1 b=new Bondari1();
  }
}

    