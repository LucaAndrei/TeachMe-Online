/* Crearea si utilizarea unei clase cu interfata Runnable.
   Se foloseste metoda yield() pentru a ceda controlul altui fir de
   aceeasi prioritate.
   Se creeaza doua fire de aceeasi prioritate (Thread.NORM_PRIORITY),
   utilizand ca argument al constructorului instante ale clasei
   Fir cu interfata Runnable.
*/

class DouaFireAR {

  /* Clasa cu interfata Runnable */
  static class Fir implements Runnable {

    /* Definirea metodei run() din interfata Runnable */
    public void run() {
     System.out.println("Incepe executarea firului "+
       Thread.currentThread().getName());
     for(int i=0; i<6; i++) {
      System.out.println("Firul "+
        Thread.currentThread().getName()+" ciclul i="+i);
      Thread.yield(); // cedarea controlului procesorului
     }
    }
  } /* incheierea clasei Fir */

  public static void main(String args[]) throws Exception {
    Thread fir1, fir2;
    System.out.println("Se creeaza firul Alpha");
    fir1=new Thread(new Fir(), "Alpha");
    System.out.println("Se creeaza firul Beta");
    fir2=new Thread(new Fir(), "Beta");
    System.out.println("Se pune in executie firul Alpha");
    fir1.start();
    System.out.println("Se pune in executie firul Beta");
    fir2.start();
    System.out.println("Sfarsitul metodei main()");
  } /* Sfarsitul metodei main() */
}
     