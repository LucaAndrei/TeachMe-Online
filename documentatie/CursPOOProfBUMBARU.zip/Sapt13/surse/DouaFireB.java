/* Crearea si utilizarea unei clase de fire de executie. In metoda 
   run a firului nu se folosesc metodele sleep() sau yield(), dar se 
   parcurge un ciclu de contorizare (pe j) de 100000000 ori pentru a
   mari durata de executie a ciclului exterior (pe indicele i).
   Se creeaza doua fire de aceeasi prioritate (Thread.NORM_PRIORITY).
*/

class DouaFireB {

  /* Clasa firelor de executie */
  static class Fir extends Thread {

    Fir(String numeFir) {
      super(numeFir);
      System.out.println("S-a creat firul "+getName());
    }

    /* Redefinirea metodei run() din clasa Thread */
    public void run() {
     System.out.println("Incepe executarea firului "+getName());
     for(int i=0; i<5; i++) {
      for(int j=0; j<100000000; j++);
      System.out.println("Firul "+getName()+" ciclul i="+i);
     }
    }
  } /* incheierea clasei Fir */

  public static void main(String args[]) throws Exception {
    Fir fir1, fir2, fir3;
    System.out.println("Se creeaza firele Alpha si Beta");
    fir1=new Fir("Alpha");
    fir2=new Fir("Beta");
    System.out.println("Se pun in executie cele doua fire");
    fir1.start();
    fir2.start();
    for (int i=0; i<5; i++) {
      for(int j=0; j<100000000; j++);
      System.out.println("main() ciclul i="+i);
    }
    System.out.println("Sfarsitul metodei main()");
  } /* Sfarsitul metodei main() */
}
     