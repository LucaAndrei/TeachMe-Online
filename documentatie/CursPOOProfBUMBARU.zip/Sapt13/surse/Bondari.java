import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Bondari extends JFrame {
  JButton nouBondar;

  public Bondari() {
    super("Bondari");
    nouBondar=new JButton("Creare nou bondar");
    nouBondar.addActionListener(new CreareBondar());
    getContentPane().add(nouBondar, BorderLayout.NORTH);    
    addWindowListener(new Iesire());
    setSize(200,100);
    setLocation(new Point(0,20));
    setVisible(true);
  }

  /* Clasa cu  interfata Runnable pentru un fir de executie
     cu interfata grafica
  */
  class Bondar extends JFrame implements Runnable {
    JSlider perioada, amplitudine;
    Fereastra fereastra;
    Thread fir;
    boolean esteViu;

    public Bondar() {
      perioada=new JSlider(JSlider.HORIZONTAL, 100, 500, 200);
      perioada.setBorder(BorderFactory.createTitledBorder( 
         "Perioada saltului")); 
      perioada.setMajorTickSpacing(200); 
      perioada.setMinorTickSpacing(100); 
      perioada.setPaintTicks(true); 
      perioada.setPaintLabels(true); 
      amplitudine=new JSlider(JSlider.HORIZONTAL, 0, 40, 10);
      amplitudine.setBorder(BorderFactory.createTitledBorder( 
         "Amplitudinea saltului"));  
      amplitudine.setMajorTickSpacing(20); 
      amplitudine.setMinorTickSpacing(2); 
      amplitudine.setPaintTicks(true); 
      amplitudine.setPaintLabels(true);
      fereastra=new Fereastra();
      fereastra.setSize(200,200);
      fereastra.setBackground(Color.cyan);
      fereastra.culoare=Color.red;
      Box box=Box.createVerticalBox(); 
      box.add(perioada);
      box.add(amplitudine);
      box.add(fereastra);
      getContentPane().add(box);
      addWindowListener(new SfarsitBondar(this));
      setSize(200,350);
      setVisible(true);
    }

    /* Definirea metodei run() a interfetei Runnable */
    public void run() {
     Rectangle r=fereastra.getBounds();
     fereastra.x=r.width/2;
     fereastra.y=r.height/2;
     esteViu=true;
     while(esteViu) {
      fereastra.ampl=amplitudine.getValue();
      fereastra.repaint();       
      try {
        fir.sleep(perioada.getValue());
      }
      catch(Exception e) {
        System.out.println(e);
      }
     }
    }
  } /* Sfarsitul clasei Bondar */

  /* Fereastra in care evolueaza "bondarul" */
  class Fereastra extends Canvas {
    int x, y, ampl;
    Color culoare;

    public void paint(Graphics g) {
     Rectangle r=getBounds();
     x+=(int)(ampl*(Math.random()-0.5));
     if(x<0) x=0;
     else if(x>=r.width) x=r.width-5;
     y+=(int)(ampl*(Math.random()-0.5));
     if(y<0) y=0;
     else if(y>=r.height) y=r.height-5;
     g.setColor(culoare);
     g.fillRect(x,y,10,10);
     g.setColor(Color.red);
     g.drawRect(x,y,10,10); 
    }
  } /* Sfarsitul clasei Fereastra */

  /* Incheierea executarii aplicatiei */
  class Iesire extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
  } /* Sfarsitul clasei Iesire */

  /* Crearea si lansarea unui nou fir de executie */
  class CreareBondar implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      int x,y;
      x=(int)(Math.random()*400);
      y=(int)(Math.random()*200);
      Bondar bondar=new Bondar();
      bondar.setLocation(new Point(x,y));
      Thread thread=new Thread(bondar);
      thread.start();
    }
  } /* Sfarsitul clasei CreareBondar */

  /* Incheierea executarii unui fir de executie */
  class SfarsitBondar extends WindowAdapter {
    Bondar bondar;
    SfarsitBondar(Bondar bondar) {
      this.bondar=bondar;
    }

    public void vindowClosing(WindowEvent e) {
      bondar.esteViu=false;
    }
  } /* Sfarsitul clasei SfarsitBondar */

  /* Metoda  principala a aplicatiei */
  public static void main(String args[]) {
    Bondari b=new Bondari();
  }
}

    