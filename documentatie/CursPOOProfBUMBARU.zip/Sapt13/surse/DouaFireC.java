/* Crearea si utilizarea unei clase de fire de executie. In metoda 
   run a firului se foloseste metoda sleep(1000) pentru a pune 
   firul in asteptare pe o durata de 1000 milisecunde. Similar se
   procedeaza in metoda main()
*/

class DouaFireC {

  /* Clasa firelor de executie */
  static class Fir extends Thread {

    Fir(String numeFir) {
      super(numeFir);
      System.out.println("S-a creat firul "+getName());
    }

    /* Redefinirea metodei run() din clasa Thread */
    public void run() {
     System.out.println("Incepe executarea firului "+getName());
     for(int i=0; i<5; i++) {
      System.out.println("Firul "+getName()+" ciclul i="+i);
      try {
        sleep(1000);
      }
      catch(InterruptedException e) {}
     }
    }
  } /* incheierea clasei Fir */

  public static void main(String args[]) throws Exception {
    Fir fir1, fir2, fir3;
    System.out.println("Se creeaza firele Alpha si Beta");
    fir1=new Fir("Alpha");
    fir2=new Fir("Beta");
    System.out.println("Se pun in executie cele doua fire");
    fir1.start();
    fir2.start();
    for (int i=0; i<5; i++) {
      System.out.println("main() ciclul i="+i);
      try {
        Thread.sleep(1000);
      }
      catch(InterruptedException e) {}
    }
    System.out.println("Sfarsitul metodei main()");
  } /* Sfarsitul metodei main() */
}
     