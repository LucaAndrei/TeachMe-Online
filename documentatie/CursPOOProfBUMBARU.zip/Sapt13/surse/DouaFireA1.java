/* Crearea si utilizarea unei clase de fire de executie care
   extinde clasa Thread. Se foloseste metoda yield() pentru 
   a ceda controlul altui fir de aceeasi prioritate.
   Se creeaza doua fire de aceeasi prioritate (Thread.NORM_PRIORITY).
*/

class DouaFireA1 {

  /* Clasa firelor de executie */
  static class Fir extends Thread {

    Fir(String numeFir) {
      super(numeFir);
      System.out.println("S-a creat firul "+getName());
    }

    /* Redefinirea metodei run() din clasa Thread */
    public void run() {
     System.out.println("Incepe executarea firului "+getName());
     for(int i=0; i<6; i++) {
      System.out.println("Firul "+getName()+" ciclul i="+i);
      yield(); // cedarea controlului procesorului
     }
    }
  } /* incheierea clasei Fir */

  public static void main(String args[]) throws Exception {
    Fir fir1, fir2;
    System.out.println("Se creeaza firul Alpha");
    fir1=new Fir("Alpha");
    System.out.println("Se creeaza firul Beta");
    fir2=new Fir("Beta");
    System.out.println("Se pune in executie firul Alpha");
    fir1.start();
    System.out.println("Se pune in executie firul Beta");
    fir2.start();
    System.out.println("Sfarsitul metodei main()");
  } /* Sfarsitul metodei main() */
}
     