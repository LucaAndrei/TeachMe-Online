class Sincro {
  Producator prod;
  Consumator cons;
  Monitor monit;
  int nrCicluri;

  /* Clasa Producator. Producatorul genereaza un tablou de date si
     il pune in monitor pentru a fi transmis consumatorului
  */
  class Producator extends Thread {
    public void run() {
      System.out.println("Incepe executarea firului producator");
      for (int i=0; i<nrCicluri; i++) {
        int n=((int)(5*Math.random()))+2;
        int tab[]=new int[n];
        for(int j=0; j<n; j++)
          tab[j]=(int)(1000*Math.random());
        monit.puneTablou(tab);
        System.out.print("Ciclul i="+i+" S-a pus tabloul: ");
        for(int j=0; j<n; j++) System.out.print(tab[j]+" ");
        System.out.println();
      }
      System.out.println("Sfarsitul executiei firului Producator");
    }
  } /* Sfarsitul clasei Producator */

  /* Clasa Consumator. Consumatorul foloseste (in cazul de fata
     doar afiseaza) datele preluate din monitor
  */
  class Consumator extends Thread {
    public void run() {
      System.out.println("Incepe executarea firului Consumator");
      int tab[];
      for(int i=0; i<nrCicluri; i++) {
        tab=monit.preiaTablou();
        System.out.print("Ciclul i="+i+
          " s-a preluat tabloul ");
        for(int j=0; j<tab.length; j++)
          System.out.print(tab[j]+" ");
        System.out.println();
      }
      System.out.println("Sfarsitul executiei firului Consumator");
    }
  } /* Sfarsitul clasei Consumator */

  /* Clasa Monitor. Monitorul contine date si metode folosite in
     comun de Producator si Consumator. In acest scop, producatorul
     si consumatorul folosesc metodele sincronizate ale monitorului
  */
  class Monitor {
    int tab[]; // tabloul de date care se transmit
    boolean valoriNoi=false; // variabila de conditie a monitorului

    /* Metoda prin care producatorul pune date in monitor */
    public synchronized void puneTablou(int tab[]) {
      if(valoriNoi) { 
        try {
          wait(); // se asteapta sa fie folosite datele puse anterior
       }
        catch(InterruptedException e) {}
      }
      this.tab=tab; // se modifica tabloul tab din monitor
      valoriNoi=true; // monitorul contine date noi
      notify(); // se notifica consumatorul ca s-au pus date noi
    }

    /* Metoda prin care consumatorul preia datele din monitor */
    public synchronized int[] preiaTablou() {
      if(!valoriNoi) {
        try {
          wait(); // se asteapta sa se puna date noi
        }
        catch(InterruptedException e) {}
      }
      valoriNoi=false; // datele puse anterior au fost folosite
      notify(); // se notifica producatorul ca datele au fost preluate
      return tab;
    }
  } /* Sfarsitul clasei Monitor */

  public Sincro(int numarCicluri) {
    nrCicluri=numarCicluri;
    prod=new Producator();
    cons=new Consumator();
    monit=new Monitor();
    prod.start();
    cons.start();
  }

  public static void main(String args[]) {
    int numarCicluri=8;
    System.out.println("Incepe executarea metodei main()");
    Sincro sinc=new Sincro(numarCicluri);
    System.out.println("Sfarsitul metodei main()");
  }
}
