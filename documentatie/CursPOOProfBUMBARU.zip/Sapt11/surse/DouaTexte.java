import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class DouaTexte extends Applet {
   Button b=new Button("Buton pentru schimbare text");
   Label  lab=new Label("Textul initial");
   String text1, text2;
   Actiune act=new Actiune();
   int k=2;

   public void init() {
      text1=getParameter("textul1");
      text2=getParameter("textul2");
      setLayout(new GridLayout(2,1));
      add(b);
      add(lab);
      setBackground(Color.cyan);
      b.addActionListener(act);
      b.setBackground(Color.magenta);
      setVisible(true);
   }

   class Actiune implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         k++;
         if(k>2) k=1;
         if(k==1) {
            lab.setText(text1);
            lab.setBackground(Color.blue);
            lab.setForeground(Color.yellow);
         } else {
            lab.setText(text2);
            lab.setBackground(Color.green);
            lab.setForeground(Color.black);
         }
         setVisible(true);
      }
   }
}
