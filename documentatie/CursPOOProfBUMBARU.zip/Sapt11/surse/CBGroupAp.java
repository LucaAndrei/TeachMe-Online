/* Applet prin care se testeaza clasele Checkbox si CheckboxGroup. Appletul
contine trei casete ("butoane radio") si o instanta a clasei    Label in care
se afiseaza eticheta casetei selectate in momentul respectiv */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/* Appletul propriu-zis. Se construiesc obiectele grafice: casetele de
   validare ("butoanele radio") cb1, cb2, cb3 si eticheta lab. Casetele sunt
   toate afectate grupului cbgr construit in prealabil. Se construieste, de
   asemenea, obiectul ecb care intercepteaza si trateaza evenimentele
   generate de casetele de validare. Interceptorul ecb este inregistrat sa
   asculte evenimentele generate de casetele de validare. Constructorul
   interceptorului primeste ca argumente referinte la grupul de casete si la o
   eticheta unde se va afisa eticheta casetei  curenta a acestei casete. 
*/

public class CBGroupAp extends Applet {
   CheckboxGroup cbgr=new CheckboxGroup();
   Checkbox cb1=new Checkbox("CB1", false, cbgr), 
            cb2=new Checkbox("CB2", true,cbgr),
            cb3=new Checkbox("CB3", false, cbgr);
   Label lab=new Label();
   EvCheckboxGroup ecb=new EvCheckboxGroup();

   public void init() {
      cb1.addItemListener(ecb);
      cb2.addItemListener(ecb);
      cb3.addItemListener(ecb);
      cb1.setBackground(Color.cyan);
      cb2.setBackground(Color.cyan);
      cb3.setBackground(Color.cyan);
      lab.setBackground(Color.green);
      lab.setAlignment(Label.CENTER);
      setLayout(new BorderLayout());
      add("North",lab);
      add("West",cb1);
      add("Center",cb2);
      add("East",cb3);
      setVisible(true);
   }
   
   /* Clasa imbricata EvCheckboxGroup implementeaza interfata ItemtListener.
      Instantele ei intercepteaza evenimentele de comutare generate de Checkbox
      si introduc in eticheta din applet starea preluata, atunci cand ea se
      modifica 
   */
   
   class EvCheckboxGroup implements ItemListener {
      
      public void itemStateChanged(ItemEvent e) {
         Checkbox cb=cbgr.getSelectedCheckbox();
         lab.setText("S-a selectat caseta: "+cb.getLabel());
      }
   }      
}

