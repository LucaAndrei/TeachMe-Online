/* Un prim applet */

import java.awt.*;
import java.applet.*;

public class PrimApplet extends Applet {
  
   public void paint(Graphics g) {
      g.drawString("Primul nostru applet", 5,50);
   }
}

