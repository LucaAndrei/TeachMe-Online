/* Aplet de testare a gestionarului de pozitionare FlowLayout.
   In cadru exista 2 butoane de comanda: Pune si Elimina. Exista, de asemenea,
   un grup de 3 casete de validare (butoane radio): Stanga, Centru, Dreapta. La
   fiecare apasare pe butonul "Pune", pe suprafata appletului se mai pune o
   eticheta, iar la apasarea pe butonul "Elimina" , se elimina ultima
   eticheta din applet. Apasarea pe oricare din cele trei butoane radio
   comanda alinierea corespunzatoare.Se admit cel mult 20 etichete
*/

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class TestFlowAp extends Applet {
   Label tlab[]=new Label[20];
   FlowLayout fl=new FlowLayout();
   
   public void init() {
      /* Construirea obiectelor grafice */
      Button pune=new Button("Pune");
      Button elimina=new Button("Elimina");
      CheckboxGroup cbg=new CheckboxGroup();
      Checkbox stanga=new Checkbox("Stanga", false, cbg);
      Checkbox centru=new Checkbox("Centru", true, cbg);
      Checkbox dreapta=new Checkbox("Dreapta", false, cbg);
      /* Construirea interceptoarelor de evenimente */
      ApasButon ab=new ApasButon(this);
      SelectAlin sa=new SelectAlin(this);
      /* Construirea celor 20 etichete si setarea culorii de fond */
      for(int i=0; i<20; i++) {
         tlab[i]=new Label("Eticheta nr. "+(i+1));
         tlab[i].setBackground(Color.cyan);
      }
      /* Adaugarea la componente a interceptoarelor de evenimente si 
         setarea culorii de fond a fiecarii componente
      */
      setBackground(Color.yellow);
      pune.addActionListener(ab);
      pune.setBackground(Color.magenta);
      elimina.addActionListener(ab);
      elimina.setBackground(Color.magenta);
      stanga.addItemListener(sa);
      stanga.setBackground(Color.green);
      centru.addItemListener(sa);
      centru.setBackground(Color.green);
      dreapta.addItemListener(sa);
      dreapta.setBackground(Color.green);
      /* Stabilirea dimensiunii ferestrei si a gestionarului de pozitionare
         folosit
      */
      setLayout(fl);
      /* Adaugarea la fereastra principala a componentelor si vizualizarea */
      add(pune);
      add(elimina);
      add(stanga);
      add(centru);
      add(dreapta);
      setVisible(true);
   }
   
   
   /* Clasa care intercepteaza si trateaza evenimentele generate de butoane
   */
   
   static class ApasButon implements ActionListener {
      TestFlowAp ap;
      int contor;   
      ApasButon(TestFlowAp ap) {
         this.ap=ap;
         contor=0;
      }
      public void actionPerformed(ActionEvent e) {
         String actiune=e.getActionCommand();
         if(actiune.equals("Pune") && contor<20){
              ap.add(ap.tlab[contor]);
              contor++;
         }
         else if(actiune.equals("Elimina") && contor>0) {
              contor--;
              ap.remove(ap.tlab[contor]);
         }
         ap.fl.layoutContainer(ap);
         ap.setVisible(true);
      }
   }
   
   /* Clasa care intercepteaza si trateaza evenimentele generate de cele
      trei butoane radio
   */
   
   static class SelectAlin implements ItemListener {
      TestFlowAp ap;
      SelectAlin(TestFlowAp ap) {
         this.ap=ap;
      }
      public void itemStateChanged(ItemEvent e) {
         /* Se determina ce buton radio este selectat si ce eticheta are */
         Checkbox cb=(Checkbox)e.getItemSelectable();
         String cblab=cb.getLabel();
         /* Se seteaza alinierea corespunzatoare etichetei butonului radio
            selectat
         */
         if(cblab.equals("Stanga")) 
                ap.fl.setAlignment(FlowLayout.LEFT);  
                   else if(cblab.equals("Centru")) 
                 ap.fl.setAlignment(FlowLayout.CENTER);
         else if(cblab.equals("Dreapta")) 
                ap.fl.setAlignment(FlowLayout.RIGHT);
         /* Se efectueaza alinierea componentelor din container */
         ap.fl.layoutContainer(ap);
         ap.setVisible(true);
      }
   }            
}

