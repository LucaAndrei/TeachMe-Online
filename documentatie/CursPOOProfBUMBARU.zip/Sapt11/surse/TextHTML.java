/* Experimentarea folosirii marcajelor HTML in textele pentru
   componente JFC/Swing
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class TextHTML extends JFrame {
 JTextArea ta;
 JLabel label;
 Sfarsit sfarsit;
 /* Textul introdus initial in aria de text */
 String textInitial="<html>\n<h2>Proba HTML</h2>Text normal<br>\n"+
  "<i>Text italic <b>Text italic aldin</b></i><br>\n"+
  " <font face=serif color=blue size=4>\n"+
  "  Text albastru cu font serif\n </font>\n<p bgcolor=aqua>"+
  "Revenire la text normal<br>cu fond aqua\n</html>";

 /* Constructorul clasei TextHTML construieste interfata grafica */
 TextHTML() {
  super("Incercare de texte HTML");
  Container cp=getContentPane();
  sfarsit=new Sfarsit(); // incheierea executarii aplicatiei
  addWindowListener(sfarsit);
  ta=new JTextArea(15,10); // aria in care se introduce textul HTML
  ta.setLineWrap(true);
  ta.setWrapStyleWord(true);
  ta.append(textInitial);
  ta.setBorder(BorderFactory.createTitledBorder(
    "Introduceti aici un text HTML"));
  Box vb=Box.createVerticalBox();
  Box hb=Box.createHorizontalBox();
  vb.add(ta);
  String textButon="<html><font color=red size=4>"+
   "<b><i>Vizualizare text</i></b></font>";
  JButton buton=new JButton(textButon); // butonul de comanda a 
                                        // vizualizarii textului

  buton.addActionListener(new Vizualizare());
  buton.setBorder(BorderFactory.createRaisedBevelBorder());
  hb.add(buton);
  JButton reset=new JButton("<html><font color=blue size=4>"+
   "<b>Reset</b></font>"); // butonul de revenire la textul initial
  reset.setBorder(BorderFactory.createRaisedBevelBorder());
  reset.addActionListener(new Reset());
  hb.add(reset);
  vb.add(hb);
  cp.add(vb,BorderLayout.WEST);
  label=new JLabel(); // eticheta pe care se vizualizeaza textul HTML
  label.setBorder(BorderFactory.createTitledBorder(
   "Vizualizarea textului HTML"));
  label.setOpaque(true);
  label.setBackground(Color.white);
  cp.add(label,BorderLayout.CENTER);
  setLocation(50,50);
  setSize(450,300);
  setVisible(true);
 }

 /* Clasa de ascultare a inchiderii ferestrei principale*/
 class Sfarsit extends WindowAdapter { 
  public void windowClosing(WindowEvent e) {
   System.exit(0);
  }
 }

 /* clasa de ascultare a butonului de vizualizare a textului */
 class Vizualizare implements ActionListener { 
  public void actionPerformed(ActionEvent e) {
   try {
    /* afisarea pe componenta label a textului extras din 
       aria de text ta
    */
    label.setText(ta.getText());
   }
   catch(Exception ex) { // s-a constatat o eroare in textul HTML
    label.setText("Eroare de sintaxa HTML");
   }
  }
 }

 /* Clasa de ascultare a butonului de Reset */
 class Reset implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    ta.setText(textInitial);
    label.setText("");
  }
 }
 
 public static void main(String args[]) {
  TextHTML text=new TextHTML(); // instantierea aplicatiei
 }
}
