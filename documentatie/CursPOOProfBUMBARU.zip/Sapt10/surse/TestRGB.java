/* Alegerea culorilor in sistemul RGB (Red, Green, Blue) */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;


class TestRGB { 
 static AF af=new AF();
 static IUG iug=new IUG("Alegerea culorii in sistemul RGB"+
    " (Red, Green, Blue)");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  AjustCuloare red, green, blue; // rigle de ajustare a culorilor
  Box box1; // caseta riglelor de ajustare
  JPanel panouCuloare; // panoul pe care se prezinta culoarea
  Color culoare; // culoarea panoului panouCuloare

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(500, 200);
   setLocation(100, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   /* Se creeaza caseta cu dispozitive de ajustare */
   box1=Box.createVerticalBox();
   red=new AjustCuloare("Rosu      "); // ajustare rosu
   box1.add(red);
   green=new AjustCuloare("Verde     "); // ajustare verde
   box1.add(green);
   blue=new AjustCuloare("Albastru "); // ajustare albastru
   blue.ajustare.setPaintLabels(true);
   box1.add(blue);
   cp.add(box1, BorderLayout.WEST);
   panouCuloare=new JPanel(); // crearea panoului pentru culoare
   cp.add(panouCuloare, BorderLayout.CENTER);
   puneCuloarea();  // se pune culoarea initiala
   setVisible(true);
  }

  /* Metoda de determinare a culorii RGB */
  void puneCuloarea() {
   culoare=new Color(red.val, green.val, blue.val);
   panouCuloare.setBackground(culoare);  
  }
 }   

 /* Un "dispozitiv" de ajustare a valorii unei culori */

 static class AjustCuloare extends Box implements ChangeListener {
  JTextField valoare; // camp pentru afisarea valorii HSB
  JSlider ajustare; // rigla de ajustare a valorii
  int val=0; // valoarea RGB in intervalul 0,..,255

  AjustCuloare(String culoare) {
   super(BoxLayout.X_AXIS);
   add(new JLabel(culoare));
   add(Box.createHorizontalGlue());
   ajustare=new JSlider(JSlider.HORIZONTAL, 0, 255, 0);
   ajustare.setMajorTickSpacing(50);
   ajustare.setMinorTickSpacing(10);
   ajustare.setPaintTicks(true);
   ajustare.addChangeListener(this);
   add(ajustare);
   add(Box.createHorizontalStrut(5));
   valoare=new JTextField("0",4);
   valoare.setHorizontalAlignment(JTextField.RIGHT);
   valoare.setEditable(false);
   valoare.setBackground(Color.white);
   valoare.setMaximumSize(valoare.getMinimumSize());
   add(valoare);
   add(Box.createHorizontalStrut(5));
  }

  /* metoda de ascultare a deplasarii cursorului riglei */
  public void stateChanged(ChangeEvent e) {
   val=ajustare.getValue(); // determinarea valorii culorii
   valoare.setText(" "+val); // afisarea valorii
   iug.puneCuloarea(); // modificarea culorii panoului
  }
 }

    
 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }


 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  