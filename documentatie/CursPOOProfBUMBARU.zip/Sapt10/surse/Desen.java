/* Testarea clasei Graphics 
   In fereastra aplicatiei iug se introduce suprafata de desenare
   panouDesen din clasa PanouDesen, care este derivata din clasa
   Canvas
   In clasa PanouDesen, metoda paint() este redefinita, astfel
   incat sa traseze mai multe desene, testandu-se  metodele
   clasei Graphics
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Desen {
   static Sfarsit sfarsit=new Sfarsit();
   static IUG iug=new IUG("Exemplu de desenare");

   static class IUG extends JFrame {
    PanouDesen panouDesen;

    IUG(String titlu) {
     super(titlu);
     addWindowListener(sfarsit);
     panouDesen=new PanouDesen();
     setLocation(200,150);
     getContentPane().add(panouDesen);
     setSize(220,200);
     setVisible(true);
    }
  }


   static class Sfarsit extends WindowAdapter {
      public void windowClosing(WindowEvent e) {
         System.exit(0);
      }
   }

   static class PanouDesen extends Canvas {
    
      public void paint(Graphics g) {
         setBackground(Color.white);
         g.setColor(Color.black);
         g.drawRect(5,5,40,25);
         g.drawRect(50,5,40,25);
         g.setColor(Color.blue);
         g.fillRect(50,5,40,25);
         g.setColor(Color.red);
         g.drawRoundRect(100,5,40,25,10,10);
         g.drawRoundRect(150,5,40,25,10,10);
         g.setColor(Color.green);
         g.fillRoundRect(150,5,40,25,10,10);
         g.drawOval(5,40,40,25);
         g.drawOval(50,40,40,25);
         g.setColor(Color.magenta);
         g.fillOval(50,40,40,25);
         g.setColor(Color.black);
         g.drawArc(100,40,40,25,-5,130);
         g.drawArc(150,40,40,25,-5,130);
         g.setColor(Color.green);
         g.fillArc(150,40,40,25,-5,130);
         g.setColor(Color.black);
         int[] xlf={5,30,55,80,100,125}, ylf={100,70,85,75,75,80};
         g.drawPolyline(xlf,ylf,6);
         int[] xp={15,50,75,65,55}, yp={100,90,95,120,150};
         g.drawPolygon(xp,yp,5);
         g.setColor(Color.yellow);
         g.fillPolygon(xp,yp,5);       
      }
   
   }

   public static void main(String args[]) {
   }
}
