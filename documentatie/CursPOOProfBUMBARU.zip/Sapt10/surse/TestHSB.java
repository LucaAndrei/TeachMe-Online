/* Alegerea culorilor in sistemul HSB (Hue, Saturation, Brightness) */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;


class TestHSB { 
 static AF af=new AF();
 static IUG iug=new IUG("Alegerea culorii in sistemul HSB"+
    " (Hue, Saturation, Brightness)");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  AjustCuloare hue, satur, bright; // rigle de ajustare a culorilor
  Box box1; // caseta riglelor de ajustare
  JPanel panouCuloare; // panoul pe care se prezinta culoarea
  Color culoare; // culoarea panoului panouCuloare
  JLabel culoriRGB; // pentru afisarea culorilor in sistem RGB

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(500, 200);
   setLocation(100, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   /* Se creeaza caseta cu dispozitive de ajustare */
   box1=Box.createVerticalBox();
   hue=new AjustCuloare("Nuanta      "); // ajustarea nuantei
   box1.add(hue);
   satur=new AjustCuloare("Saturatie  "); // ajustarea saturatiei
   box1.add(satur);
   bright=new AjustCuloare("Stralucire "); // ajustarea stralucirii
   bright.ajustare.setPaintLabels(true);
   box1.add(bright);
   cp.add(box1, BorderLayout.WEST);
   panouCuloare=new JPanel(); // crearea panoului pentru culoare
   cp.add(panouCuloare, BorderLayout.CENTER);
   culoriRGB=new JLabel(); // crearea etichetei cu valori RGB
   cp.add(culoriRGB, BorderLayout.SOUTH);
   puneCuloarea();  // se pune culoarea initiala
   setVisible(true);
  }

  /* Metoda de determinare a culorii RGB */
  void puneCuloarea() {
   culoare=new Color(Color.HSBtoRGB(hue.fval, satur.fval,
     bright.fval)); // conversie din HSB in RGB
   panouCuloare.setBackground(culoare);  
   culoriRGB.setText("Culori RGB -> rosu: "+ 
     culoare.getRed()+"  verde: "+culoare.getGreen()+
     "  albastru: "+culoare.getBlue()); 
  }
 }   

 /* Un "dispozitiv" de ajustare a valorii unei culori */

 static class AjustCuloare extends Box implements ChangeListener {
  JTextField valoare; // camp pentru afisarea valorii HSB
  JSlider ajustare; // rigla de ajustare a valorii
  float fval=1.0f; // valoarea HSB (in intervalul 0,..,1).

  AjustCuloare(String culoare) {
   super(BoxLayout.X_AXIS);
   add(new JLabel(culoare));
   add(Box.createHorizontalGlue());
   ajustare=new JSlider(JSlider.HORIZONTAL, 0, 100,100);
   ajustare.setMajorTickSpacing(20);
   ajustare.setMinorTickSpacing(10);
   ajustare.setPaintTicks(true);
   ajustare.addChangeListener(this);
   add(ajustare);
   add(Box.createHorizontalStrut(5));
   valoare=new JTextField("1.00",4);
   valoare.setHorizontalAlignment(JTextField.RIGHT);
   valoare.setEditable(false);
   valoare.setBackground(Color.white);
   valoare.setMaximumSize(valoare.getMinimumSize());
   add(valoare);
   add(Box.createHorizontalStrut(5));
  }

  /* metoda de ascultare a deplasarii cursorului riglei */
  public void stateChanged(ChangeEvent e) {
   fval=ajustare.getValue()/100.0f; // determinarea valorii reale
      // in intwervalul 0,..1
   valoare.setText((fval+" ").substring(0,4)); // afisarea valorii
   iug.puneCuloarea(); // modificarea culorii panoului
  }
 }

    
 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }


 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  