/* Alegerea culorilor folosind un JColorChooser */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class SelectCulori { 
 static AF af=new AF();
 static AscultDialog ascultDialog=new AscultDialog();
 static AscultButon ascultButon=new AscultButon();
 static IUG iug=new IUG("Alegerea culorii folosind JColorChooser");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JPanel panouCuloare; // panoul pe care se prezinta culoarea
  JColorChooser selectorCuloare;
  JDialog dialogCuloare;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(350, 200);
   setLocation(100, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   panouCuloare=new JPanel(); // crearea panoului pentru culoare
   cp.add(panouCuloare, BorderLayout.CENTER);
   selectorCuloare=new JColorChooser();
   JButton butonCuloare=new JButton("Schimbarea culorii");
   butonCuloare.addActionListener(ascultButon);
   butonCuloare.setToolTipText("Selectarea culorii panoului");
   cp.add(butonCuloare, BorderLayout.SOUTH);
   dialogCuloare=JColorChooser.createDialog(butonCuloare,
    "Alegerea culorii", true, selectorCuloare, ascultDialog,
    ascultDialog);   
   setVisible(true);
  }

 }   

    
 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Ascultator actiuni fereastra dialog */ 
 static class AscultDialog implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   if(e.getActionCommand().equals("OK"))
    iug.panouCuloare.setBackground(
          iug.selectorCuloare.getColor());
  }
 }

 /* Ascultarea butonului de comanda */
 static class AscultButon implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    iug.dialogCuloare.show();
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  