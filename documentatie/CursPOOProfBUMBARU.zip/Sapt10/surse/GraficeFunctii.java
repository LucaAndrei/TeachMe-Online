/* Aplicatie de trasare a graficelor unor functii.
   Se selecteaza functia de trasat si se introduc valorile marginilor
   intervalului de reprezentare.
   Trasarea functiei se face fie cand se selecteaza o noua functie,
   fie cand este selectat unul din campurile de text si se apasa 
   tasta <Enter>.
   Daca se introduc date gresite, nu se traseaza functia, ci apare un
   mesaj de eroare
*/
   
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class GraficeFunctii {
  static Actiuni act=new Actiuni();
  static Functii fct=new Functii();
  static Grafic gr=new Grafic();
  static Label mesaj=new Label();
  static boolean trasare=false;
  static int nrPasi=200; // numarul de subintervale
  static int nrNoduri=nrPasi+1; // numarul de puncte ale graficului
  static int indFunc;  // indicele functiei care se reprezinta grafic
    // Tabele de coordonate ale punctelor graficului functiei
  static int x[]=new int[nrNoduri], y[]=new int[nrNoduri];
    // inaltimea si latimea suprafetei de desenare si pozitiile axelor
  static int inaltime, latime, xord, yabsc; 

 
  public static void main(String args[]) {
    JFrame fp=new JFrame("Grafice de functii");
    Container cp=fp.getContentPane();
    cp.add(fct,"North");
    cp.add(gr,"Center");
    gr.setBackground(Color.cyan);
    cp.add(mesaj,"South");
    mesaj.setBackground(Color.green);
    fp.addWindowListener(act);
    fp.setLocation(150,50);
    fp.setSize(500,500);
    fp.setVisible(true);
  }

  // Introducerea datelor si calcularea coordonatelor 

  static class Functii extends JPanel {
    // Componenta de selectare a functiei
    JLabel lab=new JLabel("Alegeti functia de reprezentat");
    Choice f=new Choice();
    // Campurile de text pentru introducerea marginilor intervalului
    // si numarului de subintervale
    JTextField inf=new JTextField("-6.28");
    JTextField sup=new JTextField("6.28");
    JTextField pasi=new JTextField("200");
    
    // Constructorul clasei Functii
    Functii() {
      // Adaugarea de functii la lista de optiuni
      f.add("x^2");
      f.add("x^3");
      f.add("log(1+x^2)-1");
      f.add("sin(x)");
      f.add("cos(x)");
      f.add("exp(-abs(0.1*x))*cos(x)");
      f.add("cos(x)/sqrt(1+x*x)");
      // Setarea gestionarului de pozitionare
      setLayout(new GridLayout(4,2));
      // Adaugarea componentelor
      add(new Label("Alegeti functia de reprezentat: "));
      add(f);
      add(new Label("Marginea inferioara a intervalului: "));
      add(inf);
      add(new Label("Marginea superioara a intervalului: "));
      add(sup);
      add(new Label("Numarul de subintervale pentru trasare: "));
      add(pasi);
      // Adaugarea la componente a interceptorului de evenimente
      inf.addActionListener(act);
      sup.addActionListener(act);
      pasi.addActionListener(act);
      f.addItemListener(act);
    }
    
    // Calcularea valorii functiei in punctul de abscisa x
    double func(double x) {
      switch(indFunc) {
        case 0: return x*x;
        case 1: return x*x*x;
        case 2: return Math.log(1+x*x)-1;
        case 3: return Math.sin(x);
        case 4: return Math.cos(x);
        case 5: return Math.exp(-Math.abs(0.1*x))*Math.cos(x);
        case 6: return Math.cos(x)/Math.sqrt(1.0+x*x);
      }
      return 0.0;
    }


  }

  // Captarea si tratarea evenimentelor
  static class Actiuni  extends WindowAdapter
               implements ActionListener, ItemListener {

    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
    public void actionPerformed(ActionEvent e) {
      reprezinta();
    }
    public void itemStateChanged(ItemEvent e) {
      reprezinta();
    }
    public void reprezinta() {
      try {
        calcul();//Se calculeaza coordonatele punctelor graficului
        gr.repaint();//Se traseaza graficul functiei
      }
      catch(Exception e) {
        mesaj.setText("eroare: "+e);
      }
    }
    // Calcularea coordonatelor tuturor punctelor graficului
    void calcul() throws Exception {
      double xmin,xmax,ymin,ymax,pas,scarax,scaray;
      // Initializari
      mesaj.setText("");
      trasare=false;
      gr.repaint();
      // Preluarea datelor introduse in campurile de text
      int nrP=Integer.parseInt(fct.pasi.getText());
      if(nrP<1) throw new Exception("Numar de intervale incorect");
      if(nrP != nrPasi) {
        nrPasi=nrP;
        nrNoduri=nrPasi+1;
        x=new int[nrNoduri];
        y=new int[nrNoduri];
      }
      xmin=Double.parseDouble(fct.inf.getText()); // marginea din stanga
      xmax=Double.parseDouble(fct.sup.getText()); // marginea din dreapta
      if(xmin==xmax) throw new Exception("xmin==xmax");
      pas=(xmax-xmin)/nrPasi; // Lungimea subintervalului     
      double valy[]=new double[nrNoduri];// tabloul ordonatelor
      // Preluarea indicelui functiei selectate
      indFunc=fct.f.getSelectedIndex(); // se afla indicele functiei
      // Determinarea dimensiunilor suprafetei de desenare
      inaltime=gr.getHeight();  // inaltimea suprafetei de desenare
      latime=gr.getWidth();  // latimea suprafetei de desenare
      // Calcularea ordonatelor punctelor graficului
      for (int i=0; i<nrNoduri; i++) valy[i]=fct.func(xmin+i*pas);
      // Determinarea valorilor minima si maxima ale lui y
      ymin=valy[0];
      ymax=valy[0];
      for (int i=1; i<nrNoduri; i++) {
        if(valy[i]>ymax) ymax=valy[i];
        if(valy[i]<ymin) ymin=valy[i];
      }
      // Determinarea scarilor de reprezentare pe cele doua directii
      scarax=latime/(xmax-xmin);
      scaray=inaltime/(ymax-ymin);
      // Calcularea coordonatelor de pe desen ale punctelor graficului
      for(int i=0; i<nrNoduri; i++) {
         y[i]=inaltime-(int)Math.round((valy[i]-ymin)*scaray);
         x[i]=(int)Math.round(i*pas*scarax);
      }
      // Determinarea pozitiilor pe desen ale axelor de coordonate
      yabsc=inaltime+(int)Math.round(ymin*scaray);
      xord=(int)Math.round(-xmin*scarax);
      trasare=true;
    }
  }      

  // Componenta pe care se traseaza desenul
  static class Grafic extends Canvas {
    // Metoda de trasare a graficului
    public void paint(Graphics g) {
      if(!trasare) return;
      // Trasarea axelor de coordonate
      g.setColor(Color.blue);
      if(yabsc>=0 && yabsc<=inaltime)
        g.drawLine(0,yabsc,latime,yabsc);
      if(xord>=0 && xord<=latime)
        g.drawLine(xord,0,xord,inaltime);   
      // Trasarea curbei (sub forma de linie franta)
      g.setColor(Color.red);
      g.drawPolyline(x,y,nrNoduri);
    }
  }
}  