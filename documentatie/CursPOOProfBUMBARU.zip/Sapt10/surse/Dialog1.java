/* Alegerea culorilor folosind obiectele de culoare predefinite
   din clasa Color
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import javax.swing.event.*;


class Dialog1 { 
 static AF af=new AF();
 static IntroducereText it=new IntroducereText();
 static IUG iug=new IUG("Utilizarea unei ferestre de dialog");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JTextArea arieText;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(250, 200);
   setLocation(100, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   JButton buton1=new JButton("Introducere text");
   buton1.addActionListener(it);
   cp.add(buton1, BorderLayout.NORTH);
   arieText=new JTextArea();
   arieText.setLineWrap(true);
   arieText.setWrapStyleWord(true);
   cp.add(arieText, BorderLayout.CENTER);  
   setVisible(true);
  }

 }   
  
 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
     System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa pentru introducerea textului prin fereastra de dialog */
 static class IntroducereText implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   String sirIntrodus;
   boolean terminat=false;
   while(!terminat) {
    sirIntrodus=JOptionPane.showInputDialog("Introduceti un text");
    if(sirIntrodus!=null) { 
     if(sirIntrodus.trim().equals(""))
      JOptionPane.showMessageDialog(iug, "Nu se permite un sir vid!",
       "Avertisment", JOptionPane.WARNING_MESSAGE);
     else { 
      int raspuns=JOptionPane.showConfirmDialog(iug,
        "Doriti adaugarea textului: "+sirIntrodus+"?");
      if(raspuns==JOptionPane.YES_OPTION) 
        iug.arieText.append(sirIntrodus+"\n");
      terminat=true;
     }
    }
    else terminat=true;
   }
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  