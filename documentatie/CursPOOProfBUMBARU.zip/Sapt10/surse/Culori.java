/* Alegerea culorilor folosind obiectele de culoare predefinite
   din clasa Color
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;


class Culori { 
 static AF af=new AF();
 static IUG iug=new IUG("Alegerea culorii din lista");

 /* clasa imbricata pentru interfata utilizator grafica */
 static class IUG extends JFrame {
  JPanel panouCuloare; // panoul pe care se prezinta culoarea
  String[] numeCulori={"black", "darkGray", "gray", 
   "lightGray", "white", "blue", "cyan", "green", "orange",
   "yellow", "red", "pink", "magenta"};
  Color[] tablouCulori={Color.black, Color.darkGray, Color.gray,
   Color.lightGray, Color.white, Color.blue, Color.cyan, Color.green,
   Color.orange, Color.yellow, Color.red, Color.pink, Color.magenta};
  JList listaCulori;

  IUG(String titlu) { // constructorul clasei IUG
   super(titlu);
   setSize(250, 200);
   setLocation(100, 50);
   Container cp=getContentPane();
   addWindowListener(af);  // adaugarea ascultatorului de fereastra
   panouCuloare=new JPanel(); // crearea panoului pentru culoare
   cp.add(panouCuloare, BorderLayout.CENTER);

   Color[] tablouCulori={Color.black, Color.darkGray, Color.white};
   listaCulori=new JList(numeCulori);
   listaCulori.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
   listaCulori.addListSelectionListener(new AscultLista());
   JScrollPane panouCulori=new JScrollPane(listaCulori);
   cp.add(panouCulori, BorderLayout.WEST);
   
   setVisible(true);
  }

 }   

    
 /* Clasa ascultatoare de fereastra */  
 static class AF extends WindowAdapter {
  public void windowClosing(WindowEvent e) {
   System.exit(0); // incheierea executarii aplicatiei
  }
 }

 /* Clasa ascultatoare a listei de culori */
 static class AscultLista implements ListSelectionListener {
  public void valueChanged(ListSelectionEvent e) {
   int indiceCuloare=iug.listaCulori.getSelectedIndex();
   iug.panouCuloare.setBackground(iug.tablouCulori[indiceCuloare]);
  }
 }

 /* Metoda principala a aplicatiei */
 public static void main(String args[]) {
 }
}
  