class PrimaAplicatie { 
   public static void main(String args[]) { 
      System.out.println("Prima noastra aplicatie a reusit!"); 
   } 
}