class PrimaAplicatie1 { 
   void main(String args[]) { 
      System.ont.println("Prima noastra aplicatie a reusit!"); 
   } 
}